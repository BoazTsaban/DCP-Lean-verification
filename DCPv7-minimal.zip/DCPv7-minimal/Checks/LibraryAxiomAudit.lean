/- Audit of both the inherited library and the fixed-manuscript development.
The legacy library still declares its old algorithm inputs; the separate
DCPv7AxiomAudit forbids those dependencies in every v7-origin declaration. -/
import DCPv7
import Lean.Util.CollectAxioms

open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound,
    ``BraidGroup.Literature.standardEmbedding_injective,
    ``BraidGroup.Literature.center_generated_fullTwist,
    ``BraidGroup.Literature.fullTwist_pure,
    ``BraidGroup.Literature.deleteEnds,
    ``BraidGroup.Literature.deleteEnds_embedded,
    ``BraidGroup.Literature.deleteEnds_fullTwist,
    ``BraidGroup.Literature.doubleCentralizer,
    ``BraidGroup.Literature.wordProblem_exists,
    ``BraidGroup.Literature.centralizerAlgorithm_exists,
    ``BraidGroup.Literature.simultaneousConjugacy_exists,
    ``FiniteArtinGroup.Literature.embedding,
    ``FiniteArtinGroup.Literature.embedding_injective,
    ``FiniteArtinGroup.Literature.embedding_parabolic,
    ``FiniteArtinGroup.Literature.doubleCentralizer,
    ``FiniteArtinGroup.Literature.directProduct_intersection,
    ``FiniteArtinGroup.Literature.embedding_word,
    ``FiniteArtinGroup.Literature.wordProblem_exists,
    ``FiniteArtinGroup.Literature.centralizerAlgorithm_exists,
    ``FiniteArtinGroup.Literature.simultaneousConjugacy_exists,
    ``DCPv7.Literature.BR11_structure,
    ``DCPv7.Literature.BR11_word_procedure,
    ``DCPv7.Literature.GS91_fixed_multipliers,
    ``DCPv7.Literature.Ch92_spherical_biautomatic]
  let mut count : Nat := 0
  let mut declared : Array Name := #[]
  let mut observed : Array Name := #[]
  for (name, info) in env.constants.toList do
    let localOrigin := match env.getModuleIdxFor? name with
      | some idx =>
        let modName := env.header.moduleNames[idx.toNat]!.toString
        modName == "BraidGroup" || modName.startsWith "BraidGroup." ||
          modName == "DCPVerification" || modName.startsWith "DCPVerification." ||
          modName == "DCPv7" || modName.startsWith "DCPv7."
      | none => false
    if localOrigin then
      count := count + 1
      if info matches .axiomInfo _ then
        if !allowed.contains name then throwError "Unreviewed axiom declaration: {name}"
        declared := declared.push name
      for ax in (← collectAxioms name) do
        if !allowed.contains ax then throwError "Unreviewed axiom {ax} in {name}"
        if !observed.contains ax then observed := observed.push ax
  logInfo m!"Audited {count} local declarations; {declared.size} explicit literature axioms."
  logInfo m!"Declared literature axioms: {declared}"
  logInfo m!"Observed dependencies: {observed}"
  for theoremName in #[``DCPv7.MainSearch.main_theorem,
      ``DCPv7.ConstrainedSearch.main_theorem,
      ``DCPv7.WordAutomaton.finite_words_generate,
      ``DCPv7.ProductEncoding.product_main_theorem,
      ``DCPv7.EncodedAutomaton.generatorWords_generate,
      ``DCPv7.EncodedAutomaton.generatorWords_primrec,
      ``DCPv7.EncodedAutomaton.intersection_correct,
      ``DCPv7.EncodedAutomaton.intersectAll_primrec,
      ``DCPv7.EffectiveReduction.reduction_correct,
      ``DCPv7.AssemblyCost.assembly_time_linear,
      ``DCPVerification.main_theorem,
      ``DCPVerification.Constraints.main_theorem,
      ``DCPVerification.Spherical.reduction,
      ``DCPVerification.SphericalDecision.main_theorem,
      ``DCPVerification.rawAssembly_length] do
    logInfo m!"{theoremName}: {← collectAxioms theoremName}"
