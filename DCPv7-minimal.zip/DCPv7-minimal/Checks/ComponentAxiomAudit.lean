import DCPv7.LengthEnumeration
import DCPv7.Automaton
import DCPv7.LengthComputability
import DCPv7.SignedSearch
import DCPv7.AutomatonGenerators
import DCPv7.AutomatonFinitePaths
import DCPv7.AutomatonGeneratorWords
import DCPv7.RestrictedAutomatonPaths
import DCPv7.FiniteScan
import DCPv7.EncodedAutomaton
import DCPv7.EncodedAutomatonPaths
import DCPv7.EncodedAutomatonGenerators
import DCPv7.EncodedGeneratorComputability
import DCPv7.EncodedAutomatonIntersection
import DCPv7.MultiplierLanguages
import DCPv7.ProductEncoding
import DCPv7.ProductComputability
import DCPv7.ProductWords
import DCPv7.ProductSearch
import DCPv7.EffectiveReduction
import DCPv7.AssemblyCost
import DCPv7.FinitePresentation
import DCPv7.SphericalPresentation
import DCPv7.PaddedWords
import DCPv7.EncodedProjection
import DCPv7.BiautomaticInterfaces
import DCPv7.BiautomaticConjugators
import DCPv7.BiautomaticFiniteAlgorithms
import DCPv7.BiautomaticAlgorithms
import DCPv7.PromiseTotalization
import DCPv7.DerivedSphericalAlgorithms
import Lean
import Lean.Util.CollectAxioms

/-! This audits the independent infrastructure and local deductions. The
manuscript axiom boundary and coverage are checked separately. -/
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    let localOrigin := match env.getModuleIdxFor? name with
      | some idx =>
        let moduleName := env.header.moduleNames[idx.toNat]!.toString
        moduleName.startsWith "DCPv7."
      | none => false
    if localOrigin then
      count := count + 1
      if info matches .axiomInfo _ then
        throwError "Unexpected custom axiom declaration: {name}"
      for ax in (← collectAxioms name) do
        if !allowed.contains ax then
          throwError "Unexpected axiom dependency {ax} in {name}"
  logInfo m!"Audited {count} declarations in the imported DCPv7 component modules; no custom axioms."
