/- Independent all-declaration axiom audit of the public DCPv7 import.

The scope is determined by origin module, including generated and private
declarations. It does not rely on declaration namespaces or a theorem shortlist.
Only the four named DCPv7.Literature axioms may be declared in a DCPv7 module.
The three old finite-Artin algorithm axioms are forbidden in every declaration
of v7 origin, even though the imported older development still declares them.
This is an axiom audit, not a source-to-manuscript coverage certificate.
-/
import DCPv7
import Lean.Util.CollectAxioms

open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let isV7Module := fun (name : Name) =>
    name.toString == "DCPv7" || name.toString.startsWith "DCPv7."
  let foundations : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let braidInputs : Array Name := #[
    ``BraidGroup.Literature.standardEmbedding_injective,
    ``BraidGroup.Literature.center_generated_fullTwist,
    ``BraidGroup.Literature.fullTwist_pure,
    ``BraidGroup.Literature.deleteEnds,
    ``BraidGroup.Literature.deleteEnds_embedded,
    ``BraidGroup.Literature.deleteEnds_fullTwist,
    ``BraidGroup.Literature.doubleCentralizer,
    ``BraidGroup.Literature.wordProblem_exists,
    ``BraidGroup.Literature.centralizerAlgorithm_exists,
    ``BraidGroup.Literature.simultaneousConjugacy_exists]
  let structuralArtinInputs : Array Name := #[
    ``FiniteArtinGroup.Literature.embedding,
    ``FiniteArtinGroup.Literature.embedding_injective,
    ``FiniteArtinGroup.Literature.embedding_parabolic,
    ``FiniteArtinGroup.Literature.doubleCentralizer,
    ``FiniteArtinGroup.Literature.directProduct_intersection,
    ``FiniteArtinGroup.Literature.embedding_word]
  let v7Inputs : Array Name := #[
    ``DCPv7.Literature.BR11_structure,
    ``DCPv7.Literature.BR11_word_procedure,
    ``DCPv7.Literature.GS91_fixed_multipliers,
    ``DCPv7.Literature.Ch92_spherical_biautomatic]
  let forbidden : Array Name := #[
    ``FiniteArtinGroup.Literature.wordProblem_exists,
    ``FiniteArtinGroup.Literature.centralizerAlgorithm_exists,
    ``FiniteArtinGroup.Literature.simultaneousConjugacy_exists]
  let allowed := foundations ++ braidInputs ++ structuralArtinInputs ++ v7Inputs
  let mut count : Nat := 0
  let mut declared : Array Name := #[]
  let mut observed : Array Name := #[]
  let modules := env.header.moduleNames.filter isV7Module
  for (name, info) in env.constants.toList do
    let v7Origin := match env.getModuleIdxFor? name with
      | some idx => isV7Module env.header.moduleNames[idx.toNat]!
      | none => false
    if v7Origin then
      count := count + 1
      if info matches .axiomInfo _ then
        if !v7Inputs.contains name then
          throwError "Unexpected v7-origin axiom declaration: {name}"
        declared := declared.push name
      for ax in (← collectAxioms name) do
        if forbidden.contains ax then
          throwError "Forbidden old finite-Artin algorithm axiom {ax} in {name}"
        if !allowed.contains ax then
          throwError "Unreviewed axiom dependency {ax} in {name}"
        if !observed.contains ax then observed := observed.push ax
  if count == 0 then throwError "No DCPv7-origin declarations were audited"
  if declared.size != v7Inputs.size then
    throwError "Expected exactly four v7-origin axioms; found {declared}"
  for name in v7Inputs do
    if !declared.contains name then
      throwError "Expected literature axiom was not imported and audited: {name}"
  logInfo m!"Audited {count} declarations from {modules.size} DCPv7-origin modules."
  logInfo m!"Audited modules: {modules.qsort Name.lt}"
  logInfo m!"Declared DCPv7 axioms ({declared.size}): {declared.qsort Name.lt}"
  logInfo m!"Allowed transitive axiom dependencies ({allowed.size}): {allowed.qsort Name.lt}"
  logInfo m!"Observed transitive axiom dependencies ({observed.size}): {observed.qsort Name.lt}"
  logInfo m!"Forbidden old finite-Artin algorithm dependencies: none in every audited declaration."
  for theoremName in #[
      ``DCPv7.VerifiedBiautomatic.algorithms,
      ``DCPv7.VerifiedBiautomatic.centralizer_correct,
      ``DCPv7.VerifiedBiautomatic.simultaneous_correct,
      ``DCPv7.VerifiedSpherical.main_theorem,
      ``DCPv7.VerifiedManuscript.braid_main,
      ``DCPv7.VerifiedManuscript.constrained_main,
      ``DCPv7.VerifiedManuscript.spherical_main,
      ``DCPv7.VerifiedManuscript.product_main] do
    logInfo m!"{theoremName}: {← collectAxioms theoremName}"
