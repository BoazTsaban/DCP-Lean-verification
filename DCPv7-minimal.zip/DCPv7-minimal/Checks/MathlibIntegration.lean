import Mathlib
import DCPv7

#check DCPv7.MainSearch.main_theorem
#check DCPv7.WordAutomaton.finite_words_generate
#check DCPv7.ProductEncoding.coordinateInput_primrec
#check DCPv7.AssemblyCost.assembly_time_linear
#check DCPv7.VerifiedBiautomatic.biautomatic_lemma
#check DCPv7.VerifiedManuscript.spherical_main
#check DCPv7.VerifiedManuscript.product_main
#check DCPv7.ProductEncoding.paperSearch_preserves_targets
