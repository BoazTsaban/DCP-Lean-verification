import DCPv7.VerifiedManuscript

/-! Public entry point for the minimal manuscript verification package.
See README.md, TRUST.md and verification/coverage.json. -/
