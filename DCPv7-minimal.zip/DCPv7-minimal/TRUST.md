# Exact mathematical trust boundary

The manuscript deductions are kernel checked relative to standard Lean
foundations (`propext`, `Classical.choice`, `Quot.sound`) and the following
**20 used mathematical inputs**. The exact Lean types and source comments are
in the three `Literature.lean` files. The manuscript bibliography supplies the
full references.

## Braid inputs (10)

In `BraidGroup/Literature.lean`:

- `standardEmbedding_injective`: classical standard-parabolic embedding.
- `center_generated_fullTwist`: Garside's center theorem, with ambient rank at
  least three.
- `fullTwist_pure`: purity of the full twist.
- `deleteEnds`: deletion of interior strands of a pure braid.
- `deleteEnds_embedded`: deletion kills an embedded pure braid with a trivial
  final strand.
- `deleteEnds_fullTwist`: deletion sends the full twist to the two-strand
  full twist.
- `doubleCentralizer`: the parabolic double-centralizer theorem of
  Garber--Kalka--Liberman--Teicher / Ajbal--Godelle.
- `wordProblem_exists`: the uniform braid word-problem algorithm.
- `centralizerAlgorithm_exists`: Gurzo's algorithm for centralizers of finite
  sets, including the empty set.
- `simultaneousConjugacy_exists`: the Lee--Lee simultaneous-conjugacy algorithm.

The geometric deletion map is restricted to pure braids. The added-strand
center-intersection conclusion is proved locally using these inputs and the
proved exponent-sum homomorphism. The double-coset conclusion is not an axiom.

## Spherical structural inputs (6)

In `BraidGroup/SphericalLiterature.lean`, namespace
`FiniteArtinGroup.Literature`:

- `embedding`, `embedding_injective`, `embedding_parabolic`, `embedding_word`:
  the indicated standard-parabolic embeddings, injectivity, proper/parabolic
  image properties and word action.
- `doubleCentralizer`, `directProduct_intersection`: the Ajbal--Godelle
  double-centralizer and internal-product intersection assertions for the
  admitted nonexceptional ambient types.

Only the diagram enlargements listed in the paper are admitted by the
`AllowedEmbedding` predicate. The actual spherical decision and search
procedures used by DCPv7 are derived through the proved biautomatic lemma.

## Constructive biautomatic inputs (4)

In `DCPv7/Literature.lean`:

- `BR11_structure`: Bridson--Reeves, Proposition 1.2, presentation-to-structure
  construction, allowed to diverge outside the biautomatic promise.
- `BR11_word_procedure`: the structure-based word procedure used in their
  Lemma 1.3 proof.
- `GS91_fixed_multipliers`: fixed-word left/right multiplier constructions from
  Gersten--Short, pp. 135--136 and the constructive proof of Lemma 4.2. This is a
  constructive-proof interface with explicit coordinate orientation, rather
  than a claim that its exact displayed type is a verbatim theorem statement.
- `Ch92_spherical_biautomatic`: Charney, Theorem 3.4, for the supported explicit
  finite spherical presentations.

Generic automata intersection, erasing padded projection, emptiness, trimming,
path extraction and centralizer-generator construction are proved locally.
The simultaneous-conjugacy and centralizer conclusions of the manuscript's
biautomatic lemma are not additional assumptions.

## Legacy declarations and the audit

The minimal module import closure still needs mixed-purpose files from the
earlier development. Consequently `BraidGroup/SphericalLiterature.lean` also
**declares** three older direct spherical algorithm axioms:
`wordProblem_exists`, `centralizerAlgorithm_exists`, and
`simultaneousConjugacy_exists` in `FiniteArtinGroup.Literature`.

Those three declarations are not among the 20 inputs used by the DCPv7
conclusions. `Checks/DCPv7AxiomAudit.lean` checks every DCPv7-origin declaration,
including private and generated declarations, and rejects any dependency on
these three older algorithm axioms. It also permits exactly the four declared
DCPv7 literature inputs and only the 20 reviewed mathematical inputs plus the
three Lean foundations as transitive dependencies.

`Checks/LibraryAxiomAudit.lean` separately audits all imported custom library
declarations, allowing the explicitly disclosed legacy declarations as well.
`Checks/ComponentAxiomAudit.lean` checks that the independent infrastructure
has no custom axiom dependency. The package is therefore not described as
axiom-free, and a count of declared axioms should not be confused with the
principal theorems' dependencies.

## Coverage and limitations

`verification/coverage.json` maps all 11 labelled manuscript items and five
additional obligations to formal declarations. Two labelled items are
definitions and one is an explicitly cited theorem; the others are local
proofs. `Checks/CoverageReferences.lean` resolves all referenced declarations
through Lean.

The reduction, search schedule, generator computations, exact listed spherical
embeddings, coordinate decomposition, and gather-then-re-expression product
search follow the paper's proof routes. Proof-source provenance is recorded
byte for byte. The English-to-formal correspondence and the adequacy of the
cited interfaces are reviewed mathematical judgments, not propositions proved
by parsing the manuscript in Lean. The cited papers' own proofs are outside
this package's verification boundary.
