# Minimal Lean verification of DCPv7

This package contains the custom Lean sources needed to verify the proofs of
**The Double Coset Problem for Parabolic Subgroups of Braid Groups**, by Arkadius
Kalka, Mina Teicher and Boaz Tsaban, in the bundled `manuscript/DCPv7.tex`.

Verification is **complete modulo the named cited mathematical inputs**. The
package proves the manuscript's deductions using 20 explicit literature inputs
and the standard Lean foundations. It does not formalize the proofs of those
cited results. See [TRUST.md](TRUST.md) for the precise boundary. A successful
`verify.py` run records its exact inputs in `verification/result.json`.

The package contains **75 custom source modules**, six verification checks, a
small independent consumer, the manuscript, and coverage/provenance metadata.
No Lean installation, Mathlib source, transitive dependency source, compiled
library, cache, PDF, or historical build log is bundled. The 74 imported proof
modules are byte-for-byte copies of the verified development; the public
`DCPv7.lean` wrapper imports only the final manuscript module. Unused development
helpers are omitted.

## Dependencies

- [Lean / elan](https://github.com/leanprover/elan#installation): Lean **4.33.0**,
  selected by `lean-toolchain` (`leanprover/lean4:v4.33.0`). Install elan using its
  official instructions if it is not already available.
- [Mathlib](https://github.com/leanprover-community/mathlib4) at commit
  [`db584cd6d46c92f209a44c0f1c829460d327499d`](https://github.com/leanprover-community/mathlib4/tree/db584cd6d46c92f209a44c0f1c829460d327499d).
- Git and Python **3.9 or later**. The verifier uses only Python's standard library.

`lakefile.toml` pins Mathlib. `lake-manifest.json` also pins all eight transitive
packages by upstream Git URL and commit: Batteries, Aesop, Qq, ProofWidgets,
ImportGraph, LeanSearchClient, Plausible and Cli. Lake obtains them from their
upstream repositories. Do not run `lake update` unless intentionally creating
and rechecking a different dependency version.

## Reproduce from the archive

Extract `DCPv7-minimal.zip` and open a terminal in the extracted directory:

```sh
cd DCPv7-minimal
lake exe cache get
python3 verify.py
```

Elan selects/installs the pinned compiler, Lake obtains the pinned dependencies,
and Mathlib's cache command obtains its compiled dependencies. The cache reduces
build time; it is external to this source package. An Internet connection is
needed for this initial setup. The verification run rebuilds the custom proofs
from the included sources, with warnings treated as errors.

On a machine with an existing checkout of **exactly the pinned Mathlib revision**,
reuse it and its already installed transitive dependencies instead:

```sh
python3 verify.py --mathlib /absolute/path/to/mathlib4
```

This creates dependency links only inside this package's ignored `.lake`
directories. It neither copies nor changes the shared library. Dependency Git
revisions and tracked source contents are checked. Filesystem execute-bit
changes in cloud-synchronized checkouts are ignored; source changes are not.
Do not move the package until verification has finished.

The default is three parallel post-build checks. Adjust the number of workers
or the per-command timeout if needed:

```sh
python3 verify.py --jobs 2 --timeout 3600
```

For just the theorem build, use `lake build --wfail DCPv7`. For the full receipt,
use `verify.py`.

## What the verification command checks

1. The pinned Lean version, dependency commits and tracked dependency contents.
2. The included source hashes, the exact manuscript inventory (11 labelled
   environments and five additional proof obligations), and the correspondence
   ledger in `verification/coverage.json`.
3. A source scan excluding proof escapes and unexpected axiom declarations.
4. A fresh warning-as-error build of the custom source import closure.
5. Axiom dependencies of every imported custom declaration, including private
   and generated declarations; a stricter audit of every DCPv7-origin declaration
   forbids the three old direct spherical algorithm axioms.
6. Independent infrastructure uses no custom axioms; coverage declaration names
   resolve through Lean; importing full Mathlib in either order succeeds; a
   separate Lake package consumes the public library.
7. The complete input inventory and content/identity freeze before and after
   the run. The receipt is written only after all checks and workers finish.

The source checks and generated receipt support reproducibility. The
source-to-paper correspondence is an explicit reviewed mapping; Lean checks the
formal statements and proofs, not the English prose. Generated logs are placed
in `verification/logs/` and are not part of the distribution.

## Public entry point

```lean
import DCPv7

#check DCPv7.VerifiedManuscript.braid_main
#check DCPv7.VerifiedManuscript.constrained_main
#check DCPv7.VerifiedBiautomatic.biautomatic_lemma
#check DCPv7.VerifiedManuscript.spherical_main
#check DCPv7.VerifiedManuscript.product_main
```

The braid theorem uses ambient centralizers, the added-strand argument and exact
increasing-total-length search in the supplied subgroup generators. The
biautomatic lemma proves the automaton intersection/projection, finite-system
decision, and trimmed-automaton centralizer-generator construction from the
named cited interfaces. The spherical theorem derives its algorithms from that
lemma. The product theorem first gathers the particular factor witnesses and
then expresses those selected tuples in the original supplied generators.

Parabolicity and biautomaticity are input promises. The package does not claim
an algorithm recognizing those promises. Witness search can diverge on negative
instances; separate decision procedures answer the yes/no question. The linear
assembly-cost result excludes subgroup-dependent centralizer preprocessing.

## Manuscript and provenance

The included manuscript has SHA-256
`4ed2b4de7dcc154f5d8d0a18433c693616e79737f3236d6dd373ccd4f64f0177`.
`verification/provenance.json` records the original proof-source hashes and the
four authorized wording/precision corrections since the source-reviewed paper:
removing an extra word, making padding erasure/surjectivity explicit, treating
the empty simultaneous system explicitly, and restricting the introductory
Coxeter minimal-length claim to standard parabolic double cosets. These edits
preserve the reviewed proof routes. The portable package receives a fresh
receipt; it does not reuse the development directory's historical receipt.
