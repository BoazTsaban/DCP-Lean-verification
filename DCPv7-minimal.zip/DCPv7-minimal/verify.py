#!/usr/bin/env python3
"""Rebuild the minimal package and check its manuscript/axiom boundaries."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
IGNORED_DIRS = {'.lake', '.git', '__pycache__', 'logs'}
IGNORED_FILES = {'.DS_Store', 'Icon\r'}
GENERATED = {'verification/result.json', 'verification/inputs.json'}
CHECKS = ('ComponentAxiomAudit', 'LibraryAxiomAudit', 'DCPv7AxiomAudit',
          'CoverageReferences', 'MathlibIntegration', 'ReverseIntegration')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    result = {}
    for base, directories, files in os.walk(ROOT):
        directories[:] = sorted(d for d in directories if d not in IGNORED_DIRS)
        for name in sorted(files):
            p = Path(base) / name
            relative = p.relative_to(ROOT).as_posix()
            if name not in IGNORED_FILES and relative not in GENERATED:
                if p.is_symlink():
                    raise SystemExit(f'Unexpected input symlink: {relative}')
                result[relative] = sha(p)
    return result


def snapshot():
    hashes = inputs()
    hashes['verification/inputs.json'] = sha(ROOT / 'verification/inputs.json')
    result = {}
    for relative, digest in hashes.items():
        stat = (ROOT / relative).stat()
        result[relative] = (digest, stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)
    return result


def lean_code(text):
    """Discard nested comments and strings before scanning proof escapes."""
    out, i, depth = [], 0, 0
    while i < len(text):
        if text.startswith('/-', i):
            depth += 1
            i += 2
        elif depth and text.startswith('-/', i):
            depth -= 1
            i += 2
        elif depth:
            i += 1
        elif text.startswith('--', i):
            end = text.find('\n', i)
            i = len(text) if end < 0 else end
        elif text[i] == '"':
            i += 1
            while i < len(text):
                if text[i] == '\\':
                    i += 2
                elif text[i] == '"':
                    i += 1
                    break
                else:
                    i += 1
            out.append(' ')
        else:
            out.append(text[i])
            i += 1
    if depth:
        raise SystemExit('Unterminated Lean comment')
    return ''.join(out)


def link_shared(shared, lock):
    """Reuse an existing exact-revision Mathlib; never copy its sources."""
    shared = shared.expanduser().resolve()
    for base in (ROOT, ROOT / 'verification/consumer'):
        directory = base / '.lake/packages'
        directory.mkdir(parents=True, exist_ok=True)
        for package in lock['packages']:
            name = package['name']
            source = shared if name == 'mathlib' else shared / '.lake/packages' / name
            target = directory / name
            if not source.is_dir():
                raise SystemExit(f'Existing dependency unavailable: {source}')
            if target.exists() or target.is_symlink():
                if target.resolve() != source:
                    raise SystemExit(f'Refusing to replace existing dependency: {target}')
            else:
                target.symlink_to(source, target_is_directory=True)


def dependencies(lock):
    actual = {}
    for package in lock['packages']:
        directory = ROOT / '.lake/packages' / package['name']
        revision = subprocess.check_output(
            ['git', '-C', str(directory), 'rev-parse', 'HEAD'], text=True).strip()
        if revision != package['rev']:
            raise SystemExit(f'Wrong dependency revision: {package["name"]}: {revision}')
        # Local reuse must not silently validate a modified standard library.
        clean = subprocess.run(['git', '-c', 'core.filemode=false', '-C', str(directory), 'diff', '--quiet', 'HEAD', '--'])
        if clean.returncode:
            raise SystemExit(f'Tracked dependency files differ from the pin: {package["name"]}')
        actual[package['name']] = revision
    return actual


def scope_check():
    manifest = json.loads((ROOT / 'verification/manuscript.json').read_text(encoding='utf-8'))
    coverage = json.loads((ROOT / 'verification/coverage.json').read_text(encoding='utf-8'))
    provenance = json.loads((ROOT / 'verification/provenance.json').read_text(encoding='utf-8'))
    source = ROOT / manifest['source']
    digest = sha(source)
    if digest != manifest['sha256'] or digest != coverage['manuscript_sha256']:
        raise SystemExit('Manuscript and coverage hashes disagree')
    if digest != provenance['bundled_manuscript_sha256']:
        raise SystemExit('Manuscript and provenance disagree')
    text = source.read_text(encoding='utf-8')
    rows = manifest['theorem_environments']
    inventory = []
    pattern = r'\\begin\{(definition|maintheorem|theorem|proposition|lemma|corollary|remark)\}(?:\[[^\]]*\])?\\label\{([^}]+)\}.*?\\end\{\1\}'
    for match in re.finditer(pattern, text, re.S):
        inventory.append({'environment': match[1], 'label': match[2],
                          'line': text.count('\n', 0, match.start()) + 1,
                          'end_line': text.count('\n', 0, match.end()) + 1,
                          'statement': match.group()})
    if inventory != rows:
        raise SystemExit('Manuscript theorem inventory changed')
    if [r['label'] for r in rows] != [r['label'] for r in coverage['labelled_results']]:
        raise SystemExit('Coverage labels disagree with manuscript inventory')
    if len(rows) != 11 or len(coverage['additional_obligations']) != 5:
        raise SystemExit('Expected 11 labelled items and five additional obligations')
    if coverage['remaining_gaps'] != []:
        raise SystemExit('The coverage ledger has outstanding gaps')
    for row in coverage['labelled_results']:
        if row['proof_status'] not in {'PROVED', 'DEFINITION', 'CITED_RESULT'}:
            raise SystemExit(f'Unclosed coverage item: {row["label"]}')
    if any(r['proof_status'] != 'PROVED' for r in coverage['additional_obligations']):
        raise SystemExit('Unclosed additional obligation')
    for name, record in provenance['source_modules_copied_byte_for_byte'].items():
        if sha(ROOT / name) != record['sha256']:
            raise SystemExit(f'Original proof source changed: {name}')
    prior = text
    for change in reversed(provenance['authorized_manuscript_corrections']):
        if prior.count(change['after']) != 1:
            raise SystemExit('Manuscript correction provenance does not match')
        prior = prior.replace(change['after'], change['before'], 1)
    if hashlib.sha256(prior.encode()).hexdigest() != provenance['source_reviewed_manuscript_sha256']:
        raise SystemExit('Reviewed manuscript provenance does not match')
    # Each ledger declaration is compiled in the checked reference file.
    references = (ROOT / 'Checks/CoverageReferences.lean').read_text(encoding='utf-8')
    checked = set(re.findall(r'^#check\s+(\S+)', references, re.M))
    for row in coverage['labelled_results'] + coverage['additional_obligations']:
        names = row.get('lean_sources', row.get('lean', '')).split(';')
        for name in names:
            name = name.strip()
            if name not in checked:
                raise SystemExit(f'Coverage declaration is not compiler checked: {name}')
    return digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mathlib', type=Path, help='reuse an existing exact-revision Mathlib checkout')
    parser.add_argument('--jobs', type=int, default=3, help='parallel post-build checks (default: 3)')
    parser.add_argument('--timeout', type=int, default=1800, help='seconds allowed per command')
    args = parser.parse_args()
    if args.jobs < 1 or args.timeout < 1:
        parser.error('--jobs and --timeout must be positive')
    # Ignore filesystem execute-bit differences in reused cloud checkouts.
    # This changes only this process environment; source bytes are still checked.
    config_index = int(os.environ.get('GIT_CONFIG_COUNT', '0'))
    os.environ['GIT_CONFIG_COUNT'] = str(config_index + 1)
    os.environ[f'GIT_CONFIG_KEY_{config_index}'] = 'core.filemode'
    os.environ[f'GIT_CONFIG_VALUE_{config_index}'] = 'false'
    lock = json.loads((ROOT / 'lake-manifest.json').read_text(encoding='utf-8'))
    if args.mathlib:
        link_shared(args.mathlib, lock)
    # Resolve Lake configuration before the frozen run. Dependency installation
    # and optional `lake exe cache get` should precede verification (README).
    for base in (ROOT, ROOT / 'verification/consumer'):
        subprocess.run(['lake', 'env', 'lean', '--version'], cwd=base, check=True,
                       timeout=args.timeout, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    lean_version = subprocess.check_output(['lake', 'env', 'lean', '--version'], cwd=ROOT, text=True).strip()
    if not re.search(r'Lean \(version 4\.33\.0(?:,|\))', lean_version):
        raise SystemExit(f'Wrong Lean compiler: {lean_version}')
    expected = json.loads((ROOT / 'verification/inputs.json').read_text(encoding='utf-8'))
    if inputs() != expected:
        raise SystemExit('Package inputs do not match verification/inputs.json')
    frozen = snapshot()
    revisions = dependencies(lock)
    manuscript_hash = scope_check()
    lean_files = [name for name in expected if name.endswith('.lean')]
    allowed_axiom_files = {'BraidGroup/Literature.lean', 'BraidGroup/SphericalLiterature.lean', 'DCPv7/Literature.lean'}
    for name in lean_files:
        code = lean_code((ROOT / name).read_text(encoding='utf-8'))
        if re.search(r'\b(sorry|admit|unsafe|native_decide)\b', code):
            raise SystemExit(f'Forbidden proof escape: {name}')
        if name not in allowed_axiom_files and re.search(r'\baxiom\b', code):
            raise SystemExit(f'Unexpected axiom declaration: {name}')
    logs = ROOT / 'verification/logs'
    logs.mkdir(parents=True, exist_ok=True)

    def run(name, argv, cwd=ROOT):
        path = logs / (name + '.log')
        try:
            result = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, timeout=args.timeout,
                                    encoding='utf-8')
        except subprocess.TimeoutExpired as error:
            output = error.stdout or b''
            if isinstance(output, bytes):
                output = output.decode('utf-8', errors='replace')
            path.write_text(output, encoding='utf-8')
            raise RuntimeError(f'{name} timed out; see {path.relative_to(ROOT)}') from None
        path.write_text(result.stdout, encoding='utf-8')
        if result.returncode:
            raise RuntimeError(f'{name} failed; see {path.relative_to(ROOT)}\n{result.stdout[-8000:]}')
        if name in {'ComponentAxiomAudit', 'LibraryAxiomAudit', 'DCPv7AxiomAudit'}:
            if not result.stdout.startswith('Audited '):
                raise RuntimeError(f'{name} did not report its completed audit')
        print(f'{name}: passed', flush=True)
        return result.stdout.strip()

    run('build', ['lake', 'build', '--wfail', 'DCPv7'])
    failures, summaries = [], {}
    tasks = [(name, ['lake', 'env', 'lean', '-DwarningAsError=true', f'Checks/{name}.lean'], ROOT)
             for name in CHECKS]
    tasks.append(('consumer', ['lake', 'build', '--wfail', 'Consumer'], ROOT / 'verification/consumer'))
    with ThreadPoolExecutor(max_workers=args.jobs) as executor:
        futures = {executor.submit(run, name, argv, cwd): name for name, argv, cwd in tasks}
        for future in as_completed(futures):
            try:
                summaries[futures[future]] = future.result()
            except Exception as error:
                failures.append(str(error))
    if failures:
        raise SystemExit('\n'.join(sorted(failures)))
    if snapshot() != frozen:
        raise SystemExit('Package inputs changed during verification; rerun')
    if dependencies(lock) != revisions:
        raise SystemExit('Dependency revisions changed during verification')
    report = {
        'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'formal_verification_status': 'COMPLETE_MODULO_CITED_RESULTS',
        'manuscript_source_sha256': manuscript_hash,
        'manuscript_manifest_sha256': sha(ROOT / 'verification/manuscript.json'),
        'lean_version': lean_version,
        'dependency_revisions': revisions,
        'package_input_sha256': expected,
        'input_manifest_sha256': sha(ROOT / 'verification/inputs.json'),
        'custom_source_modules': 75,
        'labelled_manuscript_items': 11,
        'additional_obligations': 5,
        'used_literature_inputs': 20,
        'standard_foundations': ['propext', 'Classical.choice', 'Quot.sound'],
        'checks_passed': ['warning-as-error build', 'proof-escape scan', 'exact manuscript inventory and provenance',
                          'coverage references checked by Lean', 'all custom-declaration axiom allowlist',
                          'all v7-origin declarations audited; old direct spherical algorithms forbidden',
                          'independent components use no custom axioms', 'full Mathlib in both import orders',
                          'separate Lake consumer', 'pre/post input inventory and identity freeze',
                          'exact dependency revisions and unchanged tracked file contents'],
        'axiom_audit_summary': summaries['DCPv7AxiomAudit'],
    }
    # Publish only after all workers have joined and the final guards passed.
    temporary = ROOT / 'verification/result.json.tmp'
    temporary.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    temporary.replace(ROOT / 'verification/result.json')
    print('COMPLETE_MODULO_CITED_RESULTS; receipt: verification/result.json', flush=True)


if __name__ == '__main__':
    main()
