import DCPv7.MainSearch
import DCPv7.VerifiedSpherical
import DCPv7.ProductPaperSearch
import DCPv7.EffectiveReduction
import DCPv7.AssemblyCost

/-! The principal decision/search conclusions of the fixed DCPv7 manuscript.
See the exact-hash coverage ledger for every labelled and unlabelled result.
-/
namespace DCPv7.VerifiedManuscript
noncomputable section

theorem braid_main : ∃ d : DCPVerification.Input → Bool,
    ∃ s : DCPVerification.Input → Part DCPVerification.Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, DCPVerification.ValidInput p →
      (d p = true ↔ DCPVerification.Positive p) ∧ (d p = true → (s p).Dom) ∧
      ∀ w ∈ s p, DCPVerification.Witness p w := MainSearch.main_theorem

theorem constrained_main : ∃ d : DCPVerification.Constraints.Input → Bool,
    ∃ s : DCPVerification.Constraints.Input → Part DCPVerification.Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, DCPVerification.Constraints.ValidInput p →
      (d p = true ↔ DCPVerification.Constraints.Positive p) ∧ (d p = true → (s p).Dom) ∧
      ∀ w ∈ s p, DCPVerification.Constraints.Witness p w := ConstrainedSearch.main_theorem

theorem spherical_main : ∃ d : DCPVerification.SphericalDecision.Input → Bool,
    ∃ s : DCPVerification.SphericalDecision.Input → Part DCPVerification.SphericalDecision.Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, DCPVerification.SphericalDecision.ValidInput p →
      (d p = true ↔ DCPVerification.SphericalDecision.Positive p) ∧ (d p = true → (s p).Dom) ∧
      ∀ w ∈ s p, DCPVerification.SphericalDecision.Witness p w := VerifiedSpherical.main_theorem

theorem product_main : ∃ d : ProductEncoding.Input → Bool,
    ∃ s : ProductEncoding.Input → Part ProductEncoding.Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, ProductEncoding.PaperValidInput p →
      (d p = true ↔ ProductEncoding.Positive ProductEncoding.FactorGroup ProductEncoding.factorValue p) ∧
      (d p = true → (s p).Dom) ∧
      ∀ w ∈ s p, ProductEncoding.Witness ProductEncoding.FactorGroup ProductEncoding.factorValue p w :=
  ProductEncoding.paper_product_main_theorem VerifiedSpherical.algorithms

end
end DCPv7.VerifiedManuscript
