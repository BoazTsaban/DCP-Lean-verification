import DCPv7.SphericalAlgorithms
import DCPv7.SignedSearch
import DCPVerification.SphericalSearch

/-! The spherical proof relative to supplied algorithms. The ambient algebra,
the two exact conjugacy families, and the supplied-generator word search follow
the manuscript. The three direct spherical algorithm axioms are not used.
-/
namespace DCPv7.SphericalWithAlgorithms
open BraidGroup GroupDCP FiniteArtinGroup
open DCPVerification.SphericalDecision
open SphericalAlgorithms

abbrev Input := DCPVerification.SphericalDecision.Input
abbrev Candidate := DCPVerification.SphericalDecision.Candidate
abbrev ValidInput := DCPVerification.SphericalDecision.ValidInput
abbrev Positive := DCPVerification.SphericalDecision.Positive
abbrev Witness := DCPVerification.SphericalDecision.Witness

def reductionInstance (alg : Algorithms) (p : Input) : RawInstance := rawAssembly
  ((alg.centralizer (ambient p, leftWords p), alg.centralizer (ambient p, rightWords p)),
    (sourceWord p, targetWord p))

def decision (alg : Algorithms) (p : Input) : Bool :=
  alg.simultaneous (ambient p, reductionInstance alg p)

theorem reduction_correct (alg : Algorithms) (p : Input) (hp : ValidInput p) :
    InstanceSolvable (ambient p) (reductionInstance alg p) ↔ Positive p := by
  rcases hp with ⟨hXY, _, hY, hAs, hBs, hg, hh, hA, hB⟩
  let X := source p
  let Y := ambient p
  let f := FiniteArtinGroup.Literature.embedding X Y hXY
  let A := FiniteArtinGroup.rawSubgroup X (leftWords p)
  let B := FiniteArtinGroup.rawSubgroup X (rightWords p)
  have hle : X.2 + 1 ≤ Y.2 + 1 := Nat.add_le_add_right (ranks_le X Y hXY) 1
  have hAm := rawSubgroup_map X Y hXY (leftWords p) hAs
  have hBm := rawSubgroup_map X Y hXY (rightWords p) hBs
  have hcs := alg.centralizer_spec Y hY (leftWords p)
    (fun w hw => rawValid_mono hle (hAs w hw))
  have hds := alg.centralizer_spec Y hY (rightWords p)
    (fun w hw => rawValid_mono hle (hBs w hw))
  have he := DCPVerification.Spherical.reduction X Y hXY A B hA hB
    ((alg.centralizer (Y, leftWords p)).map (FiniteArtinGroup.rawEval Y))
    ((alg.centralizer (Y, rightWords p)).map (FiniteArtinGroup.rawEval Y))
    (by simpa only [A, hAm] using hcs.2)
    (by simpa only [B, hBm] using hds.2)
    (FiniteArtinGroup.rawEval X (sourceWord p)) (FiniteArtinGroup.rawEval X (targetWord p))
  rw [FiniteArtinGroup.Literature.embedding_word X Y hXY _ hg,
    FiniteArtinGroup.Literature.embedding_word X Y hXY _ hh] at he
  rw [reductionInstance, rawAssembly_solvable_iff]
  exact he

theorem reduction_valid (alg : Algorithms) (p : Input) (hp : ValidInput p) :
    InstanceValid (ambient p) (reductionInstance alg p) := by
  rcases hp with ⟨hXY, _, hY, hAs, hBs, hg, hh, _, _⟩
  have hle := Nat.add_le_add_right (ranks_le _ _ hXY) 1
  exact rawAssembly_valid ((ambient p).2 + 1) _ _ _ _
    (alg.centralizer_spec _ hY _ (fun w hw => rawValid_mono hle (hAs w hw))).1
    (alg.centralizer_spec _ hY _ (fun w hw => rawValid_mono hle (hBs w hw))).1
    (rawValid_mono hle hg) (rawValid_mono hle hh)

theorem decision_correct (alg : Algorithms) (p : Input) (hp : ValidInput p) :
    decision alg p = true ↔ Positive p :=
  (alg.simultaneous_spec _ hp.2.2.1 _ (reduction_valid alg p hp)).trans (reduction_correct alg p hp)

theorem reductionInstance_computable (alg : Algorithms) : Computable (reductionInstance alg) := by
  have hl : Computable (fun p : Input => alg.centralizer (ambient p, leftWords p)) :=
    alg.centralizer_computable.comp (ambient_primrec.to_comp.pair leftWords_primrec.to_comp)
  have hr : Computable (fun p : Input => alg.centralizer (ambient p, rightWords p)) :=
    alg.centralizer_computable.comp (ambient_primrec.to_comp.pair rightWords_primrec.to_comp)
  exact rawAssembly_primrec.to_comp.comp
    ((hl.pair hr).pair (sourceWord_primrec.to_comp.pair targetWord_primrec.to_comp))

theorem decision_computable (alg : Algorithms) : Computable (decision alg) :=
  alg.simultaneous_computable.comp (ambient_primrec.to_comp.pair (reductionInstance_computable alg))

def candidateTest (alg : Algorithms) (p : Input) (w : Candidate) : Bool :=
  if CandidateValid p w then alg.word (source p, (targetWord p, expandedCandidate p w)) else false

theorem candidateTest_correct (alg : Algorithms) (p : Input) (hp : ValidInput p) (w : Candidate) :
    candidateTest alg p w = true ↔ Witness p w := by
  by_cases hv : CandidateValid p w
  · have hsA := hp.2.2.2.1
    have hsB := hp.2.2.2.2.1
    have hg := hp.2.2.2.2.2.1
    have hh := hp.2.2.2.2.2.2.1
    have hex : RawValid ((source p).2 + 1) (expandedCandidate p w) := by
      exact (rawValid_append _ _ _).mpr ⟨(rawValid_append _ _ _).mpr
        ⟨substitute_valid _ _ hsA _ hv.1, hg⟩, substitute_valid _ _ hsB _ hv.2⟩
    simp only [candidateTest, DCPVerification.SphericalDecision.Witness, hv, if_true, true_and]
    rw [alg.word_spec _ hp.2.1 _ _ hh hex]
    simp only [expandedCandidate, FiniteArtinGroup.rawEval_append, mul_assoc]
  · simp [candidateTest, DCPVerification.SphericalDecision.Witness, hv]

theorem candidateTest_computable (alg : Algorithms) : Computable₂ (candidateTest alg) := by
  have ht : Computable (fun q : Input × Candidate =>
      alg.word (source q.1, (targetWord q.1, expandedCandidate q.1 q.2))) :=
    alg.word_computable.comp ((source_primrec.comp Primrec.fst).to_comp.pair
      ((targetWord_primrec.comp Primrec.fst).to_comp.pair expandedCandidate_primrec.to_comp))
  exact (Computable.cond candidateValid_primrec.decide.to_comp ht (Computable.const false)).of_eq
    (fun q => by simp only [Bool.cond_decide]; rfl)

def search (alg : Algorithms) : Input → Part Candidate := SignedSearch.run
  (fun p => (leftWords p).length) (fun p => (rightWords p).length) (candidateTest alg)

theorem search_partrec (alg : Algorithms) : Partrec (search alg) :=
  SignedSearch.run_partrec _ _ _
    (Primrec.list_length.comp leftWords_primrec).to_comp
    (Primrec.list_length.comp rightWords_primrec).to_comp (candidateTest_computable alg)

theorem search_sound (alg : Algorithms) (p : Input) (hp : ValidInput p) (w : Candidate)
    (hw : w ∈ search alg p) : Witness p w :=
  (candidateTest_correct alg p hp w).mp (SignedSearch.run_sound _ _ _ p w hw).2.2

theorem search_terminates_iff (alg : Algorithms) (p : Input) (hp : ValidInput p) :
    (search alg p).Dom ↔ Positive p := by
  rw [search, SignedSearch.run_dom]
  constructor
  · rintro ⟨w, _, _, ht⟩
    exact (positive_iff_witness p).mpr ⟨w, (candidateTest_correct alg p hp w).mp ht⟩
  · intro h
    obtain ⟨w, hw⟩ := (positive_iff_witness p).mp h
    exact ⟨w, hw.1.1, hw.1.2, (candidateTest_correct alg p hp w).mpr hw⟩

theorem main_theorem (alg : Algorithms) : ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, ValidInput p →
      (d p = true ↔ Positive p) ∧ (d p = true → (s p).Dom) ∧
        ∀ w ∈ s p, Witness p w :=
  ⟨decision alg, search alg, decision_computable alg, search_partrec alg, fun p hp =>
    ⟨decision_correct alg p hp, fun h => (search_terminates_iff alg p hp).mpr
      ((decision_correct alg p hp).mp h), search_sound alg p hp⟩⟩

end DCPv7.SphericalWithAlgorithms
