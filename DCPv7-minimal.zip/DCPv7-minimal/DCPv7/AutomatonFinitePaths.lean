import DCPv7.Automaton
import DCPv7.LengthEnumeration
import Mathlib.Computability.DFA

/-! Finite reachability and the explicit trimming paths in `lem:biautomatic`.
Removing a repeated-state loop gives a path shorter than the state count.
Consequently both the trimming test and the chosen prefixes/suffixes use a
finite list of words. No reachability oracle is assumed.
-/
namespace DCPv7.WordAutomaton

variable {α Q : Type} (M : WordAutomaton α Q)

def toDFA : DFA α Q := ⟨M.step, M.start, M.accept⟩

theorem evalFrom_toDFA (q : Q) (w : List α) :
    M.toDFA.evalFrom q w = M.evalFrom q w := by
  induction w generalizing q with
  | nil => rfl
  | cons a w ih => exact ih (M.step q a)

variable [Fintype Q]

theorem short_path (A : List α) (q : Q) (w : List α) (hw : ∀ a ∈ w, a ∈ A) :
    ∃ v : List α, v.length < Fintype.card Q ∧
      M.evalFrom q v = M.evalFrom q w ∧ ∀ a ∈ v, a ∈ A := by
  suffices ∀ n, ∀ w : List α, w.length = n → (∀ a ∈ w, a ∈ A) →
      ∃ v : List α, v.length < Fintype.card Q ∧
        M.evalFrom q v = M.evalFrom q w ∧ ∀ a ∈ v, a ∈ A from
    this w.length w rfl hw
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    intro w hn hA
    by_cases hshort : w.length < Fintype.card Q
    · exact ⟨w, hshort, rfl, hA⟩
    · obtain ⟨r, a, b, c, he, _, hb, ha, hloop, hc⟩ :=
        M.toDFA.evalFrom_split (s := q) (t := M.toDFA.evalFrom q w)
          (Nat.le_of_not_gt hshort) rfl
      have hlen : (a ++ c).length < n := by
        have hbpos : 0 < b.length := List.length_pos_iff.mpr hb
        rw [he, List.length_append, List.length_append] at hn
        simp only [List.length_append]
        omega
      have hAc : ∀ x ∈ a ++ c, x ∈ A := by
        intro x hx
        apply hA x
        rw [he]
        simp only [List.mem_append] at hx ⊢
        exact hx.elim (fun h => Or.inl (Or.inl h)) Or.inr
      obtain ⟨v, hv, heval, hletters⟩ := ih (a ++ c).length hlen (a ++ c) rfl hAc
      refine ⟨v, hv, heval.trans ?_, hletters⟩
      rw [← M.evalFrom_toDFA, M.toDFA.evalFrom_of_append, ha, hc]
      exact M.evalFrom_toDFA q w

def boundedWords (A : List α) (n : Nat) : List (List α) :=
  (List.range n).flatMap (LengthEnumeration.words A)

theorem mem_boundedWords (A : List α) (n : Nat) (w : List α) :
    w ∈ boundedWords A n ↔ w.length < n ∧ ∀ a ∈ w, a ∈ A := by
  simp only [boundedWords, List.mem_flatMap, List.mem_range, LengthEnumeration.mem_words]
  constructor
  · rintro ⟨k, hk, hlen, hA⟩
    exact ⟨by omega, hA⟩
  · rintro ⟨hk, hA⟩
    exact ⟨w.length, hk, rfl, hA⟩

variable [DecidableEq Q] [DecidablePred M.accept]

def prefixPath (A : List α) (q : Q) : Option (List α) :=
  LengthEnumeration.first (fun w => decide (M.evalFrom M.start w = q))
    (boundedWords A (Fintype.card Q))

def suffixPath (A : List α) (q : Q) : Option (List α) :=
  LengthEnumeration.first (fun w => decide (M.accept (M.evalFrom q w)))
    (boundedWords A (Fintype.card Q))

def nonemptyDecision (A : List α) : Bool := (M.suffixPath A M.start).isSome

omit [DecidablePred M.accept] in
theorem prefixPath_sound (A : List α) (q : Q) (w : List α)
    (hw : M.prefixPath A q = some w) : M.evalFrom M.start w = q := by
  exact of_decide_eq_true (LengthEnumeration.first_sound _ _ _ hw).2

omit [DecidableEq Q] in
theorem suffixPath_sound (A : List α) (q : Q) (w : List α)
    (hw : M.suffixPath A q = some w) : M.accept (M.evalFrom q w) := by
  exact of_decide_eq_true (LengthEnumeration.first_sound _ _ _ hw).2

variable (A : List α) (hA : ∀ a : α, a ∈ A)

include hA in
omit [DecidablePred M.accept] in
theorem prefixPath_exists (q : Q) (hq : M.Useful q) : ∃ w, M.prefixPath A q = some w := by
  obtain ⟨p, _, hp, _⟩ := hq
  obtain ⟨v, hv, he, hletters⟩ := M.short_path A M.start p (fun a _ => hA a)
  apply (LengthEnumeration.first_terminates _ _).mpr
  exact ⟨v, (mem_boundedWords A _ v).mpr ⟨hv, hletters⟩, by simp [he, hp]⟩

include hA in
omit [DecidableEq Q] in
theorem suffixPath_exists (q : Q) (hq : M.Useful q) : ∃ w, M.suffixPath A q = some w := by
  obtain ⟨_, t, _, ht⟩ := hq
  obtain ⟨v, hv, he, hletters⟩ := M.short_path A q t (fun a _ => hA a)
  apply (LengthEnumeration.first_terminates _ _).mpr
  exact ⟨v, (mem_boundedWords A _ v).mpr ⟨hv, hletters⟩, by simpa [he] using ht⟩

include hA in
omit [DecidableEq Q] in
theorem nonemptyDecision_correct :
    M.nonemptyDecision A = true ↔ ∃ w, M.Accepts w := by
  simp only [nonemptyDecision, Option.isSome_iff_exists]
  constructor
  · rintro ⟨w, hw⟩
    exact ⟨w, M.suffixPath_sound A M.start w hw⟩
  · rintro ⟨w, hw⟩
    exact M.suffixPath_exists A hA M.start (M.useful_start hw)

def trimmed (q : Q) : Bool := (M.prefixPath A q).isSome && (M.suffixPath A q).isSome

include hA in
theorem trimmed_iff (q : Q) : M.trimmed A q = true ↔ M.Useful q := by
  simp only [trimmed, Bool.and_eq_true, Option.isSome_iff_exists]
  constructor
  · rintro ⟨⟨p, hp⟩, ⟨t, ht⟩⟩
    exact ⟨p, t, M.prefixPath_sound A q p hp, M.suffixPath_sound A q t ht⟩
  · intro hq
    exact ⟨M.prefixPath_exists A hA q hq, M.suffixPath_exists A hA q hq⟩

def finiteTrimPaths : M.TrimPaths where
  prefixWord q := if q = M.start then [] else (M.prefixPath A q).getD []
  suffixWord q := (M.suffixPath A q).getD []
  prefix_start := by simp
  prefix_spec q hq := by
    by_cases he : q = M.start
    · simp [he, evalFrom]
    · obtain ⟨w, hw⟩ := M.prefixPath_exists A hA q hq
      simpa only [if_neg he, hw, Option.getD_some] using M.prefixPath_sound A q w hw
  suffix_spec q hq := by
    obtain ⟨w, hw⟩ := M.suffixPath_exists A hA q hq
    simpa only [hw, Option.getD_some] using M.suffixPath_sound A q w hw

end DCPv7.WordAutomaton
