import DCPv7.VerifiedBiautomatic
import DCPv7.DerivedSphericalAlgorithms
import DCPv7.SphericalWithAlgorithms

/-! The actual spherical algorithms are derived from the proved biautomatic
lemma and Charney's cited theorem, not the inherited direct algorithm axioms. -/
namespace DCPv7.VerifiedSpherical
noncomputable section

def algorithms : SphericalAlgorithms.Algorithms :=
  DerivedSphericalAlgorithms.ofBiautomatic VerifiedBiautomatic.algorithms
    Literature.Ch92_spherical_biautomatic

theorem main_theorem : ∃ d : DCPVerification.SphericalDecision.Input → Bool,
    ∃ s : DCPVerification.SphericalDecision.Input → Part DCPVerification.SphericalDecision.Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, DCPVerification.SphericalDecision.ValidInput p →
      (d p = true ↔ DCPVerification.SphericalDecision.Positive p) ∧
      (d p = true → (s p).Dom) ∧
      ∀ w ∈ s p, DCPVerification.SphericalDecision.Witness p w :=
  SphericalWithAlgorithms.main_theorem algorithms

end
end DCPv7.VerifiedSpherical
