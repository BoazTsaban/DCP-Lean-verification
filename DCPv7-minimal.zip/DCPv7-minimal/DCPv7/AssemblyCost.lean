import DCPVerification.Complexity
import Mathlib.Tactic.Linarith

/-! Explicit word assembly, with a linked-list operation count. Each letter,
list cell, Boolean sign operation and pair construction has unit cost. This
counts the assembly after the two centralizer lists have been computed.
It does not assert a bound for the centralizer or conjugacy algorithms.
-/
namespace DCPv7.AssemblyCost
open BraidGroup DCPVerification

def append (u v : RawWord) : RawWord × Nat := (u ++ v, u.length + 1)

def inverse (w : RawWord) : RawWord × Nat := (rawInverse w, 2 * w.length + 2)

def conjugate (w v : RawWord) : RawWord × Nat :=
  let a := append w v
  let b := inverse w
  let c := append a.1 b.1
  (c.1, a.2 + b.2 + c.2 + 1)

@[simp] theorem conjugate_value (w v : RawWord) : (conjugate w v).1 = rawConjugate w v := rfl

@[simp] theorem conjugate_cost (w v : RawWord) :
    (conjugate w v).2 = 4 * w.length + v.length + 5 := by
  simp [conjugate, append, inverse]
  omega

def leftFamily : List RawWord → RawInstance × Nat
  | [] => ([], 1)
  | u :: c =>
    let tail := leftFamily c
    ((u, u) :: tail.1, tail.2 + 2)

def rightFamily (g h : RawWord) : List RawWord → RawInstance × Nat
  | [] => ([], 1)
  | v :: d =>
    let a := conjugate h v
    let b := conjugate g v
    let tail := rightFamily g h d
    ((a.1, b.1) :: tail.1, a.2 + b.2 + tail.2 + 2)

@[simp] theorem leftFamily_value (c : List RawWord) :
    (leftFamily c).1 = c.map (fun u => (u, u)) := by
  induction c with
  | nil => rfl
  | cons u c ih => simpa only [leftFamily, List.map_cons] using congrArg ((u, u) :: ·) ih

@[simp] theorem leftFamily_cost (c : List RawWord) :
    (leftFamily c).2 = 2 * c.length + 1 := by
  induction c with
  | nil => rfl
  | cons u c ih => simp only [leftFamily, List.length_cons]; rw [ih]; omega

@[simp] theorem rightFamily_value (g h : RawWord) (d : List RawWord) :
    (rightFamily g h d).1 = d.map (fun v => (rawConjugate h v, rawConjugate g v)) := by
  induction d with
  | nil => rfl
  | cons v d ih => simp only [rightFamily, conjugate_value, List.map_cons, ih]

@[simp] theorem rightFamily_cost (g h : RawWord) (d : List RawWord) :
    (rightFamily g h d).2 =
      4 * d.length * (g.length + h.length) + 2 * wordsLength d + 12 * d.length + 1 := by
  induction d with
  | nil => simp [rightFamily, wordsLength]
  | cons v d ih =>
    simp only [rightFamily, conjugate_cost, List.length_cons]
    rw [ih]
    simp only [wordsLength, List.map_cons, List.sum_cons]
    ring

def assembly (c d : List RawWord) (g h : RawWord) : RawInstance × Nat :=
  let a := leftFamily c
  let b := rightFamily g h d
  (a.1 ++ b.1, a.2 + b.2 + a.1.length + 2)

theorem assembly_value (c d : List RawWord) (g h : RawWord) :
    (assembly c d g h).1 = rawAssembly ((c, d), (g, h)) := by
  simp only [assembly, leftFamily_value, rightFamily_value, rawAssembly]

theorem assembly_cost (c d : List RawWord) (g h : RawWord) :
    (assembly c d g h).2 = 3 * c.length + 2 * wordsLength d + 12 * d.length + 4 +
      4 * d.length * (g.length + h.length) := by
  simp only [assembly, leftFamily_cost, rightFamily_cost, leftFamily_value, List.length_map]
  ring

theorem size_linear (c d : List RawWord) (g h : RawWord) :
    instanceLength (rawAssembly ((c, d), (g, h))) ≤
      (2 * wordsLength c + 2 * wordsLength d + 2 * d.length) *
        (1 + g.length + h.length) := by
  rw [rawAssembly_length]
  nlinarith [Nat.zero_le (wordsLength c * (g.length + h.length)),
    Nat.zero_le (wordsLength d * (g.length + h.length))]

theorem assembly_time_linear (c d : List RawWord) (g h : RawWord) :
    (assembly c d g h).2 ≤
      (3 * c.length + 2 * wordsLength d + 16 * d.length + 4) *
        (1 + g.length + h.length) := by
  rw [assembly_cost]
  nlinarith [Nat.zero_le (c.length * (g.length + h.length)),
    Nat.zero_le (wordsLength d * (g.length + h.length))]

end DCPv7.AssemblyCost
