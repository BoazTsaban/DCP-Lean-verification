import DCPVerification.Main
import BraidGroup.SubgroupWords

/-! General word-level effectiveness of Proposition `prop:ambient-reduction`.
The inclusion is a supplied finite list of ambient words. It is applied by
literal substitution before computing both ambient centralizers and assembling
the paper's two conjugacy families.
-/
namespace DCPv7.EffectiveReduction
open BraidGroup GroupDCP

abbrev Input := (List RawWord × List RawWord) × (RawWord × RawWord)

def includedInput (images : List RawWord) (p : Input) : Input :=
  ((p.1.1.map (substitute images), p.1.2.map (substitute images)),
    (substitute images p.2.1, substitute images p.2.2))

def reduction (centralizer : List RawWord → List RawWord)
    (images : List RawWord) (p : Input) : RawInstance :=
  let q := includedInput images p
  rawAssembly ((centralizer q.1.1, centralizer q.1.2), q.2)

theorem includedInput_primrec : Primrec₂ includedInput := by
  have hs : Primrec₂ (fun images : List RawWord => fun s : List RawWord =>
      s.map (substitute images)) :=
    Primrec.list_map Primrec.snd
      (Primrec.to₂ (substitute_primrec.comp (Primrec.fst.comp Primrec.fst) Primrec.snd))
  have hL : Primrec (fun q : List RawWord × Input => q.2.1.1.map (substitute q.1)) :=
    hs.comp Primrec.fst (Primrec.fst.comp (Primrec.fst.comp Primrec.snd))
  have hR : Primrec (fun q : List RawWord × Input => q.2.1.2.map (substitute q.1)) :=
    hs.comp Primrec.fst (Primrec.snd.comp (Primrec.fst.comp Primrec.snd))
  have hg : Primrec (fun q : List RawWord × Input => substitute q.1 q.2.2.1) :=
    substitute_primrec.comp Primrec.fst (Primrec.fst.comp (Primrec.snd.comp Primrec.snd))
  have hh : Primrec (fun q : List RawWord × Input => substitute q.1 q.2.2.2) :=
    substitute_primrec.comp Primrec.fst (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))
  exact (hL.pair hR).pair (hg.pair hh)

theorem reduction_computable (centralizer : List RawWord → List RawWord)
    (hc : Computable centralizer) : Computable₂ (reduction centralizer) := by
  have hl : Computable (fun q : List RawWord × Input =>
      centralizer (includedInput q.1 q.2).1.1) :=
    hc.comp (Computable.fst.comp (Computable.fst.comp includedInput_primrec.to_comp))
  have hr : Computable (fun q : List RawWord × Input =>
      centralizer (includedInput q.1 q.2).1.2) :=
    hc.comp (Computable.snd.comp (Computable.fst.comp includedInput_primrec.to_comp))
  exact rawAssembly_primrec.to_comp.comp
    ((hl.pair hr).pair (Computable.snd.comp includedInput_primrec.to_comp))

variable {G : Type} [Group G]

structure Evaluation where
  value : RawWord → G
  append : ∀ u v, value (u ++ v) = value u * value v
  inverse : ∀ w, value (rawInverse w) = (value w)⁻¹

theorem Evaluation.conjugate (ev : Evaluation (G := G)) (u v : RawWord) :
    ev.value (rawConjugate u v) = ev.value u * ev.value v * (ev.value u)⁻¹ := by
  simp only [rawConjugate, ev.append, ev.inverse]

def Solvable (ev : Evaluation (G := G)) (e : RawInstance) : Prop :=
  ∃ x : G, ∀ uv ∈ e, x⁻¹ * ev.value uv.1 * x = ev.value uv.2

theorem assembly_solvable_iff (ev : Evaluation (G := G))
    (c d : List RawWord) (g h : RawWord) :
    Solvable ev (rawAssembly ((c, d), (g, h))) ↔
      ∃ x, Solves (c.map ev.value) (d.map ev.value) (ev.value g) (ev.value h) x := by
  constructor
  · rintro ⟨x, hx⟩
    refine ⟨x, ?_, ?_⟩
    · intro u hu
      obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hu
      exact hx (w, w) (List.mem_append.mpr (Or.inl (List.mem_map.mpr ⟨w, hw, rfl⟩)))
    · intro v hv
      obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hv
      have he := hx (rawConjugate h w, rawConjugate g w)
        (List.mem_append.mpr (Or.inr (List.mem_map.mpr ⟨w, hw, rfl⟩)))
      simpa only [ev.conjugate] using he
  · rintro ⟨x, hc, hd⟩
    refine ⟨x, ?_⟩
    intro uv huv
    simp only [rawAssembly, List.mem_append, List.mem_map] at huv
    rcases huv with ⟨w, hw, rfl⟩ | ⟨w, hw, rfl⟩
    · exact hc _ (List.mem_map.mpr ⟨w, hw, rfl⟩)
    · simpa only [ev.conjugate] using hd _ (List.mem_map.mpr ⟨w, hw, rfl⟩)

theorem reduction_correct (ev : Evaluation (G := G))
    (centralizer : List RawWord → List RawWord) (images : List RawWord) (p : Input)
    (A B H : Subgroup G) (hA : A ≤ H) (hB : B ≤ H)
    (hc : Generates ((centralizer (includedInput images p).1.1).map ev.value)
      (Subgroup.centralizer (A : Set G)))
    (hd : Generates ((centralizer (includedInput images p).1.2).map ev.value)
      (Subgroup.centralizer (B : Set G)))
    (hCA : HasDoubleCentralizer A) (hCB : HasDoubleCentralizer B)
    (hZ : Subgroup.center G ⊓ H = ⊥)
    (hg : ev.value (substitute images p.2.1) ∈ H)
    (hh : ev.value (substitute images p.2.2) ∈ H) :
    Solvable ev (reduction centralizer images p) ↔
      InDoubleCoset A B (ev.value (substitute images p.2.1))
        (ev.value (substitute images p.2.2)) := by
  rw [reduction, assembly_solvable_iff]
  exact ambient_reduction A B H hA hB _ _ hc hd hCA hCB hZ _ _ hg hh

end DCPv7.EffectiveReduction
