import DCPv7.EncodedAutomaton
import Mathlib.Computability.Primrec.List

/-! Padded pairs of words. A coordinate value zero is padding; a genuine symbol
`a` is stored as `a+1`. Projection erases padding. The compiler contract below
is an interface for a standard automata operation, not a literature axiom.
-/
namespace DCPv7.PaddedWords
set_option backward.isDefEq.respectTransparency false

abbrev Word := List Nat

def firstSymbol (a : Nat) : Option Nat :=
  if a.unpair.1 = 0 then none else some (a.unpair.1 - 1)

def secondSymbol (a : Nat) : Option Nat :=
  if a.unpair.2 = 0 then none else some (a.unpair.2 - 1)

def firstProjection (w : Word) : Word := w.filterMap firstSymbol
def secondProjection (w : Word) : Word := w.filterMap secondSymbol

def pad : Word → Word → Word
  | [], [] => []
  | a :: u, [] => Nat.pair (a + 1) 0 :: pad u []
  | [], b :: v => Nat.pair 0 (b + 1) :: pad [] v
  | a :: u, b :: v => Nat.pair (a + 1) (b + 1) :: pad u v
termination_by u v => u.length + v.length

@[simp] theorem firstProjection_nil : firstProjection [] = [] := rfl
@[simp] theorem secondProjection_nil : secondProjection [] = [] := rfl

@[simp] theorem firstProjection_cons_positive (a b : Nat) (w : Word) :
    firstProjection (Nat.pair (a + 1) b :: w) = a :: firstProjection w := by
  simp [firstProjection, firstSymbol]

@[simp] theorem firstProjection_cons_padding (b : Nat) (w : Word) :
    firstProjection (Nat.pair 0 b :: w) = firstProjection w := by
  simp [firstProjection, firstSymbol]

@[simp] theorem secondProjection_cons_positive (a b : Nat) (w : Word) :
    secondProjection (Nat.pair a (b + 1) :: w) = b :: secondProjection w := by
  simp [secondProjection, secondSymbol]

@[simp] theorem secondProjection_cons_padding (a : Nat) (w : Word) :
    secondProjection (Nat.pair a 0 :: w) = secondProjection w := by
  simp [secondProjection, secondSymbol]

@[simp] theorem firstProjection_pad (u v : Word) : firstProjection (pad u v) = u := by
  induction u generalizing v with
  | nil =>
    induction v with
    | nil => simp [pad]
    | cons b v ih => simpa only [pad, firstProjection_cons_padding] using ih
  | cons a u ih =>
    cases v with
    | nil => simpa only [pad, firstProjection_cons_positive] using congrArg (a :: ·) (ih [])
    | cons b v => simpa only [pad, firstProjection_cons_positive] using congrArg (a :: ·) (ih v)

@[simp] theorem secondProjection_pad (u v : Word) : secondProjection (pad u v) = v := by
  induction u generalizing v with
  | nil =>
    induction v with
    | nil => simp [pad]
    | cons b v ih => simpa only [pad, secondProjection_cons_positive] using congrArg (b :: ·) ih
  | cons a u ih =>
    cases v with
    | nil => simpa only [pad, secondProjection_cons_padding] using ih []
    | cons b v => simpa only [pad, secondProjection_cons_positive] using congrArg (b :: ·) (ih v)

theorem pad_injective {u v p q : Word} (h : pad u v = pad p q) : u = p ∧ v = q :=
  ⟨by simpa only [firstProjection_pad] using congrArg firstProjection h,
   by simpa only [secondProjection_pad] using congrArg secondProjection h⟩

theorem firstSymbol_primrec : Primrec firstSymbol := by
  have hp : PrimrecPred (fun a : Nat => a.unpair.1 = 0) :=
    Primrec.eq.comp (Primrec.fst.comp Primrec.unpair) (Primrec.const 0)
  exact (Primrec.cond hp.decide (Primrec.const none)
    (Primrec.option_some.comp (Primrec.nat_sub.comp (Primrec.fst.comp Primrec.unpair)
      (Primrec.const 1)))).of_eq (fun a => by simp only [Bool.cond_decide]; rfl)

theorem firstProjection_primrec : Primrec firstProjection :=
  Primrec.listFilterMap Primrec.id (Primrec.to₂ (firstSymbol_primrec.comp Primrec.snd))

def AlphabetWord (n : Nat) (w : Word) : Prop := ∀ a ∈ w, a < n

/-- A verified implementation of first-coordinate projection and an output
alphabet restriction. Supplying this structure is an explicit proof obligation;
declaring the structure does not assume that such a compiler exists. -/
structure ProjectionCompiler where
  code : Nat × EncodedAutomaton.Code → EncodedAutomaton.Code
  computable : Computable code
  alphabet : ∀ n D, EncodedAutomaton.alphabetSize (code (n, D)) = n
  correct : ∀ n D w, (EncodedAutomaton.machine (code (n, D))).Accepts w ↔
    AlphabetWord n w ∧ ∃ t, (EncodedAutomaton.machine D).Accepts t ∧ firstProjection t = w

end DCPv7.PaddedWords
