import Std

/-! The literal increasing-total-length enumeration in Remark `rem:witnesses`.

This purely finite part is independent of Mathlib. Both alphabets may be empty.
Stage zero includes the pair of empty words. A later computability theorem can
use these exact stages, rather than replacing them by an encoding-order search.
-/
namespace DCPv7.LengthEnumeration

variable {α β : Type}

def words (alphabet : List α) : Nat → List (List α)
  | 0 => [[]]
  | n + 1 => alphabet.flatMap fun a => (words alphabet n).map (a :: ·)

theorem mem_words (alphabet : List α) (n : Nat) (w : List α) :
    w ∈ words alphabet n ↔ w.length = n ∧ ∀ a ∈ w, a ∈ alphabet := by
  induction n generalizing w with
  | zero =>
    cases w <;> simp [words]
  | succ n ih =>
    cases w with
    | nil => simp [words]
    | cons a w =>
      simp only [words, List.mem_flatMap, List.mem_map]
      constructor
      · rintro ⟨b, hb, v, hv, he⟩
        have hbw : b = a ∧ v = w := List.cons.inj he
        rcases hbw with ⟨rfl, rfl⟩
        rcases (ih v).mp hv with ⟨hlen, hall⟩
        exact ⟨by simp [hlen], by simpa using And.intro hb hall⟩
      · rintro ⟨hlen, hall⟩
        have ha : a ∈ alphabet := hall a (by simp)
        have hw : ∀ b ∈ w, b ∈ alphabet := fun b hb => hall b (by simp [hb])
        exact ⟨a, ha, w, (ih w).mpr ⟨by simpa using hlen, hw⟩, rfl⟩

def stage (A : List α) (B : List β) (n : Nat) : List (List α × List β) :=
  (List.range (n + 1)).flatMap fun k =>
    (words A k).flatMap fun u => (words B (n - k)).map fun v => (u, v)

theorem mem_stage (A : List α) (B : List β) (n : Nat) (u : List α) (v : List β) :
    (u, v) ∈ stage A B n ↔
      u.length + v.length = n ∧
      (∀ a ∈ u, a ∈ A) ∧ (∀ b ∈ v, b ∈ B) := by
  simp only [stage, List.mem_flatMap, List.mem_map, List.mem_range]
  constructor
  · rintro ⟨k, hk, x, hx, y, hy, he⟩
    have hxy : x = u ∧ y = v := Prod.mk.inj he
    rcases hxy with ⟨rfl, rfl⟩
    rcases (mem_words A k x).mp hx with ⟨hu, hA⟩
    rcases (mem_words B (n - k) y).mp hy with ⟨hv, hB⟩
    exact ⟨by omega, hA, hB⟩
  · rintro ⟨hlen, hA, hB⟩
    exact ⟨u.length, by omega, u, (mem_words A u.length u).mpr ⟨rfl, hA⟩,
      v, (mem_words B (n - u.length) v).mpr ⟨by omega, hB⟩, rfl⟩

theorem empty_pair (A : List α) (B : List β) : ([], []) ∈ stage A B 0 := by
  exact (mem_stage A B 0 [] []).mpr ⟨rfl, by simp, by simp⟩

theorem eventually_enumerated (A : List α) (B : List β) (u : List α) (v : List β)
    (hu : ∀ a ∈ u, a ∈ A) (hv : ∀ b ∈ v, b ∈ B) :
    (u, v) ∈ stage A B (u.length + v.length) :=
  (mem_stage A B _ u v).mpr ⟨rfl, hu, hv⟩

def first (test : α → Bool) : List α → Option α
  | [] => none
  | a :: s => if test a then some a else first test s

theorem first_sound (test : α → Bool) (s : List α) (a : α)
    (h : first test s = some a) : a ∈ s ∧ test a = true := by
  induction s with
  | nil => simp [first] at h
  | cons b s ih =>
    by_cases hb : test b = true
    · simp only [first, hb, ↓reduceIte, Option.some.injEq] at h
      subst a
      exact ⟨by simp, hb⟩
    · have hs : first test s = some a := by simpa [first, hb] using h
      exact ⟨List.mem_cons_of_mem b (ih hs).1, (ih hs).2⟩

theorem first_none (test : α → Bool) (s : List α) :
    first test s = none ↔ ∀ a ∈ s, test a ≠ true := by
  induction s with
  | nil => simp [first]
  | cons a s ih =>
    by_cases ha : test a = true
    · simp [first, ha]
    · simp [first, ha, ih]

theorem first_terminates (test : α → Bool) (s : List α) :
    (∃ a, first test s = some a) ↔ ∃ a ∈ s, test a = true := by
  constructor
  · rintro ⟨a, ha⟩
    exact ⟨a, (first_sound test s a ha).1, (first_sound test s a ha).2⟩
  · rintro ⟨a, ha, ht⟩
    cases he : first test s with
    | none => exact False.elim (((first_none test s).mp he a ha) ht)
    | some b => exact ⟨b, rfl⟩

/-- An indexed finite scan, suitable for the partial-recursive implementation. -/
def prefixFirst [Inhabited α] (test : α → Bool) (s : List α) : Nat → Option α
  | 0 => none
  | n + 1 => match prefixFirst test s n with
    | some a => some a
    | none => if test (s.getD n default) then some (s.getD n default) else none

theorem prefixFirst_cons [Inhabited α] (test : α → Bool) (a : α) (s : List α)
    (n : Nat) : prefixFirst test (a :: s) (n + 1) =
      if test a then some a else prefixFirst test s n := by
  induction n with
  | zero => simp [prefixFirst]
  | succ n ih =>
    change (match prefixFirst test (a :: s) (n + 1) with
      | some b => some b
      | none => if test ((a :: s).getD (n + 1) default) then
          some ((a :: s).getD (n + 1) default) else none) =
        if test a then some a else prefixFirst test s (n + 1)
    rw [ih]
    cases test a <;> rfl

theorem prefixFirst_eq_first [Inhabited α] (test : α → Bool) (s : List α) :
    prefixFirst test s s.length = first test s := by
  induction s with
  | nil => rfl
  | cons a s ih =>
    rw [List.length_cons, prefixFirst_cons, ih]
    rfl

end DCPv7.LengthEnumeration
