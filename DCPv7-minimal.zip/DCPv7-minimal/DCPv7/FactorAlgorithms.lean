import DCPv7.ProductWords
import DCPv7.SphericalWithAlgorithms
import DCPVerification.Search

/-! Concrete dispatch on the factor type/rank code. The spherical algorithms
are supplied through an explicit record, to be derived from the biautomatic
lemma. The dispatch does not use the inherited direct spherical algorithm axioms.
-/
namespace DCPv7.ProductEncoding
open BraidGroup FiniteArtinGroup
open SphericalAlgorithms
set_option backward.isDefEq.respectTransparency false

def sourceDiagram (c : FactorCode) : Diagram :=
  (⟨(c.1 - 1) % 4, Nat.mod_lt _ (by decide)⟩, c.2)

def FactorGroup : FactorCode → Type
  | (0, r) => BraidGroup r
  | (t + 1, r) => OfDiagram (sourceDiagram (t + 1, r))

instance factorGroup : ∀ c, Group (FactorGroup c)
  | (0, r) => inferInstanceAs (Group (BraidGroup r))
  | (t + 1, r) => inferInstanceAs (Group (OfDiagram (sourceDiagram (t + 1, r))))

def factorValue : ∀ c, Word → FactorGroup c
  | (0, r), w => BraidGroup.rawEval r w
  | (t + 1, r), w => FiniteArtinGroup.rawEval (sourceDiagram (t + 1, r)) w

theorem factorEvaluationLaws : EvaluationLaws FactorGroup factorValue where
  nil c := by rcases c with ⟨t, r⟩; cases t <;> rfl
  append c u v := by
    rcases c with ⟨t, r⟩
    cases t with
    | zero => exact BraidGroup.rawEval_append r u v
    | succ t => exact FiniteArtinGroup.rawEval_append (sourceDiagram (t + 1, r)) u v
  inverse c w := by
    rcases c with ⟨t, r⟩
    cases t with
    | zero => exact BraidGroup.rawEval_inverse r w
    | succ t => exact FiniteArtinGroup.rawEval_inverse (sourceDiagram (t + 1, r)) w

def evenAmbientRank (r : Nat) : Nat := if r % 2 = 0 then r + 2 else r + 1

theorem evenAmbientRank_larger (r : Nat) : r < evenAmbientRank r := by
  unfold evenAmbientRank
  split <;> omega

theorem evenAmbientRank_even (r : Nat) : Even (evenAmbientRank r) := by
  rw [even_iff_two_dvd, Nat.dvd_iff_mod_eq_zero]
  unfold evenAmbientRank
  split <;> omega

def ambientDiagram (X : Diagram) : Diagram :=
  if X.1 = 0 then (0, X.2 + 1) else
  if X.1 = 1 then (1, evenAmbientRank X.2) else (X.1, X.2 + 1)

theorem source_supported (c : FactorCode) (hc : ValidFactor c) (h : c.1 ≠ 0) :
    Supported (sourceDiagram c) := by
  rcases c with ⟨t, r⟩
  dsimp only [ValidFactor, Prod.fst, Prod.snd] at hc h
  rcases hc with ⟨ht, hr⟩ | ⟨ht, hr⟩ | ⟨ht, hr⟩ | ⟨ht, hr⟩ | ⟨ht, hr⟩
  · exact False.elim (h ht)
  · subst t
    exact Or.inl ⟨rfl, hr⟩
  · subst t
    exact Or.inr (Or.inl ⟨rfl, hr⟩)
  · subst t
    exact Or.inr (Or.inr (Or.inl ⟨rfl, hr.elim Or.inl (fun he => Or.inr (Or.inl he))⟩))
  · subst t
    exact Or.inr (Or.inr (Or.inr ⟨rfl, hr.elim Or.inl (fun he => Or.inr (Or.inl he))⟩))

theorem ambient_allowed (c : FactorCode) (hc : ValidFactor c) (h : c.1 ≠ 0) :
    AllowedEmbedding (sourceDiagram c) (ambientDiagram (sourceDiagram c)) := by
  rcases c with ⟨t, r⟩
  dsimp only [ValidFactor, Prod.fst, Prod.snd] at hc h
  rcases hc with ⟨ht, hr⟩ | ⟨ht, hr⟩ | ⟨ht, hr⟩ | ⟨ht, hr⟩ | ⟨ht, hr⟩
  · exact False.elim (h ht)
  · subst t
    exact DCPVerification.Spherical.typeB_allowed r hr
  · subst t
    exact DCPVerification.Spherical.typeD_allowed r (evenAmbientRank r) hr
      (evenAmbientRank_larger r) (evenAmbientRank_even r)
  · subst t
    rcases hr with rfl | rfl
    · exact DCPVerification.Spherical.typeE6_allowed
    · exact DCPVerification.Spherical.typeE7_allowed
  · subst t
    rcases hr with rfl | rfl
    · exact DCPVerification.Spherical.typeI25_allowed
    · exact DCPVerification.Spherical.typeH3_allowed

theorem sourceDiagram_primrec : Primrec sourceDiagram := by
  have ht : Primrec (fun c : FactorCode => (sourceDiagram c).1) :=
    Primrec.fin_val_iff.mp (Primrec.nat_mod.comp
      (Primrec.nat_sub.comp Primrec.fst (Primrec.const 1)) (Primrec.const 4))
  exact ht.pair Primrec.snd

theorem evenAmbientRank_primrec : Primrec evenAmbientRank := by
  have hp : PrimrecPred (fun r : Nat => r % 2 = 0) :=
    Primrec.eq.comp (Primrec.nat_mod.comp Primrec.id (Primrec.const 2)) (Primrec.const 0)
  exact (Primrec.cond hp.decide
    (Primrec.nat_add.comp Primrec.id (Primrec.const 2))
    (Primrec.nat_add.comp Primrec.id (Primrec.const 1))).of_eq
      (fun r => by simp only [Bool.cond_decide]; rfl)

theorem ambientDiagram_primrec : Primrec ambientDiagram := by
  have h0 : PrimrecPred (fun X : Diagram => X.1 = 0) :=
    Primrec.eq.comp Primrec.fst (Primrec.const 0)
  have h1 : PrimrecPred (fun X : Diagram => X.1 = 1) :=
    Primrec.eq.comp Primrec.fst (Primrec.const 1)
  have hnext : Primrec (fun X : Diagram => X.2 + 1) :=
    Primrec.nat_add.comp Primrec.snd (Primrec.const 1)
  exact (Primrec.cond h0.decide ((Primrec.const (0 : Fin 4)).pair hnext)
    (Primrec.cond h1.decide
      ((Primrec.const (1 : Fin 4)).pair (evenAmbientRank_primrec.comp Primrec.snd))
      (Primrec.fst.pair hnext))).of_eq
        (fun X => by simp only [Bool.cond_decide]; rfl)

noncomputable section

def factorDecision (alg : Algorithms) (p : CoordinateInput) : Bool :=
  if p.1.1 = 0 then DCPVerification.decision (p.1.2, p.2) else
    SphericalWithAlgorithms.decision alg
      ((sourceDiagram p.1, ambientDiagram (sourceDiagram p.1)), p.2)

def factorWordTest (alg : Algorithms) (p : FactorCode × (Word × Word)) : Bool :=
  if p.1.1 = 0 then DCPVerification.wordDecision (p.1.2, p.2) else
    alg.word (sourceDiagram p.1, p.2)

theorem factorDecision_computable (alg : Algorithms) : Computable (factorDecision alg) := by
  have hp : PrimrecPred (fun p : CoordinateInput => p.1.1 = 0) :=
    Primrec.eq.comp (Primrec.fst.comp Primrec.fst) (Primrec.const 0)
  have hb : Computable (fun p : CoordinateInput => DCPVerification.decision (p.1.2, p.2)) :=
    DCPVerification.decision_computable.comp
      ((Primrec.snd.comp Primrec.fst).pair Primrec.snd).to_comp
  have hs : Computable (fun p : CoordinateInput => SphericalWithAlgorithms.decision alg
      ((sourceDiagram p.1, ambientDiagram (sourceDiagram p.1)), p.2)) :=
    (SphericalWithAlgorithms.decision_computable alg).comp
      (((sourceDiagram_primrec.comp Primrec.fst).pair
        (ambientDiagram_primrec.comp (sourceDiagram_primrec.comp Primrec.fst))).pair Primrec.snd).to_comp
  exact (Computable.cond hp.decide.to_comp hb hs).of_eq
    (fun p => by simp only [Bool.cond_decide]; rfl)

theorem factorWordTest_computable (alg : Algorithms) : Computable (factorWordTest alg) := by
  have hp : PrimrecPred (fun p : FactorCode × (Word × Word) => p.1.1 = 0) :=
    Primrec.eq.comp (Primrec.fst.comp Primrec.fst) (Primrec.const 0)
  have hb : Computable (fun p : FactorCode × (Word × Word) =>
      DCPVerification.wordDecision (p.1.2, p.2)) :=
    DCPVerification.wordDecision_computable.comp
      ((Primrec.snd.comp Primrec.fst).pair Primrec.snd).to_comp
  have hs : Computable (fun p : FactorCode × (Word × Word) =>
      alg.word (sourceDiagram p.1, p.2)) :=
    alg.word_computable.comp
      ((sourceDiagram_primrec.comp Primrec.fst).pair Primrec.snd).to_comp
  exact (Computable.cond hp.decide.to_comp hb hs).of_eq
    (fun p => by simp only [Bool.cond_decide]; rfl)

def FactorInputValid (p : CoordinateInput) : Prop :=
  if p.1.1 = 0 then DCPVerification.ValidInput (p.1.2, p.2) else
    DCPVerification.SphericalDecision.ValidInput
      ((sourceDiagram p.1, ambientDiagram (sourceDiagram p.1)), p.2)

def FactorPositive (p : CoordinateInput) : Prop := GroupDCP.InDoubleCoset
  (Subgroup.closure {x | x ∈ p.2.1.map (factorValue p.1)})
  (Subgroup.closure {x | x ∈ p.2.2.1.map (factorValue p.1)})
  (factorValue p.1 p.2.2.2.1) (factorValue p.1 p.2.2.2.2)

theorem factorDecision_correct (alg : Algorithms) (p : CoordinateInput) (hp : FactorInputValid p) :
    factorDecision alg p = true ↔ FactorPositive p := by
  rcases p with ⟨⟨t, r⟩, s⟩
  cases t with
  | zero => exact DCPVerification.decision_correct (r, s) hp
  | succ t =>
    exact SphericalWithAlgorithms.decision_correct alg
      ((sourceDiagram (t + 1, r), ambientDiagram (sourceDiagram (t + 1, r))), s) hp

def FactorWordValid (c : FactorCode) (w : Word) : Prop :=
  ∀ a ∈ w, a.1 < generatorCount c

theorem factorWordTest_correct (alg : Algorithms) (c : FactorCode) (hc : ValidFactor c) (u v : Word)
    (hu : FactorWordValid c u) (hv : FactorWordValid c v) :
    factorWordTest alg (c, (u, v)) = true ↔ factorValue c u = factorValue c v := by
  rcases c with ⟨t, r⟩
  cases t with
  | zero =>
    have hr : 1 ≤ r := by
      rcases hc with h | h | h | h | h <;> omega
    exact DCPVerification.wordDecision_spec r hr u v hu hv
  | succ t =>
    exact alg.word_spec (sourceDiagram (t + 1, r))
      (source_supported _ hc (by omega)) u v hu hv

end
end DCPv7.ProductEncoding
