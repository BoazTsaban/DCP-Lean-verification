import BraidGroup.ArtinWords
import BraidGroup.DoubleCoset
import Mathlib.Computability.Partrec

/-! Algorithm parameters for the spherical proof. The record is not an axiom:
its fields must be supplied by the biautomatic lemma and the cited spherical
biautomaticity/presentation inputs.
-/
namespace DCPv7.SphericalAlgorithms
open BraidGroup FiniteArtinGroup

structure Algorithms where
  word : Diagram × (RawWord × RawWord) → Bool
  word_computable : Computable word
  word_spec : ∀ X, Supported X → ∀ u v,
    RawValid (X.2 + 1) u → RawValid (X.2 + 1) v →
      (word (X, (u, v)) = true ↔ FiniteArtinGroup.rawEval X u = FiniteArtinGroup.rawEval X v)
  centralizer : Diagram × List RawWord → List RawWord
  centralizer_computable : Computable centralizer
  centralizer_spec : ∀ X, Supported X → ∀ s,
    (∀ w ∈ s, RawValid (X.2 + 1) w) →
      (∀ w ∈ centralizer (X, s), RawValid (X.2 + 1) w) ∧
      GroupDCP.Generates ((centralizer (X, s)).map (FiniteArtinGroup.rawEval X))
        (Subgroup.centralizer (FiniteArtinGroup.rawSubgroup X s : Set (OfDiagram X)))
  simultaneous : Diagram × RawInstance → Bool
  simultaneous_computable : Computable simultaneous
  simultaneous_spec : ∀ X, Supported X → ∀ e, InstanceValid X e →
    (simultaneous (X, e) = true ↔ InstanceSolvable X e)

end DCPv7.SphericalAlgorithms
