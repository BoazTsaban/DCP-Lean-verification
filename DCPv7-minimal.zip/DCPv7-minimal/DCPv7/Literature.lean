import DCPv7.BiautomaticInterfaces
import DCPv7.SphericalPresentation

/-! Named cited inputs, at the boundary used by DCPv7.

BR11 Proposition 1.2 supplies presentation-to-biautomatic-structure construction.
The word procedure is the structure-based procedure used in the proof of its
Lemma 1.3. GS91 pp.135--136 and the constructive proof of Lemma 4.2 supply the
fixed-word multiplier constructions, with coordinates oriented as in the paper.
These are interfaces to the cited constructive proofs, not assertions of the
manuscript's new simultaneous-conjugacy or centralizer-generator conclusion.

The standard automata intersection, projection, emptiness, trimming, and word
extraction operations are verified in this package and are not axioms here.
-/
namespace DCPv7.Literature

/-- Bridson--Reeves, Proposition 1.2, in the finite-automata formulation of
biautomaticity used by GS91. Outside the promise the constructor may diverge. -/
axiom BR11_structure : Nonempty Biautomatic.StructureConstruction

/-- The automatic-structure word procedure used in BR11, proof of Lemma 1.3. -/
axiom BR11_word_procedure : Nonempty Biautomatic.WordProblemConstruction

/-- The left/right fixed-word constructions in GS91 pp.135--136 and the proof
of Lemma 4.2; this is a constructive-proof interface, not the lemma's verbatim
statement (which displays the same word on both sides). -/
axiom GS91_fixed_multipliers : Nonempty Biautomatic.FixedMultipliers

/-- Charney, Theorem 3.4, for the standard finite spherical presentations.
Their explicit relation lists and equivalence to the existing Artin groups are
proved in SphericalPresentation, rather than included in this axiom. -/
axiom Ch92_spherical_biautomatic : ∀ X : FiniteArtinGroup.Diagram,
  FiniteArtinGroup.Supported X → Biautomatic.IsBiautomatic (SphericalPresentation.code X)

end DCPv7.Literature
