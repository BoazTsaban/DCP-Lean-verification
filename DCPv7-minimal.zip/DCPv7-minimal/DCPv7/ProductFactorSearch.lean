import DCPv7.ProductDecision
import DCPv7.MainSearch
import Mathlib.Computability.RE

/-! Run the factor witness searches and gather their particular coordinate
factors. These are targets for the subsequent search in the original tuple
generators; they are not replaced by a direct search for another factorization.
-/
namespace DCPv7.ProductEncoding
open GroupDCP SphericalAlgorithms
set_option backward.isDefEq.respectTransparency false
noncomputable section

def FactorWitness (p : CoordinateInput) (w : Candidate) : Prop :=
  (WordBound p.2.1.length w.1 ∧ WordBound p.2.2.1.length w.2) ∧
    factorValue p.1 p.2.2.2.2 =
      factorValue p.1 (BraidGroup.substitute p.2.1 w.1) * factorValue p.1 p.2.2.2.1 *
        factorValue p.1 (BraidGroup.substitute p.2.2.1 w.2)

def factorSearch (alg : Algorithms) (p : CoordinateInput) : Part Candidate :=
  if p.1.1 = 0 then MainSearch.search (p.1.2, p.2) else
    SphericalWithAlgorithms.search alg
      ((sourceDiagram p.1, ambientDiagram (sourceDiagram p.1)), p.2)

theorem factorSearch_partrec (alg : Algorithms) : Partrec (factorSearch alg) := by
  have hp : PrimrecPred (fun p : CoordinateInput => p.1.1 = 0) :=
    Primrec.eq.comp (Primrec.fst.comp Primrec.fst) (Primrec.const 0)
  have hb : Partrec (fun p : CoordinateInput => MainSearch.search (p.1.2, p.2)) :=
    MainSearch.search_partrec.comp
      ((Primrec.snd.comp Primrec.fst).pair Primrec.snd).to_comp
  have hs : Partrec (fun p : CoordinateInput => SphericalWithAlgorithms.search alg
      ((sourceDiagram p.1, ambientDiagram (sourceDiagram p.1)), p.2)) :=
    (SphericalWithAlgorithms.search_partrec alg).comp
      (((sourceDiagram_primrec.comp Primrec.fst).pair
        (ambientDiagram_primrec.comp (sourceDiagram_primrec.comp Primrec.fst))).pair Primrec.snd).to_comp
  exact (Partrec.cond hp.decide.to_comp hb hs).of_eq
    (fun p => by simp only [Bool.cond_decide]; rfl)

theorem factorSearch_sound (alg : Algorithms) (p : CoordinateInput) (hp : FactorInputValid p)
    (w : Candidate) (hw : w ∈ factorSearch alg p) : FactorWitness p w := by
  rcases p with ⟨⟨t, r⟩, s⟩
  cases t with
  | zero => exact MainSearch.search_sound (r, s) hp w hw
  | succ t =>
    exact SphericalWithAlgorithms.search_sound alg
      ((sourceDiagram (t + 1, r), ambientDiagram (sourceDiagram (t + 1, r))), s) hp w hw

theorem factorSearch_dom (alg : Algorithms) (p : CoordinateInput) (hp : FactorInputValid p)
    (hpos : FactorPositive p) : (factorSearch alg p).Dom := by
  rcases p with ⟨⟨t, r⟩, s⟩
  cases t with
  | zero => exact (MainSearch.search_terminates_iff (r, s) hp).mpr hpos
  | succ t => exact (SphericalWithAlgorithms.search_terminates_iff alg
      ((sourceDiagram (t + 1, r), ambientDiagram (sourceDiagram (t + 1, r))), s) hp).mpr hpos

def expandFactorWitness (p : CoordinateInput) (w : Candidate) : Word × Word :=
  (BraidGroup.substitute p.2.1 w.1, BraidGroup.substitute p.2.2.1 w.2)

theorem expandFactorWitness_primrec : Primrec₂ expandFactorWitness :=
  (BraidGroup.substitute_primrec.comp
    (Primrec.fst.comp (Primrec.snd.comp Primrec.fst)) (Primrec.fst.comp Primrec.snd)).pair
  (BraidGroup.substitute_primrec.comp
    (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst))) (Primrec.snd.comp Primrec.snd))

def factorTargets (alg : Algorithms) (p : CoordinateInput) : Part (Word × Word) :=
  (factorSearch alg p).map (expandFactorWitness p)

theorem factorTargets_partrec (alg : Algorithms) : Partrec (factorTargets alg) :=
  (factorSearch_partrec alg).map expandFactorWitness_primrec.to_comp

theorem factorTargets_dom (alg : Algorithms) (p : CoordinateInput) (hp : FactorInputValid p)
    (hpos : FactorPositive p) : (factorTargets alg p).Dom := factorSearch_dom alg p hp hpos

structure FactorTargetSpec (p : CoordinateInput) (t : Word × Word) : Prop where
  left_valid : FactorWordValid p.1 t.1
  right_valid : FactorWordValid p.1 t.2
  left_mem : factorValue p.1 t.1 ∈ Subgroup.closure {x | x ∈ p.2.1.map (factorValue p.1)}
  right_mem : factorValue p.1 t.2 ∈ Subgroup.closure {x | x ∈ p.2.2.1.map (factorValue p.1)}
  equation : factorValue p.1 p.2.2.2.2 =
    factorValue p.1 t.1 * factorValue p.1 p.2.2.2.1 * factorValue p.1 t.2

theorem factorTargets_sound (alg : Algorithms) (p : CoordinateInput) (hp : FactorInputValid p)
    (t : Word × Word) (ht : t ∈ factorTargets alg p) : FactorTargetSpec p t := by
  obtain ⟨w, hw, rfl⟩ := (Part.mem_map_iff _).mp ht
  have hs := factorSearch_sound alg p hp w hw
  rcases p with ⟨⟨tag, r⟩, s⟩
  cases tag with
  | zero =>
    exact ⟨BraidGroup.substitute_valid r s.1 hp.2.1 w.1 hs.1.1,
      BraidGroup.substitute_valid r s.2.1 hp.2.2.1 w.2 hs.1.2,
      BraidGroup.substitute_mem r s.1 w.1 hs.1.1,
      BraidGroup.substitute_mem r s.2.1 w.2 hs.1.2, hs.2⟩
  | succ tag =>
    exact ⟨BraidGroup.substitute_valid (r + 1) s.1 hp.2.2.2.1 w.1 hs.1.1,
      BraidGroup.substitute_valid (r + 1) s.2.1 hp.2.2.2.2.1 w.2 hs.1.2,
      FiniteArtinGroup.substitute_mem _ s.1 w.1 hs.1.1,
      FiniteArtinGroup.substitute_mem _ s.2.1 w.2 hs.1.2, hs.2⟩

def gatherPrefix (alg : Algorithms) (p : Input) (n : Nat) : Part (List (Word × Word)) :=
  n.rec (Part.some []) fun i previous => previous.bind fun ts =>
    (factorTargets alg (coordinateInput p i)).map fun t => ts ++ [t]

@[simp] theorem gatherPrefix_zero (alg : Algorithms) (p : Input) :
    gatherPrefix alg p 0 = Part.some [] := rfl

@[simp] theorem gatherPrefix_succ (alg : Algorithms) (p : Input) (n : Nat) :
    gatherPrefix alg p (n + 1) = (gatherPrefix alg p n).bind fun ts =>
      (factorTargets alg (coordinateInput p n)).map fun t => ts ++ [t] := rfl

theorem gatherPrefix_partrec (alg : Algorithms) : Partrec₂ (gatherPrefix alg) := by
  have hc : Partrec (fun q : (Input × Nat) × (Nat × List (Word × Word)) =>
      factorTargets alg (coordinateInput q.1.1 q.2.1)) :=
    (factorTargets_partrec alg).comp
      (coordinateInput_primrec.comp (Primrec.fst.comp Primrec.fst) (Primrec.fst.comp Primrec.snd)).to_comp
  have ha : Computable₂ (fun q : (Input × Nat) × (Nat × List (Word × Word)) =>
      fun t : Word × Word => q.2.2 ++ [t]) :=
    Computable.list_append.comp (Computable.snd.comp (Computable.snd.comp Computable.fst))
      (Computable.list_cons.comp Computable.snd (Computable.const []))
  exact Partrec.nat_rec Computable.snd (Computable.const []) (hc.map ha).to₂

theorem gatherPrefix_dom (alg : Algorithms) (p : Input) (n : Nat)
    (hp : ∀ i < n, FactorInputValid (coordinateInput p i))
    (hpos : ∀ i < n, FactorPositive (coordinateInput p i)) : (gatherPrefix alg p n).Dom := by
  induction n with
  | zero => simp
  | succ n ih =>
    obtain ⟨ts, hts⟩ := Part.dom_iff_mem.mp (ih (fun i hi => hp i (by omega))
      (fun i hi => hpos i (by omega)))
    obtain ⟨t, ht⟩ := Part.dom_iff_mem.mp (factorTargets_dom alg _ (hp n (by omega)) (hpos n (by omega)))
    exact Part.dom_iff_mem.mpr ⟨ts ++ [t], Part.mem_bind hts (Part.mem_map _ ht)⟩

theorem gatherPrefix_sound (alg : Algorithms) (p : Input) (n : Nat)
    (hp : ∀ i < n, FactorInputValid (coordinateInput p i))
    (ts : List (Word × Word)) (hts : ts ∈ gatherPrefix alg p n) :
    ts.length = n ∧ ∀ i < n, FactorTargetSpec (coordinateInput p i) (ts.getD i ([], [])) := by
  induction n generalizing ts with
  | zero =>
    have he : ts = [] := Part.mem_some_iff.mp hts
    subst ts
    exact ⟨rfl, by simp⟩
  | succ n ih =>
    obtain ⟨previous, hprevious, ht⟩ := Part.mem_bind_iff.mp hts
    obtain ⟨t, htarget, rfl⟩ := (Part.mem_map_iff _).mp ht
    have hs := ih (fun i hi => hp i (by omega)) previous hprevious
    refine ⟨by simp [hs.1], ?_⟩
    intro i hi
    by_cases hin : i < n
    · rw [List.getD_append _ _ _ _ (by omega)]
      exact hs.2 i hin
    · have he : i = n := by omega
      subst i
      rw [List.getD_append_right _ _ _ _ (by omega), hs.1, Nat.sub_self]
      exact factorTargets_sound alg _ (hp n (by omega)) t htarget

def gather (alg : Algorithms) (p : Input) : Part (List (Word × Word)) :=
  gatherPrefix alg p p.1.length

theorem gather_partrec (alg : Algorithms) : Partrec (gather alg) :=
  (gatherPrefix_partrec alg).comp Computable.id (Primrec.list_length.comp Primrec.fst).to_comp

theorem gather_dom (alg : Algorithms) (p : Input) (hp : ValidInput p)
    (hpos : Positive FactorGroup factorValue p) : (gather alg p).Dom := by
  apply gatherPrefix_dom alg p p.1.length hp.2.1
  have hc : ∀ i : Fin p.1.length, InDoubleCoset
      (coordinateSubgroups p p.2.1 i) (coordinateSubgroups p p.2.2.1 i)
      (tupleValue FactorGroup factorValue p.1 p.2.2.2.1 i)
      (tupleValue FactorGroup factorValue p.1 p.2.2.2.2 i) := by
    apply (product_doubleCoset_iff _ _ _ _).mp
    rw [Positive, hp.2.2.1, hp.2.2.2] at hpos
    exact hpos
  exact fun i hi => (coordinatePositive_iff p ⟨i, hi⟩).mpr (hc ⟨i, hi⟩)

structure TargetSpec (p : Input) (ts : List (Word × Word)) : Prop where
  length : ts.length = p.1.length
  left_valid : ∀ i : Fin p.1.length, FactorWordValid p.1[i] (ts.getD i.val ([], [])).1
  right_valid : ∀ i : Fin p.1.length, FactorWordValid p.1[i] (ts.getD i.val ([], [])).2
  left_mem : ∀ i : Fin p.1.length, factorValue p.1[i] (ts.getD i.val ([], [])).1 ∈
    coordinateSubgroups p p.2.1 i
  right_mem : ∀ i : Fin p.1.length, factorValue p.1[i] (ts.getD i.val ([], [])).2 ∈
    coordinateSubgroups p p.2.2.1 i
  equation : ∀ i : Fin p.1.length, factorValue p.1[i] (project i.val p.2.2.2.2) =
    factorValue p.1[i] (ts.getD i.val ([], [])).1 * factorValue p.1[i] (project i.val p.2.2.2.1) *
      factorValue p.1[i] (ts.getD i.val ([], [])).2

theorem gather_sound (alg : Algorithms) (p : Input) (hp : ValidInput p)
    (ts : List (Word × Word)) (hts : ts ∈ gather alg p) : TargetSpec p ts := by
  have hs := gatherPrefix_sound alg p p.1.length hp.2.1 ts hts
  have hi (i : Fin p.1.length) : FactorTargetSpec
      (p.1[i], (p.2.1.map (project i.val), p.2.2.1.map (project i.val),
        project i.val p.2.2.2.1, project i.val p.2.2.2.2)) (ts.getD i.val ([], [])) := by
    have h := hs.2 i.val i.isLt
    simpa only [coordinateInput, List.getD_eq_getElem p.1 (0, 1) i.isLt, Fin.getElem_fin] using h
  exact ⟨hs.1, fun i => (hi i).left_valid, fun i => (hi i).right_valid,
    fun i => (hi i).left_mem, fun i => (hi i).right_mem, fun i => (hi i).equation⟩

end
end DCPv7.ProductEncoding
