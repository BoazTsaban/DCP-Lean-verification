import DCPv7.LengthEnumeration
import Mathlib.Computability.Partrec
import Mathlib.Computability.Primrec.List

/-! The exact total-length schedule is primitive recursive. The unbounded search
uses that schedule, including stage zero, and not the encoding order of words.
-/
namespace DCPv7.LengthEnumeration

set_option maxHeartbeats 400000
set_option backward.isDefEq.respectTransparency false

variable {α β P : Type} [Primcodable α] [Primcodable β] [Primcodable P]

theorem pair_snd_primrec : Primrec₂ (fun q : P × α => fun b : β => (q.2, b)) :=
  Primrec.to₂ ((Primrec.snd.comp Primrec.fst).pair Primrec.snd)

theorem words_primrec : Primrec₂ (@words α) := by
  have hs : Primrec₂ (fun A : List α => fun r : Nat × List (List α) =>
      A.flatMap fun a => r.2.map (a :: ·)) := by
    apply Primrec.list_flatMap Primrec.fst
    exact Primrec.list_map (Primrec.snd.comp (Primrec.snd.comp Primrec.fst))
      (Primrec.to₂ (Primrec.list_cons.comp (Primrec.snd.comp Primrec.fst) Primrec.snd))
  exact (Primrec.nat_rec (Primrec.const [[]]) hs).of_eq fun A n => by
    induction n with
    | zero => rfl
    | succ n ih => simp only [words, ih]

theorem stage_primrec : Primrec (fun p : (List α × List β) × Nat =>
    stage p.1.1 p.1.2 p.2) := by
  have hB : Primrec (fun q : ((((List α × List β) × Nat) × Nat) × List α) =>
      words q.1.1.1.2 (q.1.1.2 - q.1.2)) :=
    words_primrec.comp
      (Primrec.snd.comp (Primrec.fst.comp (Primrec.fst.comp Primrec.fst)))
      (Primrec.nat_sub.comp (Primrec.snd.comp (Primrec.fst.comp Primrec.fst))
        (Primrec.snd.comp Primrec.fst))
  have hp : Primrec₂ (fun q : ((((List α × List β) × Nat) × Nat) × List α) =>
      fun v : List β => (q.2, v)) :=
    pair_snd_primrec
  have hm' := Primrec.list_map hB hp
  have hm : Primrec₂ (fun q : (((List α × List β) × Nat) × Nat) =>
      fun u : List α => (words q.1.1.2 (q.1.2 - q.2)).map fun v => (u, v)) :=
    hm'.of_eq (fun q => rfl)
  have hA : Primrec (fun q : (((List α × List β) × Nat) × Nat) =>
      words q.1.1.1 q.2) :=
    words_primrec.comp (Primrec.fst.comp (Primrec.fst.comp Primrec.fst)) Primrec.snd
  have hi : Primrec₂ (fun p : ((List α × List β) × Nat) => fun k : Nat =>
      (words p.1.1 k).flatMap fun u =>
        (words p.1.2 (p.2 - k)).map fun v => (u, v)) :=
    Primrec.list_flatMap hA hm
  have hstage := Primrec.list_flatMap
    (Primrec.list_range.comp (Primrec.succ.comp Primrec.snd)) hi
  exact hstage.of_eq (fun p => rfl)

theorem first_computable [Inhabited α] (test : P → α → Bool) (ht : Computable₂ test) :
    Computable₂ (fun p s => first (test p) s) := by
  have hstep : Computable₂ (fun q : P × List α => fun r : Nat × Option α =>
      match r.2 with
      | some a => some a
      | none => if test q.1 (q.2.getD r.1 default) then
          some (q.2.getD r.1 default) else none) := by
    have hentry : Computable (fun q : (P × List α) × (Nat × Option α) =>
        q.1.2.getD q.2.1 default) :=
      (Primrec.list_getD default).to_comp.comp
        (Computable.snd.comp Computable.fst) (Computable.fst.comp Computable.snd)
    have htest : Computable (fun q : (P × List α) × (Nat × Option α) =>
        test q.1.1 (q.1.2.getD q.2.1 default)) :=
      ht.comp (Computable.fst.comp Computable.fst) hentry
    have hnew : Computable (fun q : (P × List α) × (Nat × Option α) =>
        if test q.1.1 (q.1.2.getD q.2.1 default) then
          some (q.1.2.getD q.2.1 default) else none) :=
      (Computable.cond htest (Computable.option_some.comp hentry)
        (Computable.const none)).of_eq fun q => by
          cases test q.1.1 (q.1.2.getD q.2.1 default) <;> rfl
    exact (Computable.option_casesOn (Computable.snd.comp Computable.snd) hnew
      (Computable.option_some.comp Computable.snd).to₂).of_eq
        (fun q => by rcases q with ⟨⟨p, s⟩, ⟨n, o⟩⟩; cases o <;> rfl)
  exact (Computable.nat_rec (Computable.list_length.comp Computable.snd)
    (Computable.const none) hstep).of_eq fun q => by
      dsimp only
      rw [← prefixFirst_eq_first (test q.1) q.2]
      generalize q.2.length = n
      induction n with
      | zero => rfl
      | succ n ih => simp only [prefixFirst, ih]; rfl

def lengthStep (A : P → List α) (B : P → List β)
    (test : P → List α × List β → Bool) (p : P) (n : Nat) :
    Option (List α × List β) := first (test p) (stage (A p) (B p) n)

def lengthSearch (A : P → List α) (B : P → List β)
    (test : P → List α × List β → Bool) (p : P) : Part (List α × List β) :=
  Nat.rfindOpt (lengthStep A B test p)

theorem lengthStep_computable (A : P → List α) (B : P → List β)
    (test : P → List α × List β → Bool) (hA : Computable A) (hB : Computable B)
    (ht : Computable₂ test) : Computable₂ (lengthStep A B test) :=
  (first_computable test ht).comp Computable.fst
    (stage_primrec.to_comp.comp
      (((hA.comp Computable.fst).pair (hB.comp Computable.fst)).pair Computable.snd))

theorem lengthSearch_partrec (A : P → List α) (B : P → List β)
    (test : P → List α × List β → Bool) (hA : Computable A) (hB : Computable B)
    (ht : Computable₂ test) : Partrec (lengthSearch A B test) :=
  Partrec.rfindOpt (lengthStep_computable A B test hA hB ht)

omit [Primcodable α] [Primcodable β] [Primcodable P] in
theorem lengthSearch_sound (A : P → List α) (B : P → List β)
    (test : P → List α × List β → Bool) (p : P) (w : List α × List β)
    (hw : w ∈ lengthSearch A B test p) :
    (∀ a ∈ w.1, a ∈ A p) ∧ (∀ b ∈ w.2, b ∈ B p) ∧ test p w = true := by
  obtain ⟨n, hn⟩ := Nat.rfindOpt_spec hw
  have hs := first_sound (test p) (stage (A p) (B p) n) w hn
  have hm := (mem_stage (A p) (B p) n w.1 w.2).mp hs.1
  exact ⟨hm.2.1, hm.2.2, hs.2⟩

omit [Primcodable α] [Primcodable β] [Primcodable P] in
theorem lengthSearch_dom (A : P → List α) (B : P → List β)
    (test : P → List α × List β → Bool) (p : P) :
    (lengthSearch A B test p).Dom ↔ ∃ w : List α × List β,
      (∀ a ∈ w.1, a ∈ A p) ∧ (∀ b ∈ w.2, b ∈ B p) ∧ test p w = true := by
  constructor
  · intro h
    obtain ⟨w, hw⟩ := Part.dom_iff_mem.mp h
    exact ⟨w, lengthSearch_sound A B test p w hw⟩
  · rintro ⟨w, hA, hB, ht⟩
    obtain ⟨v, hv⟩ := (first_terminates (test p)
      (stage (A p) (B p) (w.1.length + w.2.length))).mpr
        ⟨w, eventually_enumerated _ _ _ _ hA hB, ht⟩
    exact Nat.rfindOpt_dom.mpr ⟨w.1.length + w.2.length, v, hv⟩

end DCPv7.LengthEnumeration
