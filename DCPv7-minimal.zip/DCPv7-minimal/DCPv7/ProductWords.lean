import DCPv7.ProductEncoding
import BraidGroup.DoubleCosetProducts
import Mathlib.Data.List.GetD

/-! Words in the original supplied generating lists of a mixed product.
The family of factor evaluations is explicit. In particular, the words returned
by the subgroup-word theorem use the original tuple generators, rather than
independently chosen coordinate generators.
-/
namespace DCPv7.ProductEncoding

variable (G : FactorCode → Type) [∀ c, Group (G c)]
variable (value : ∀ c, Word → G c)

structure EvaluationLaws : Prop where
  nil : ∀ c, value c [] = 1
  append : ∀ c u v, value c (u ++ v) = value c u * value c v
  inverse : ∀ c w, value c (inverse w) = (value c w)⁻¹

abbrev Tuple (factors : List FactorCode) := ∀ i : Fin factors.length, G factors[i]

def tupleValue (factors : List FactorCode) (w : ProductWord) : Tuple G factors :=
  fun i => value factors[i] (project i.val w)

def wordSubgroup (factors : List FactorCode) (s : List ProductWord) : Subgroup (Tuple G factors) :=
  Subgroup.closure {x | x ∈ s.map (tupleValue G value factors)}

variable {G value} (laws : EvaluationLaws G value)
include laws

theorem tupleValue_nil (factors : List FactorCode) : tupleValue G value factors [] = 1 := by
  funext i
  exact laws.nil factors[i]

theorem tupleValue_append (factors : List FactorCode) (u v : ProductWord) :
    tupleValue G value factors (u ++ v) =
      tupleValue G value factors u * tupleValue G value factors v := by
  funext i
  simp only [tupleValue, project_append, Pi.mul_apply, laws.append]

theorem tupleValue_inverse (factors : List FactorCode) (w : ProductWord) :
    tupleValue G value factors (productInverse w) = (tupleValue G value factors w)⁻¹ := by
  funext i
  simp only [tupleValue, project_inverse, Pi.inv_apply, laws.inverse]

theorem tupleValue_chunk_flip (factors : List FactorCode) (s : List ProductWord) (a : Letter) :
    tupleValue G value factors (productChunk s (flip a)) =
      (tupleValue G value factors (productChunk s a))⁻¹ := by
  rcases a with ⟨i, b⟩
  cases b <;> simp [flip, productChunk, tupleValue_inverse laws]

theorem tupleValue_substitute_inverse (factors : List FactorCode) (s : List ProductWord) (w : Word) :
    tupleValue G value factors (productSubstitute s (inverse w)) =
      (tupleValue G value factors (productSubstitute s w))⁻¹ := by
  induction w with
  | nil => simp only [inverse_nil, productSubstitute, List.flatMap_nil, tupleValue_nil laws, inv_one]
  | cons a w ih =>
    rw [inverse_cons]
    simp only [productSubstitute, List.flatMap_append, List.flatMap_cons, List.flatMap_nil,
      List.append_nil, tupleValue_append laws, mul_inv_rev]
    change tupleValue G value factors (productSubstitute s (inverse w)) *
      tupleValue G value factors (productChunk s (flip a)) =
        (tupleValue G value factors (productSubstitute s w))⁻¹ *
          (tupleValue G value factors (productChunk s a))⁻¹
    rw [ih, tupleValue_chunk_flip laws]

theorem subgroupWord_exists (factors : List FactorCode) (s : List ProductWord)
    {a : Tuple G factors} (ha : a ∈ wordSubgroup G value factors s) :
    ∃ w : Word, (∀ l ∈ w, l.1 < s.length) ∧
      tupleValue G value factors (productSubstitute s w) = a := by
  induction ha using Subgroup.closure_induction with
  | mem a ha =>
    obtain ⟨u, hu, rfl⟩ := List.mem_map.mp ha
    obtain ⟨i, hi, he⟩ := List.mem_iff_getElem.mp hu
    refine ⟨[(i, true)], by simpa using hi, ?_⟩
    simp only [productSubstitute, List.flatMap_cons, List.flatMap_nil, List.append_nil,
      productChunk, if_true]
    rw [List.getD_eq_getElem s [] hi, he]
  | one => exact ⟨[], by simp, tupleValue_nil laws factors⟩
  | mul a b ha hb iha ihb =>
    obtain ⟨u, hu, heu⟩ := iha
    obtain ⟨v, hv, hev⟩ := ihb
    refine ⟨u ++ v, ?_, ?_⟩
    · intro l hl
      exact (List.mem_append.mp hl).elim (hu l) (hv l)
    simp only [productSubstitute, List.flatMap_append, tupleValue_append laws] at *
    rw [heu, hev]
  | inv a ha ih =>
    obtain ⟨w, hw, he⟩ := ih
    refine ⟨inverse w, ?_, ?_⟩
    · intro l hl
      obtain ⟨b, hb, rfl⟩ := List.mem_map.mp hl
      exact hw b (List.mem_reverse.mp hb)
    · rw [tupleValue_substitute_inverse laws, he]

theorem substitute_mem (factors : List FactorCode) (s : List ProductWord) (w : Word)
    (hw : ∀ l ∈ w, l.1 < s.length) :
    tupleValue G value factors (productSubstitute s w) ∈ wordSubgroup G value factors s := by
  induction w with
  | nil =>
    rw [show productSubstitute s [] = [] from rfl, tupleValue_nil laws]
    exact (wordSubgroup G value factors s).one_mem
  | cons l w ih =>
    have hl := hw l (by simp)
    have ht : ∀ b ∈ w, b.1 < s.length := fun b hb => hw b (by simp [hb])
    have hm : tupleValue G value factors (s.getD l.1 []) ∈ wordSubgroup G value factors s := by
      rw [List.getD_eq_getElem s [] hl]
      exact Subgroup.subset_closure (List.mem_map.mpr ⟨_, List.getElem_mem hl, rfl⟩)
    change tupleValue G value factors (productChunk s l ++ productSubstitute s w) ∈ _
    rw [tupleValue_append laws]
    apply (wordSubgroup G value factors s).mul_mem _ (ih ht)
    rcases l with ⟨i, b⟩
    cases b
    · simpa only [productChunk, Bool.false_eq_true, if_false, tupleValue_inverse laws] using
        (wordSubgroup G value factors s).inv_mem hm
    · simpa only [productChunk, if_true] using hm

variable (G value)

omit laws in
theorem projection_wordSubgroup (factors : List FactorCode) (s : List ProductWord)
    (i : Fin factors.length) :
    (wordSubgroup G value factors s).map (Pi.evalMonoidHom (fun j => G factors[j]) i) =
      Subgroup.closure {x : G factors[i] | x ∈ (s.map (project i.val)).map (value factors[i])} := by
  unfold wordSubgroup
  rw [MonoidHom.map_closure]
  congr 1
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hx
    exact List.mem_map.mpr ⟨project i.val w, List.mem_map.mpr ⟨w, hw, rfl⟩, rfl⟩
  · intro hy
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hy
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hv
    exact ⟨tupleValue G value factors w, List.mem_map.mpr ⟨w, hw, rfl⟩, rfl⟩

end DCPv7.ProductEncoding
