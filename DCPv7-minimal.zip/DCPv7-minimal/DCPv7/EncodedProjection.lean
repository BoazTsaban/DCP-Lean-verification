import DCPv7.PaddedWords
import DCPv7.EncodedAutomatonPaths
import Mathlib.Computability.EpsilonNFA
import Mathlib.Data.List.GetD

/-! First-coordinate projection of an encoded DFA. Padding erasure is an
epsilon transition; finite Boolean vectors encode the subset construction.
No external projection or reachability theorem is assumed.
-/
namespace DCPv7.EncodedProjection
open EncodedAutomaton PaddedWords
set_option backward.isDefEq.respectTransparency false

abbrev State (D : Code) := Fin (totalStates D)
abbrev Mask := List Bool

def projected (D : Code) : εNFA Nat (State D) where
  step q b := {r | ∃ a, a < alphabetSize D ∧ firstSymbol a = b ∧ r = (machine D).step q a}
  start := {(machine D).start}
  accept := (machine D).accept

theorem projected_path_decode (D : Code) {q r : State D} {labels : List (Option Nat)}
    (hp : (projected D).IsPath q r labels) :
    ∃ w : List Nat, AlphabetWord (alphabetSize D) w ∧
      w.map firstSymbol = labels ∧ (machine D).evalFrom q w = r := by
  induction hp with
  | nil q => exact ⟨[], by simp [AlphabetWord], rfl, rfl⟩
  | cons t q r b labels hstep hpath ih =>
    obtain ⟨a, ha, hab, hat⟩ := hstep
    obtain ⟨w, hw, hmap, heval⟩ := ih
    refine ⟨a :: w, ?_, ?_, ?_⟩
    · intro c hc
      rcases List.mem_cons.mp hc with rfl | hc
      · exact ha
      · exact hw c hc
    · simp only [List.map_cons, hab, hmap]
    · change (machine D).evalFrom ((machine D).step q a) w = r
      simpa only [hat] using heval

theorem projected_path_encode (D : Code) (q : State D) (w : List Nat)
    (hw : AlphabetWord (alphabetSize D) w) :
    (projected D).IsPath q ((machine D).evalFrom q w) (w.map firstSymbol) := by
  induction w generalizing q with
  | nil => exact εNFA.IsPath.nil q
  | cons a w ih =>
    have ha := hw a (by simp)
    have ht : AlphabetWord (alphabetSize D) w := fun b hb => hw b (by simp [hb])
    exact εNFA.IsPath.cons ((machine D).step q a) q _ (firstSymbol a) _
      ⟨a, ha, rfl, rfl⟩ (ih ((machine D).step q a) ht)

theorem reduceOption_map (w : List Nat) :
    (w.map firstSymbol).reduceOption = firstProjection w := by
  simp only [List.reduceOption, firstProjection, List.filterMap_map, Function.comp_def, id_eq]

theorem accepted_alphabet (D : Code) (w : List Nat) (hw : (machine D).Accepts w) :
    AlphabetWord (alphabetSize D) w := by
  change acceptState D ((machine D).evalFrom (machine D).start w).val = true at hw
  rw [machine_evalFrom] at hw
  exact EncodedAutomaton.accepted_alphabet D _ w hw

theorem projected_correct (D : Code) (w : List Nat) :
    w ∈ (projected D).accepts ↔
      ∃ t, (machine D).Accepts t ∧ firstProjection t = w := by
  rw [εNFA.mem_accepts_iff_exists_path]
  constructor
  · rintro ⟨q, r, labels, hq, hr, hlabels, hpath⟩
    have hstart : q = (machine D).start := hq
    subst q
    obtain ⟨t, _, ht, he⟩ := projected_path_decode D hpath
    refine ⟨t, ?_, ?_⟩
    · change (machine D).accept ((machine D).evalFrom (machine D).start t)
      rw [he]
      exact hr
    · rw [← reduceOption_map, ht, hlabels]
  · rintro ⟨t, ht, he⟩
    refine ⟨(machine D).start, (machine D).evalFrom (machine D).start t,
      t.map firstSymbol, rfl, ht, ?_, ?_⟩
    · rw [reduceOption_map, he]
    · exact projected_path_encode D _ t (accepted_alphabet D t ht)

def erasedAlphabet (D : Code) : List Nat :=
  (List.range (alphabetSize D)).filter (fun a => decide (firstSymbol a = none))

theorem mem_erasedAlphabet (D : Code) (a : Nat) :
    a ∈ erasedAlphabet D ↔ a < alphabetSize D ∧ firstSymbol a = none := by
  simp only [erasedAlphabet, List.mem_filter, List.mem_range, decide_eq_true_eq]

def epsilonCandidates (D : Code) : List (List Nat) :=
  WordAutomaton.boundedWords (erasedAlphabet D) (totalStates D)

def epsilonTest (p : Code × (Nat × Nat)) (w : List Nat) : Bool :=
  decide (evalFrom p.1 p.2.1 w = p.2.2)

def epsilonReach (D : Code) (q r : Nat) : Bool :=
  (LengthEnumeration.first (epsilonTest (D, (q, r))) (epsilonCandidates D)).isSome

theorem epsilonReach_words (D : Code) (q r : State D) :
    epsilonReach D q.val r.val = true ↔
      ∃ w, (∀ a ∈ w, a ∈ erasedAlphabet D) ∧ (machine D).evalFrom q w = r := by
  unfold epsilonReach
  rw [Option.isSome_iff_exists]
  constructor
  · rintro ⟨w, hw⟩
    have hs := LengthEnumeration.first_sound _ _ _ hw
    have hletters := (WordAutomaton.mem_boundedWords _ _ w).mp hs.1
    refine ⟨w, hletters.2, ?_⟩
    apply Fin.ext
    rw [machine_evalFrom]
    exact of_decide_eq_true hs.2
  · rintro ⟨w, hw, he⟩
    obtain ⟨v, hv, heval, hletters⟩ := (machine D).short_path (erasedAlphabet D) q w hw
    have ht : epsilonTest (D, (q.val, r.val)) v = true := by
      apply decide_eq_true
      rw [← machine_evalFrom, heval, he]
    apply (LengthEnumeration.first_terminates _ _).mpr
    exact ⟨v, (WordAutomaton.mem_boundedWords _ _ v).mpr
      ⟨by simpa only [Fintype.card_fin] using hv, hletters⟩, ht⟩

theorem erased_map (D : Code) (w : List Nat) (hw : ∀ a ∈ w, a ∈ erasedAlphabet D) :
    w.map firstSymbol = List.replicate w.length none := by
  induction w with
  | nil => rfl
  | cons a w ih =>
    have ha := (mem_erasedAlphabet D a).mp (hw a (by simp))
    have ht : ∀ b ∈ w, b ∈ erasedAlphabet D := fun b hb => hw b (by simp [hb])
    simp only [List.map_cons, List.length_cons, List.replicate_succ, ha.2, ih ht]

theorem epsilonClosure_words (D : Code) (q r : State D) :
    r ∈ (projected D).εClosure {q} ↔
      ∃ w, (∀ a ∈ w, a ∈ erasedAlphabet D) ∧ (machine D).evalFrom q w = r := by
  rw [εNFA.mem_εClosure_iff_exists_path]
  constructor
  · rintro ⟨n, hp⟩
    obtain ⟨w, hw, hmap, he⟩ := projected_path_decode D hp
    refine ⟨w, ?_, he⟩
    intro a ha
    refine (mem_erasedAlphabet D a).mpr ⟨hw a ha, ?_⟩
    have hm : firstSymbol a ∈ w.map firstSymbol := List.mem_map.mpr ⟨a, ha, rfl⟩
    rw [hmap] at hm
    exact (List.mem_replicate.mp hm).2
  · rintro ⟨w, hw, he⟩
    have hvalid : AlphabetWord (alphabetSize D) w :=
      fun a ha => ((mem_erasedAlphabet D a).mp (hw a ha)).1
    have hp := projected_path_encode D q w hvalid
    rw [he, erased_map D w hw] at hp
    exact ⟨w.length, hp⟩

theorem epsilonReach_correct (D : Code) (q r : State D) :
    epsilonReach D q.val r.val = true ↔ r ∈ (projected D).εClosure {q} := by
  rw [epsilonReach_words, epsilonClosure_words]

def maskSet (D : Code) (v : Mask) : Set (State D) := {q | v.getD q.val false = true}

def startMask (D : Code) : Mask :=
  (List.range (totalStates D)).map (fun r => epsilonReach D (startState D) r)

def nextBit (D : Code) (v : Mask) (b r : Nat) : Bool :=
  (List.range (totalStates D)).any fun q => v.getD q false &&
    (List.range (alphabetSize D)).any fun a =>
      decide (firstSymbol a = some b) && epsilonReach D (step D q a) r

def nextMask (D : Code) (v : Mask) (b : Nat) : Mask :=
  (List.range (totalStates D)).map (nextBit D v b)

def acceptMask (D : Code) (v : Mask) : Bool :=
  (List.range (totalStates D)).any (fun q => v.getD q false && acceptState D q)

theorem getD_map_range {α : Type} (f : Nat → α) (n i : Nat) (hi : i < n) (d : α) :
    ((List.range n).map f).getD i d = f i := by
  rw [List.getD_eq_getElem _ d (by simpa using hi)]
  simp only [List.getElem_map, List.getElem_range]

@[simp] theorem startMask_length (D : Code) : (startMask D).length = totalStates D := by
  simp [startMask]

@[simp] theorem nextMask_length (D : Code) (v : Mask) (b : Nat) :
    (nextMask D v b).length = totalStates D := by simp [nextMask]

theorem startMask_set (D : Code) :
    maskSet D (startMask D) = (projected D).toNFA.start := by
  ext q
  change (startMask D).getD q.val false = true ↔ q ∈ (projected D).εClosure {(machine D).start}
  rw [startMask, getD_map_range _ _ _ q.isLt]
  exact epsilonReach_correct D (machine D).start q

theorem nextMask_set (D : Code) (v : Mask) (b : Nat) :
    maskSet D (nextMask D v b) = (projected D).stepSet (maskSet D v) b := by
  ext r
  change (nextMask D v b).getD r.val false = true ↔ r ∈ (projected D).stepSet (maskSet D v) b
  rw [nextMask, getD_map_range _ _ _ r.isLt]
  simp only [nextBit, List.any_eq_true, List.mem_range, Bool.and_eq_true, decide_eq_true_eq]
  constructor
  · rintro ⟨q, hq, hflag, a, ha, he, hr⟩
    let q' : State D := ⟨q, hq⟩
    apply εNFA.mem_stepSet_iff.mpr
    refine ⟨q', hflag, ?_⟩
    apply ((projected D).mem_εClosure_iff_exists).mpr
    refine ⟨(machine D).step q' a, ⟨a, ha, he, rfl⟩, ?_⟩
    exact (epsilonReach_correct D ((machine D).step q' a) r).mp hr
  · intro hr
    obtain ⟨q, hflag, hr⟩ := εNFA.mem_stepSet_iff.mp hr
    obtain ⟨t, ht, hreach⟩ := ((projected D).mem_εClosure_iff_exists).mp hr
    obtain ⟨a, ha, he, rfl⟩ := ht
    have hb := (epsilonReach_correct D ((machine D).step q a) r).mpr hreach
    exact ⟨q.val, q.isLt, hflag, a, ha, he, hb⟩

theorem acceptMask_correct (D : Code) (v : Mask) :
    acceptMask D v = true ↔ ∃ q ∈ maskSet D v, (machine D).accept q := by
  simp only [acceptMask, List.any_eq_true, List.mem_range, Bool.and_eq_true]
  constructor
  · rintro ⟨q, hq, hflag, haccept⟩
    exact ⟨⟨q, hq⟩, hflag, haccept⟩
  · rintro ⟨q, hflag, haccept⟩
    exact ⟨q.val, q.isLt, hflag, haccept⟩

def vectors (D : Code) : List Mask := LengthEnumeration.words [false, true] (totalStates D)
def vectorIndex (D : Code) (v : Mask) : Nat := (vectors D).idxOf v
def vectorAt (D : Code) (i : Nat) : Mask := (vectors D).getD i []

theorem mem_vectors (D : Code) (v : Mask) : v ∈ vectors D ↔ v.length = totalStates D := by
  rw [vectors, LengthEnumeration.mem_words]
  constructor
  · exact And.left
  · intro hv
    exact ⟨hv, fun a _ => by cases a <;> simp⟩

theorem vectors_positive (D : Code) : 0 < (vectors D).length := by
  have hm : List.replicate (totalStates D) false ∈ vectors D := (mem_vectors D _).mpr (by simp)
  apply List.length_pos_iff.mpr
  intro he
  simp only [he, List.not_mem_nil] at hm

theorem vectorIndex_lt (D : Code) (v : Mask) (hv : v.length = totalStates D) :
    vectorIndex D v < (vectors D).length :=
  List.idxOf_lt_length_of_mem ((mem_vectors D v).mpr hv)

theorem vectorAt_index (D : Code) (v : Mask) (hv : v.length = totalStates D) :
    vectorAt D (vectorIndex D v) = v := by
  rw [vectorAt, List.getD_eq_getElem _ [] (vectorIndex_lt D v hv)]
  exact List.getElem_idxOf (vectorIndex_lt D v hv)

def compiledRow (n : Nat) (D : Code) (v : Mask) : List Nat :=
  (List.range n).map (fun b => vectorIndex D (nextMask D v b))

def compile (n : Nat) (D : Code) : Code :=
  (n, ((vectors D).length - 1,
    (vectorIndex D (startMask D), ((vectors D).map (compiledRow n D), (vectors D).map (acceptMask D)))))

@[simp] theorem compile_alphabet (n : Nat) (D : Code) : alphabetSize (compile n D) = n := rfl

theorem compile_realStates (n : Nat) (D : Code) : realStates (compile n D) = (vectors D).length := by
  have hp := vectors_positive D
  change (vectors D).length - 1 + 1 = _
  omega

theorem compile_start (n : Nat) (D : Code) :
    startState (compile n D) = vectorIndex D (startMask D) + 1 := by
  unfold startState
  rw [compile_realStates]
  change vectorIndex D (startMask D) % (vectors D).length + 1 = _
  rw [Nat.mod_eq_of_lt (vectorIndex_lt D _ (startMask_length D))]

theorem getD_map_valid {α β : Type} (s : List α) (f : α → β)
    (i : Nat) (hi : i < s.length) (da : α) (db : β) :
    (s.map f).getD i db = f (s.getD i da) := by
  rw [List.getD_eq_getElem _ db (by simpa only [List.length_map] using hi),
    List.getElem_map, List.getD_eq_getElem s da hi]

theorem compile_step (n : Nat) (D : Code) (v : Mask) (hv : v.length = totalStates D)
    (b : Nat) (hb : b < n) :
    step (compile n D) (vectorIndex D v + 1) b = vectorIndex D (nextMask D v b) + 1 := by
  rw [step, if_neg (by omega), if_pos (show b < alphabetSize (compile n D) from hb)]
  change (((vectors D).map (compiledRow n D)).getD (vectorIndex D v + 1 - 1) []).getD b 0 %
    realStates (compile n D) + 1 = _
  rw [Nat.add_sub_cancel, getD_map_valid _ _ _ (vectorIndex_lt D v hv) [] [],
    show (vectors D).getD (vectorIndex D v) [] = v from vectorAt_index D v hv,
    compiledRow, getD_map_range _ _ _ hb, compile_realStates,
    Nat.mod_eq_of_lt (vectorIndex_lt D _ (nextMask_length D v b))]

theorem compile_accept (n : Nat) (D : Code) (v : Mask) (hv : v.length = totalStates D) :
    acceptState (compile n D) (vectorIndex D v + 1) = acceptMask D v := by
  rw [acceptState, if_neg (by omega)]
  change ((vectors D).map (acceptMask D)).getD (vectorIndex D v + 1 - 1) false = _
  rw [Nat.add_sub_cancel, getD_map_valid _ _ _ (vectorIndex_lt D v hv) [] false,
    show (vectors D).getD (vectorIndex D v) [] = v from vectorAt_index D v hv]

def runMasks (D : Code) (v : Mask) (w : List Nat) : Mask := w.foldl (nextMask D) v

theorem compile_evalFrom (n : Nat) (D : Code) (v : Mask) (hv : v.length = totalStates D)
    (w : List Nat) (hw : AlphabetWord n w) :
    evalFrom (compile n D) (vectorIndex D v + 1) w = vectorIndex D (runMasks D v w) + 1 := by
  induction w generalizing v with
  | nil => rfl
  | cons b w ih =>
    rw [evalFrom_cons, compile_step n D v hv b (hw b (by simp))]
    exact ih (nextMask D v b) (nextMask_length D v b) (fun a ha => hw a (by simp [ha]))

theorem runMasks_length (D : Code) (v : Mask) (hv : v.length = totalStates D) (w : List Nat) :
    (runMasks D v w).length = totalStates D := by
  induction w generalizing v with
  | nil => exact hv
  | cons b w ih => exact ih _ (nextMask_length D v b)

theorem runMasks_set (D : Code) (v : Mask) (w : List Nat) :
    maskSet D (runMasks D v w) = (projected D).toNFA.evalFrom (maskSet D v) w := by
  induction w generalizing v with
  | nil => rfl
  | cons b w ih =>
    change maskSet D (runMasks D (nextMask D v b) w) = _
    rw [ih, nextMask_set]
    rfl

theorem compile_correct_valid (n : Nat) (D : Code) (w : List Nat) (hw : AlphabetWord n w) :
    (machine (compile n D)).Accepts w ↔ w ∈ (projected D).accepts := by
  change acceptState (compile n D)
    ((machine (compile n D)).evalFrom (machine (compile n D)).start w).val = true ↔ _
  rw [machine_evalFrom]
  change acceptState (compile n D) (evalFrom (compile n D) (startState (compile n D)) w) = true ↔ _
  rw [compile_start, compile_evalFrom n D _ (startMask_length D) w hw,
    compile_accept n D _ (runMasks_length D _ (startMask_length D) w), acceptMask_correct,
    runMasks_set, startMask_set]
  rw [← (projected D).toNFA_correct]
  change (∃ q ∈ (projected D).toNFA.evalFrom (projected D).toNFA.start w,
      (machine D).accept q) ↔
    ∃ q ∈ (projected D).toNFA.accept, q ∈ (projected D).toNFA.evalFrom (projected D).toNFA.start w
  constructor
  · rintro ⟨q, hq, ha⟩
    exact ⟨q, ha, hq⟩
  · rintro ⟨q, ha, hq⟩
    exact ⟨q, hq, ha⟩

theorem compile_correct (n : Nat) (D : Code) (w : List Nat) :
    (machine (compile n D)).Accepts w ↔
      AlphabetWord n w ∧ ∃ t, (machine D).Accepts t ∧ firstProjection t = w := by
  by_cases hw : AlphabetWord n w
  · rw [compile_correct_valid n D w hw, projected_correct]
    exact ⟨fun h => ⟨hw, h⟩, And.right⟩
  · constructor
    · intro h
      exact False.elim (hw (accepted_alphabet (compile n D) w h))
    · rintro ⟨h, _⟩
      exact False.elim (hw h)

theorem any_primrec {P A : Type} [Primcodable P] [Primcodable A]
    (test : P → A → Bool) (ht : Primrec₂ test) :
    Primrec₂ (fun (p : P) (s : List A) => s.any (test p)) := by
  have hs : Primrec₂ (fun p : P × List A => fun ab : A × Bool => test p.1 ab.1 || ab.2) :=
    Primrec.to₂ (Primrec.or.comp
      (ht.comp (Primrec.fst.comp Primrec.fst) (Primrec.fst.comp Primrec.snd))
      (Primrec.snd.comp Primrec.snd))
  exact (Primrec.list_foldr Primrec.snd (Primrec.const false) hs).of_eq fun p => by
    induction p.2 with
    | nil => rfl
    | cons a s ih => simp only [List.foldr_cons, List.any_cons, ih]

theorem erasedAlphabet_primrec : Primrec erasedAlphabet := by
  have hp : PrimrecPred (fun a : Nat => firstSymbol a = none) :=
    Primrec.eq.comp firstSymbol_primrec (Primrec.const none)
  exact (Primrec.listFilter hp).comp (Primrec.list_range.comp alphabetSize_primrec)

theorem epsilonCandidates_primrec : Primrec epsilonCandidates :=
  WordAutomaton.boundedWords_primrec.comp erasedAlphabet_primrec totalStates_primrec

theorem epsilonTest_primrec : Primrec₂ epsilonTest := by
  have hp : Primrec (fun p : (Code × (Nat × Nat)) × List Nat => ((p.1.1, p.1.2.1), p.2)) :=
    ((Primrec.fst.comp Primrec.fst).pair (Primrec.fst.comp (Primrec.snd.comp Primrec.fst))).pair Primrec.snd
  have he' := Primrec.comp evalFrom_primrec hp
  have he : Primrec (fun p : (Code × (Nat × Nat)) × List Nat => evalFrom p.1.1 p.1.2.1 p.2) :=
    he'.of_eq (fun p => rfl)
  exact (Primrec.eq.comp he (Primrec.snd.comp (Primrec.snd.comp Primrec.fst))).decide

theorem epsilonReach_primrec : Primrec (fun p : Code × (Nat × Nat) => epsilonReach p.1 p.2.1 p.2.2) :=
  Primrec.option_isSome.comp
    ((LengthEnumeration.first_primrec epsilonTest epsilonTest_primrec).comp
      Primrec.id (epsilonCandidates_primrec.comp Primrec.fst))

theorem startMask_primrec : Primrec startMask := by
  have hp : Primrec (fun p : Code × Nat => (p.1, (startState p.1, p.2))) :=
    Primrec.fst.pair ((startState_primrec.comp Primrec.fst).pair Primrec.snd)
  have hm' := Primrec.comp epsilonReach_primrec hp
  have hm : Primrec₂ (fun D : Code => fun r : Nat => epsilonReach D (startState D) r) :=
    hm'.of_eq (fun p => rfl)
  exact Primrec.list_map (Primrec.list_range.comp totalStates_primrec) hm

abbrev BitInput := Code × (Mask × (Nat × Nat))

theorem nextBit_primrec : Primrec (fun p : BitInput => nextBit p.1 p.2.1 p.2.2.1 p.2.2.2) := by
  have hD : Primrec (fun p : (BitInput × Nat) × Nat => p.1.1.1) :=
    Primrec.fst.comp (Primrec.fst.comp Primrec.fst)
  have hB : Primrec (fun p : (BitInput × Nat) × Nat => p.1.1.2.2.1) :=
    Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp (Primrec.fst.comp Primrec.fst)))
  have hR : Primrec (fun p : (BitInput × Nat) × Nat => p.1.1.2.2.2) :=
    Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp (Primrec.fst.comp Primrec.fst)))
  have hpStep : Primrec (fun p : (BitInput × Nat) × Nat => (p.1.1.1, (p.1.2, p.2))) :=
    hD.pair ((Primrec.snd.comp Primrec.fst).pair Primrec.snd)
  have hs' := Primrec.comp step_primrec hpStep
  have hs : Primrec (fun p : (BitInput × Nat) × Nat => step p.1.1.1 p.1.2 p.2) :=
    hs'.of_eq (fun p => rfl)
  have hpReach := hD.pair (hs.pair hR)
  have hr' := Primrec.comp epsilonReach_primrec hpReach
  have hr : Primrec (fun p : (BitInput × Nat) × Nat =>
      epsilonReach p.1.1.1 (step p.1.1.1 p.1.2 p.2) p.1.1.2.2.2) :=
    hr'.of_eq (fun p => rfl)
  have he : PrimrecPred (fun p : (BitInput × Nat) × Nat => firstSymbol p.2 = some p.1.1.2.2.1) :=
    Primrec.eq.comp (firstSymbol_primrec.comp Primrec.snd) (Primrec.option_some.comp hB)
  have ha : Primrec₂ (fun p : BitInput × Nat => fun a : Nat =>
      decide (firstSymbol a = some p.1.2.2.1) &&
        epsilonReach p.1.1 (step p.1.1 p.2 a) p.1.2.2.2) :=
    (Primrec.and.comp he.decide hr).of_eq (fun p => rfl)
  have hinner' := (any_primrec _ ha).comp Primrec.id
    (Primrec.list_range.comp (alphabetSize_primrec.comp (Primrec.fst.comp Primrec.fst)))
  have hinner : Primrec (fun p : BitInput × Nat =>
      (List.range (alphabetSize p.1.1)).any fun a =>
        decide (firstSymbol a = some p.1.2.2.1) &&
          epsilonReach p.1.1 (step p.1.1 p.2 a) p.1.2.2.2) :=
    hinner'.of_eq (fun p => rfl)
  have hflag : Primrec (fun p : BitInput × Nat => p.1.2.1.getD p.2 false) :=
    (Primrec.list_getD false).comp (Primrec.fst.comp (Primrec.snd.comp Primrec.fst)) Primrec.snd
  have houter : Primrec₂ (fun p : BitInput => fun q : Nat => p.2.1.getD q false &&
      (List.range (alphabetSize p.1)).any fun a =>
        decide (firstSymbol a = some p.2.2.1) && epsilonReach p.1 (step p.1 q a) p.2.2.2) :=
    (Primrec.and.comp hflag hinner).of_eq (fun p => rfl)
  exact (any_primrec _ houter).comp Primrec.id
    (Primrec.list_range.comp (totalStates_primrec.comp Primrec.fst))

theorem nextMask_primrec : Primrec (fun p : Code × (Mask × Nat) => nextMask p.1 p.2.1 p.2.2) := by
  have hp : Primrec (fun p : (Code × (Mask × Nat)) × Nat =>
      (p.1.1, (p.1.2.1, (p.1.2.2, p.2)))) :=
    (Primrec.fst.comp Primrec.fst).pair
      ((Primrec.fst.comp (Primrec.snd.comp Primrec.fst)).pair
        ((Primrec.snd.comp (Primrec.snd.comp Primrec.fst)).pair Primrec.snd))
  have hb' := Primrec.comp nextBit_primrec hp
  have hb : Primrec₂ (fun p : Code × (Mask × Nat) => fun r : Nat => nextBit p.1 p.2.1 p.2.2 r) :=
    hb'.of_eq (fun p => rfl)
  exact Primrec.list_map (Primrec.list_range.comp (totalStates_primrec.comp Primrec.fst)) hb

theorem acceptMask_primrec : Primrec₂ acceptMask := by
  have hg : Primrec (fun p : (Code × Mask) × Nat => p.1.2.getD p.2 false) :=
    (Primrec.list_getD false).comp (Primrec.snd.comp Primrec.fst) Primrec.snd
  have ha : Primrec (fun p : (Code × Mask) × Nat => acceptState p.1.1 p.2) :=
    acceptState_primrec.comp (Primrec.fst.comp Primrec.fst) Primrec.snd
  have hb' := Primrec.and.comp hg ha
  have hb : Primrec₂ (fun p : Code × Mask => fun q : Nat => p.2.getD q false && acceptState p.1 q) :=
    hb'.of_eq (fun p => rfl)
  exact (any_primrec _ hb).comp Primrec.id
    (Primrec.list_range.comp (totalStates_primrec.comp Primrec.fst))

theorem vectors_primrec : Primrec vectors :=
  LengthEnumeration.words_primrec.comp (Primrec.const [false, true]) totalStates_primrec

theorem vectorIndex_primrec : Primrec₂ vectorIndex := by
  have he : PrimrecPred (fun p : (Code × Mask) × Mask => p.2 = p.1.2) :=
    Primrec.eq.comp Primrec.snd (Primrec.snd.comp Primrec.fst)
  have he2 : Primrec₂ (fun p : Code × Mask => fun v : Mask => decide (v = p.2)) :=
    he.decide.to₂
  have hi := Primrec.list_findIdx (vectors_primrec.comp Primrec.fst) he2
  exact hi.of_eq (fun p => by simp only [vectorIndex, List.idxOf, beq_eq_decide])

theorem compiledRow_primrec : Primrec₂ (fun p : Nat × Code => compiledRow p.1 p.2) := by
  have hD : Primrec (fun p : ((Nat × Code) × Mask) × Nat => p.1.1.2) :=
    Primrec.snd.comp (Primrec.fst.comp Primrec.fst)
  have hp : Primrec (fun p : ((Nat × Code) × Mask) × Nat => (p.1.1.2, (p.1.2, p.2))) :=
    hD.pair ((Primrec.snd.comp Primrec.fst).pair Primrec.snd)
  have hn' := Primrec.comp nextMask_primrec hp
  have hn : Primrec (fun p : ((Nat × Code) × Mask) × Nat => nextMask p.1.1.2 p.1.2 p.2) :=
    hn'.of_eq (fun p => rfl)
  have hi : Primrec₂ (fun p : (Nat × Code) × Mask => fun b : Nat =>
      vectorIndex p.1.2 (nextMask p.1.2 p.2 b)) :=
    (vectorIndex_primrec.comp hD hn).of_eq (fun p => rfl)
  exact Primrec.list_map (Primrec.list_range.comp (Primrec.fst.comp Primrec.fst)) hi

theorem compile_primrec : Primrec₂ compile := by
  have hv : Primrec (fun p : Nat × Code => vectors p.2) := vectors_primrec.comp Primrec.snd
  have hcount : Primrec (fun p : Nat × Code => (vectors p.2).length - 1) :=
    Primrec.nat_sub.comp (Primrec.list_length.comp hv) (Primrec.const 1)
  have hstart : Primrec (fun p : Nat × Code => vectorIndex p.2 (startMask p.2)) :=
    vectorIndex_primrec.comp Primrec.snd (startMask_primrec.comp Primrec.snd)
  have hrows := Primrec.list_map hv compiledRow_primrec
  have hD : Primrec (fun p : (Nat × Code) × Mask => p.1.2) := Primrec.snd.comp Primrec.fst
  have hf' := acceptMask_primrec.comp hD Primrec.snd
  have hf : Primrec₂ (fun p : Nat × Code => fun v : Mask => acceptMask p.2 v) :=
    hf'.of_eq (fun p => rfl)
  have hflags := Primrec.list_map hv hf
  exact Primrec.fst.pair (hcount.pair (hstart.pair (hrows.pair hflags)))

def projectionCompiler : ProjectionCompiler where
  code p := compile p.1 p.2
  computable := compile_primrec.to_comp
  alphabet := compile_alphabet
  correct := compile_correct

end DCPv7.EncodedProjection
