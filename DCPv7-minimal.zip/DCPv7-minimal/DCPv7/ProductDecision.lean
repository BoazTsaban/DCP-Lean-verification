import DCPv7.FactorAlgorithms
import DCPv7.ProductSearch

/-! Concrete mixed-factor decision and supplied-generator search. The validity
specification states the coordinate factor promises and product decomposition.
`ProductParabolic.lean` derives these from the manuscript's parabolic promise.
-/
namespace DCPv7.ProductEncoding
open GroupDCP
open SphericalAlgorithms
set_option backward.isDefEq.respectTransparency false

theorem wordValid_append (factors : List FactorCode) (u v : ProductWord) :
    WordValid factors (u ++ v) ↔ WordValid factors u ∧ WordValid factors v := by
  constructor
  · intro h
    exact ⟨fun a ha => h a (List.mem_append_left v ha),
      fun a ha => h a (List.mem_append_right u ha)⟩
  · rintro ⟨hu, hv⟩ a ha
    exact (List.mem_append.mp ha).elim (hu a) (hv a)

theorem productInverse_valid (factors : List FactorCode) (w : ProductWord)
    (hw : WordValid factors w) : WordValid factors (productInverse w) := by
  intro a ha
  obtain ⟨b, hb, rfl⟩ := List.mem_map.mp ha
  exact hw b (List.mem_reverse.mp hb)

theorem productSubstitute_valid (factors : List FactorCode) (s : List ProductWord)
    (hs : ∀ u ∈ s, WordValid factors u) (w : Word) (hw : WordBound s.length w) :
    WordValid factors (productSubstitute s w) := by
  induction w with
  | nil => simp [productSubstitute, WordValid]
  | cons a w ih =>
    have ha := hw a (by simp)
    have ht : WordBound s.length w := fun b hb => hw b (by simp [hb])
    change WordValid factors (productChunk s a ++ productSubstitute s w)
    rw [wordValid_append]
    refine ⟨?_, ih ht⟩
    have hget : WordValid factors (s.getD a.1 []) := by
      rw [List.getD_eq_getElem s [] ha]
      exact hs _ (List.getElem_mem ha)
    rcases a with ⟨i, b⟩
    cases b
    · exact productInverse_valid factors _ hget
    · exact hget

def WordInputValid (p : Input) : Prop :=
  (∀ c ∈ p.1, ValidFactor c) ∧
  (∀ u ∈ p.2.1, WordValid p.1 u) ∧ (∀ u ∈ p.2.2.1, WordValid p.1 u) ∧
    WordValid p.1 p.2.2.2.1 ∧ WordValid p.1 p.2.2.2.2

theorem expandedCandidate_valid (p : Input) (hp : WordInputValid p) (w : Candidate)
    (hw : CandidateValid p w) : WordValid p.1 (expandedCandidate p w) := by
  rw [expandedCandidate, wordValid_append, wordValid_append]
  exact ⟨⟨productSubstitute_valid _ _ hp.2.1 _ hw.1, hp.2.2.2.1⟩,
    productSubstitute_valid _ _ hp.2.2.1 _ hw.2⟩

noncomputable section

theorem factor_coordinateCheck (alg : Algorithms) (p : Input) (hp : WordInputValid p) (w : Candidate)
    (hw : CandidateValid p w) (i : Fin p.1.length) :
    coordinateCheck (factorWordTest alg) (p, w) i.val = true ↔
      factorValue p.1[i] (project i.val p.2.2.2.2) =
        factorValue p.1[i] (project i.val (expandedCandidate p w)) := by
  have hc : ValidFactor (p.1.getD i.val (0, 1)) := by
    rw [List.getD_eq_getElem p.1 (0, 1) i.isLt]
    exact hp.1 _ (List.getElem_mem i.isLt)
  have hu := project_valid p.1 i.val p.2.2.2.2 hp.2.2.2.2
  have hv := project_valid p.1 i.val (expandedCandidate p w) (expandedCandidate_valid p hp w hw)
  have hs := factorWordTest_correct alg (p.1.getD i.val (0, 1)) hc _ _ hu hv
  rw [List.getD_eq_getElem p.1 (0, 1) i.isLt] at hs
  simpa only [coordinateCheck, List.getD_eq_getElem p.1 (0, 1) i.isLt, Fin.getElem_fin] using hs

def suppliedSearch (alg : Algorithms) : Input → Part Candidate := search (factorWordTest alg)

theorem suppliedSearch_partrec (alg : Algorithms) : Partrec (suppliedSearch alg) :=
  search_partrec (factorWordTest alg) (factorWordTest_computable alg)

theorem suppliedSearch_sound (alg : Algorithms) (p : Input) (hp : WordInputValid p) (w : Candidate)
    (hw : w ∈ suppliedSearch alg p) : Witness FactorGroup factorValue p w :=
  search_sound factorEvaluationLaws (factorWordTest alg) p (factor_coordinateCheck alg p hp) w hw

theorem suppliedSearch_terminates_iff (alg : Algorithms) (p : Input) (hp : WordInputValid p) :
    (suppliedSearch alg p).Dom ↔ Positive FactorGroup factorValue p :=
  search_terminates_iff factorEvaluationLaws (factorWordTest alg) p (factor_coordinateCheck alg p hp)

def decision (alg : Algorithms) : Input → Bool := productDecision (factorDecision alg)

theorem decision_computable (alg : Algorithms) : Computable (decision alg) :=
  productDecision_computable (factorDecision alg) (factorDecision_computable alg)

def coordinateSubgroups (p : Input) (s : List ProductWord) (i : Fin p.1.length) :
    Subgroup (FactorGroup p.1[i]) :=
  Subgroup.closure {x | x ∈ (s.map (project i.val)).map (factorValue p.1[i])}

def ProductForm (p : Input) (s : List ProductWord) : Prop :=
  wordSubgroup FactorGroup factorValue p.1 s = productSubgroup (coordinateSubgroups p s)

def ValidInput (p : Input) : Prop := WordInputValid p ∧
  (∀ i < p.1.length, FactorInputValid (coordinateInput p i)) ∧
    ProductForm p p.2.1 ∧ ProductForm p p.2.2.1

theorem coordinatePositive_iff (p : Input) (i : Fin p.1.length) :
    FactorPositive (coordinateInput p i.val) ↔
      InDoubleCoset (coordinateSubgroups p p.2.1 i) (coordinateSubgroups p p.2.2.1 i)
        (tupleValue FactorGroup factorValue p.1 p.2.2.2.1 i)
        (tupleValue FactorGroup factorValue p.1 p.2.2.2.2 i) := by
  simp only [coordinateInput]
  rw [List.getD_eq_getElem p.1 (0, 1) i.isLt]
  rfl

theorem decision_correct (alg : Algorithms) (p : Input) (hp : ValidInput p) :
    decision alg p = true ↔ Positive FactorGroup factorValue p := by
  rw [decision, productDecision_correct]
  have hprod : Positive FactorGroup factorValue p ↔
      ∀ i : Fin p.1.length,
        InDoubleCoset (coordinateSubgroups p p.2.1 i) (coordinateSubgroups p p.2.2.1 i)
          (tupleValue FactorGroup factorValue p.1 p.2.2.2.1 i)
          (tupleValue FactorGroup factorValue p.1 p.2.2.2.2 i) := by
    rw [Positive, hp.2.2.1, hp.2.2.2, product_doubleCoset_iff]
  rw [hprod]
  constructor
  · intro h i
    exact (coordinatePositive_iff p i).mp
      ((factorDecision_correct alg _ (hp.2.1 i.val i.isLt)).mp (h i.val i.isLt))
  · intro h i hi
    exact (factorDecision_correct alg _ (hp.2.1 i hi)).mpr
      ((coordinatePositive_iff p ⟨i, hi⟩).mpr (h ⟨i, hi⟩))

theorem decision_and_search (alg : Algorithms) : ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, ValidInput p →
      (d p = true ↔ Positive FactorGroup factorValue p) ∧
      (d p = true → (s p).Dom) ∧ ∀ w ∈ s p, Witness FactorGroup factorValue p w :=
  ⟨decision alg, suppliedSearch alg, decision_computable alg, suppliedSearch_partrec alg, fun p hp =>
    ⟨decision_correct alg p hp, fun hd => (suppliedSearch_terminates_iff alg p hp.1).mpr
      ((decision_correct alg p hp).mp hd), suppliedSearch_sound alg p hp.1⟩⟩

end
end DCPv7.ProductEncoding
