import DCPv7.FinitePresentation
import DCPv7.PaddedWords
import DCPv7.EncodedAutomatonIntersection
import Mathlib.GroupTheory.Subgroup.Centralizer

/-! Exact data interfaces for the cited biautomatic constructions. These
structures introduce no axioms. The local proof must consume the cited
structure/word/multiplier constructions and a verified projection compiler;
none of these records assumes the manuscript's simultaneous-conjugacy or
centralizer-generator conclusion.
-/
namespace DCPv7.Biautomatic
open FinitePresentation
set_option backward.isDefEq.respectTransparency false

abbrev Code := EncodedAutomaton.Code
abbrev StructureCode := Code × (Code × (List Code × List Code))

def language (s : StructureCode) : Code := s.1
def equalityCode (s : StructureCode) : Code := s.2.1
def leftGenerators (s : StructureCode) : List Code := s.2.2.1
def rightGenerators (s : StructureCode) : List Code := s.2.2.2
def Accepts (s : StructureCode) (w : Word) : Prop := (EncodedAutomaton.machine (language s)).Accepts w

def RelationSpec (s : StructureCode) (D : Code)
    (R : Word → Word → Prop) : Prop :=
  ∀ t, (EncodedAutomaton.machine D).Accepts t ↔
    ∃ p q, t = PaddedWords.pad p q ∧ Accepts s p ∧ Accepts s q ∧ R p q

/-- The finite-automata formulation of a biautomatic structure in the supplied
signed presentation alphabet, as in GS91 pp.135--136. -/
structure StructureSpec (P : Presentation) (s : StructureCode) : Prop where
  alphabet : EncodedAutomaton.alphabetSize (language s) = 2 * genCount P
  representatives : ∀ g : GroupOf P, ∃ w, Accepts s w ∧ value P w = g
  left_count : (leftGenerators s).length = 2 * genCount P
  right_count : (rightGenerators s).length = 2 * genCount P
  equality : RelationSpec s (equalityCode s) (fun p q => value P p = value P q)
  left : ∀ a < 2 * genCount P,
    RelationSpec s ((leftGenerators s).getD a (equalityCode s))
      (fun p q => letter P a * value P p = value P q)
  right : ∀ a < 2 * genCount P,
    RelationSpec s ((rightGenerators s).getD a (equalityCode s))
      (fun p q => value P p * letter P a = value P q)

def IsBiautomatic (P : Presentation) : Prop := ∃ s, StructureSpec P s

theorem accepted_valid (P : Presentation) (s : StructureCode) (hs : StructureSpec P s)
    (w : Word) (hw : Accepts s w) : ValidWord P w := by
  change EncodedAutomaton.acceptState (language s)
    ((EncodedAutomaton.machine (language s)).evalFrom
      (EncodedAutomaton.machine (language s)).start w).val = true at hw
  rw [EncodedAutomaton.machine_evalFrom] at hw
  have hv := EncodedAutomaton.accepted_alphabet (language s)
    (EncodedAutomaton.startState (language s)) w hw
  simpa only [ValidWord, hs.alphabet] using hv

/-- BR11 Proposition 1.2: a presentation-to-structure procedure, partial outside
the biautomatic promise. -/
structure StructureConstruction where
  run : Presentation → Part StructureCode
  partrec : Partrec run
  correct : ∀ P, IsBiautomatic P → (run P).Dom ∧ ∀ s ∈ run P, StructureSpec P s

/-- The word-problem procedure from an automatic structure, used in BR11's
proof of Lemma 1.3. No termination outside the stated promise is required. -/
structure WordProblemConstruction where
  run : (Presentation × StructureCode) × (Word × Word) → Part Bool
  partrec : Partrec run
  correct : ∀ P s, StructureSpec P s → ∀ u v, ValidWord P u → ValidWord P v →
    (run ((P, s), (u, v))).Dom ∧ ∀ b ∈ run ((P, s), (u, v)),
      (b = true ↔ value P u = value P v)

/-- The fixed-word left/right multiplier constructions of GS91 pp.135--136 and
the proof of Lemma 4.2. This interface supplies the multiplier relations only;
intersection, projection, emptiness, and generator extraction are deductions. -/
structure FixedMultipliers where
  leftCode : StructureCode × Word → Code
  left_computable : Computable leftCode
  rightCode : StructureCode × Word → Code
  right_computable : Computable rightCode
  left_spec : ∀ P s, StructureSpec P s → ∀ u, ValidWord P u →
    RelationSpec s (leftCode (s, u)) (fun p q => value P u * value P p = value P q)
  right_spec : ∀ P s, StructureSpec P s → ∀ v, ValidWord P v →
    RelationSpec s (rightCode (s, v)) (fun p q => value P p * value P v = value P q)

def subgroup (P : Presentation) (s : List Word) : Subgroup (GroupOf P) :=
  Subgroup.closure {g | g ∈ s.map (value P)}

def InstanceValid (P : Presentation) (e : List (Word × Word)) : Prop :=
  ∀ uv ∈ e, ValidWord P uv.1 ∧ ValidWord P uv.2

def InstanceSolvable (P : Presentation) (e : List (Word × Word)) : Prop :=
  ∃ x : GroupOf P, ∀ uv ∈ e, x⁻¹ * value P uv.1 * x = value P uv.2

/-- The local intersection/projection deduction, proved from multiplier
relations and a verified projection compiler, not assumed as literature. -/
structure ConjugatorCompiler where
  code : (Presentation × StructureCode) × (Word × Word) → Code
  computable : Computable code
  alphabet : ∀ P s u v, EncodedAutomaton.alphabetSize (code ((P, s), (u, v))) = 2 * genCount P
  correct : ∀ P s, StructureSpec P s → ∀ u v, ValidWord P u → ValidWord P v → ∀ w,
    (EncodedAutomaton.machine (code ((P, s), (u, v)))).Accepts w ↔
      Accepts s w ∧ (value P w)⁻¹ * value P u * value P w = value P v

/-- Total finite automaton operations after a correct structure has been
supplied. This record is constructed from the local conjugator compiler. -/
structure StructuredAlgorithms where
  centralizer : (Presentation × StructureCode) × List Word → List Word
  centralizer_computable : Computable centralizer
  centralizer_spec : ∀ P s, StructureSpec P s → ∀ u, (∀ w ∈ u, ValidWord P w) →
    (∀ w ∈ centralizer ((P, s), u), ValidWord P w) ∧
      Subgroup.closure {g | g ∈ (centralizer ((P, s), u)).map (value P)} =
        Subgroup.centralizer (subgroup P u : Set (GroupOf P))
  simultaneous : (Presentation × StructureCode) × List (Word × Word) → Bool
  simultaneous_computable : Computable simultaneous
  simultaneous_spec : ∀ P s, StructureSpec P s → ∀ e, InstanceValid P e →
    (simultaneous ((P, s), e) = true ↔ InstanceSolvable P e)

/-- The conclusion of the manuscript lemma, to be constructed by its proof.
This is a record type, not an assumption that it is inhabited. -/
structure Algorithms where
  word : Presentation × (Word × Word) → Part Bool
  word_partrec : Partrec word
  word_spec : ∀ P, IsBiautomatic P → ∀ u v, ValidWord P u → ValidWord P v →
    (word (P, (u, v))).Dom ∧ ∀ b ∈ word (P, (u, v)), (b = true ↔ value P u = value P v)
  centralizer : Presentation × List Word → Part (List Word)
  centralizer_partrec : Partrec centralizer
  centralizer_spec : ∀ P, IsBiautomatic P → ∀ s, (∀ w ∈ s, ValidWord P w) →
    (centralizer (P, s)).Dom ∧ ∀ t ∈ centralizer (P, s),
      (∀ w ∈ t, ValidWord P w) ∧ Subgroup.closure {g | g ∈ t.map (value P)} =
        Subgroup.centralizer (subgroup P s : Set (GroupOf P))
  simultaneous : Presentation × List (Word × Word) → Part Bool
  simultaneous_partrec : Partrec simultaneous
  simultaneous_spec : ∀ P, IsBiautomatic P → ∀ e, InstanceValid P e →
    (simultaneous (P, e)).Dom ∧ ∀ b ∈ simultaneous (P, e),
      (b = true ↔ InstanceSolvable P e)

end DCPv7.Biautomatic
