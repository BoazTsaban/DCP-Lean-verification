import DCPv7.Automaton
import Mathlib.Algebra.Group.Subgroup.Lattice

/-! The subgroup-generator construction in the proof of Lemma `lem:biautomatic`.

The edge generator is p_q a p_r⁻¹. Its membership follows by dividing the two
accepted words p_q a t_r and p_r t_r. Accepted paths telescope, with p_f included
at final states and p_start empty. No subgroup-generation conclusion is assumed.
-/
namespace DCPv7

variable {α Q G : Type} [Group G]

def wordValue (letter : α → G) (w : List α) : G := (w.map letter).prod

@[simp] theorem wordValue_nil (letter : α → G) : wordValue letter [] = 1 := rfl

@[simp] theorem wordValue_cons (letter : α → G) (a : α) (w : List α) :
    wordValue letter (a :: w) = letter a * wordValue letter w := rfl

@[simp] theorem wordValue_append (letter : α → G) (u v : List α) :
    wordValue letter (u ++ v) = wordValue letter u * wordValue letter v := by
  simp [wordValue]

namespace WordAutomaton

variable (M : WordAutomaton α Q) (paths : M.TrimPaths) (letter : α → G)

def edgeValue (q : Q) (a : α) : G :=
  wordValue letter (paths.prefixWord q) * letter a *
    (wordValue letter (paths.prefixWord (M.step q a)))⁻¹

def generatorSet : Set G :=
  {g | ∃ q a, M.Useful q ∧ M.Useful (M.step q a) ∧ g = M.edgeValue paths letter q a} ∪
  {g | ∃ f, M.Useful f ∧ M.accept f ∧ g = wordValue letter (paths.prefixWord f)}

theorem edge_mem_subgroup (H : Subgroup G)
    (accepted_mem : ∀ w, M.Accepts w → wordValue letter w ∈ H)
    (q : Q) (a : α) (hq : M.Useful q) (hr : M.Useful (M.step q a)) :
    M.edgeValue paths letter q a ∈ H := by
  have h₁ := accepted_mem _ (M.edge_suffix_accepted paths q a hq hr)
  have h₂ := accepted_mem _ (M.prefix_suffix_accepted paths (M.step q a) hr)
  have he : M.edgeValue paths letter q a =
      wordValue letter (paths.prefixWord q ++ a :: paths.suffixWord (M.step q a)) *
        (wordValue letter (paths.prefixWord (M.step q a) ++
          paths.suffixWord (M.step q a)))⁻¹ := by
    simp only [edgeValue, wordValue_append, wordValue_cons]
    simp [mul_inv_rev, mul_assoc]
  rw [he]
  exact H.mul_mem h₁ (H.inv_mem h₂)

theorem final_mem_subgroup (H : Subgroup G)
    (accepted_mem : ∀ w, M.Accepts w → wordValue letter w ∈ H)
    (f : Q) (hf : M.Useful f) (hfinal : M.accept f) :
    wordValue letter (paths.prefixWord f) ∈ H := by
  apply accepted_mem
  simpa only [Accepts, paths.prefix_spec f hf] using hfinal

/-- The edge factors cancel along the accepted path, leaving its final prefix. -/
theorem path_telescopes (q : Q) (w : List α) (hq : M.Useful q)
    (hw : M.accept (M.evalFrom q w)) :
    wordValue letter (paths.prefixWord q) * wordValue letter w ∈
      Subgroup.closure (M.generatorSet paths letter) := by
  induction w generalizing q with
  | nil =>
    simp only [wordValue_nil, mul_one]
    exact Subgroup.subset_closure (Or.inr ⟨q, hq, hw, rfl⟩)
  | cons a w ih =>
    have hr : M.Useful (M.step q a) := M.useful_next q a w hq hw
    have hedge : M.edgeValue paths letter q a ∈
        Subgroup.closure (M.generatorSet paths letter) :=
      Subgroup.subset_closure (Or.inl ⟨q, a, hq, hr, rfl⟩)
    have htail := ih (M.step q a) hr hw
    have hprod := (Subgroup.closure (M.generatorSet paths letter)).mul_mem hedge htail
    have he : M.edgeValue paths letter q a *
        (wordValue letter (paths.prefixWord (M.step q a)) * wordValue letter w) =
        wordValue letter (paths.prefixWord q) * wordValue letter (a :: w) := by
      simp only [edgeValue, wordValue_cons]
      simp [mul_assoc]
    rw [he] at hprod
    exact hprod

/-- Exact subgroup generation by the paper's edge words and final prefixes. -/
theorem generates_subgroup (H : Subgroup G)
    (accepted_mem : ∀ w, M.Accepts w → wordValue letter w ∈ H)
    (represented : ∀ h ∈ H, ∃ w, M.Accepts w ∧ wordValue letter w = h) :
    Subgroup.closure (M.generatorSet paths letter) = H := by
  apply le_antisymm
  · rw [Subgroup.closure_le]
    intro g hg
    rcases hg with ⟨q, a, hq, hr, rfl⟩ | ⟨f, hf, hfinal, rfl⟩
    · exact M.edge_mem_subgroup paths letter H accepted_mem q a hq hr
    · exact M.final_mem_subgroup paths letter H accepted_mem f hf hfinal
  · intro h hh
    obtain ⟨w, hw, he⟩ := represented h hh
    have ht := M.path_telescopes paths letter M.start w (M.useful_start hw) hw
    simpa only [paths.prefix_start, wordValue_nil, one_mul, he] using ht

end WordAutomaton
end DCPv7
