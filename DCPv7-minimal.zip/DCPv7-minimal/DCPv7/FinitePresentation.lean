import Mathlib.GroupTheory.PresentedGroup
import Mathlib.Computability.Partrec
import Mathlib.Computability.Primrec.List
import Lean.Elab.Tactic.Omega

/-! Finite presentations and their single natural-number word encoding.
Symbol `2*i` is the positive generator and `2*i+1` its inverse. Invalid symbols
evaluate to the identity; every algorithm specification requires valid words.
-/
namespace DCPv7.FinitePresentation
set_option backward.isDefEq.respectTransparency false

abbrev Word := List Nat
abbrev Presentation := Nat × List Word

def genCount (P : Presentation) : Nat := P.1
def flip (a : Nat) : Nat := if a % 2 = 0 then a + 1 else a - 1
def inverse (w : Word) : Word := w.reverse.map flip
def ValidWord (P : Presentation) (w : Word) : Prop := ∀ a ∈ w, a < 2 * genCount P

instance validWord_decidable : DecidableRel ValidWord := fun P w =>
  inferInstanceAs (Decidable (∀ a ∈ w, a < 2 * genCount P))

theorem flip_div_two (a : Nat) : flip a / 2 = a / 2 := by
  unfold flip
  split <;> omega

theorem flip_mod_two (a : Nat) : (flip a) % 2 = 0 ↔ a % 2 ≠ 0 := by
  unfold flip
  split <;> omega

@[simp] theorem flip_flip (a : Nat) : flip (flip a) = a := by
  unfold flip
  split <;> split <;> omega

theorem flip_lt (a n : Nat) (ha : a < 2 * n) : flip a < 2 * n := by
  unfold flip
  split <;> omega

@[simp] theorem inverse_nil : inverse [] = [] := rfl
theorem inverse_cons (a : Nat) (w : Word) : inverse (a :: w) = inverse w ++ [flip a] := by
  simp [inverse]

@[simp] theorem inverse_inverse (w : Word) : inverse (inverse w) = w := by
  simp [inverse, List.map_reverse, List.map_map, Function.comp_def]

@[simp] theorem validWord_nil (P : Presentation) : ValidWord P [] := by simp [ValidWord]
@[simp] theorem validWord_append (P : Presentation) (u v : Word) :
    ValidWord P (u ++ v) ↔ ValidWord P u ∧ ValidWord P v := by
  simp [ValidWord, or_imp, forall_and]

theorem validWord_inverse (P : Presentation) (w : Word) (hw : ValidWord P w) :
    ValidWord P (inverse w) := by
  intro a ha
  obtain ⟨b, hb, rfl⟩ := List.mem_map.mp ha
  exact flip_lt b (genCount P) (hw b (List.mem_reverse.mp hb))

def freeLetter (n a : Nat) : FreeGroup (Fin n) :=
  if h : a / 2 < n then
    if a % 2 = 0 then FreeGroup.of ⟨a / 2, h⟩ else (FreeGroup.of ⟨a / 2, h⟩)⁻¹
  else 1

def freeEval (n : Nat) (w : Word) : FreeGroup (Fin n) := (w.map (freeLetter n)).prod

@[simp] theorem freeLetter_even (n : Nat) (i : Fin n) : freeLetter n (2 * i.val) = FreeGroup.of i := by
  simp [freeLetter, i.isLt]

@[simp] theorem freeLetter_odd (n : Nat) (i : Fin n) :
    freeLetter n (2 * i.val + 1) = (FreeGroup.of i)⁻¹ := by
  have hdiv : (2 * i.val + 1) / 2 = i.val := by omega
  have hmod : (2 * i.val + 1) % 2 = 1 := by omega
  simp [freeLetter, hdiv, hmod, i.isLt]

@[simp] theorem freeLetter_flip (n a : Nat) : freeLetter n (flip a) = (freeLetter n a)⁻¹ := by
  by_cases hi : a / 2 < n
  · by_cases he : a % 2 = 0
    · simp [freeLetter, flip_div_two, flip_mod_two, hi, he]
    · simp [freeLetter, flip_div_two, flip_mod_two, hi, he]
  · simp [freeLetter, flip_div_two, hi]

@[simp] theorem freeEval_nil (n : Nat) : freeEval n [] = 1 := rfl
@[simp] theorem freeEval_cons (n a : Nat) (w : Word) :
    freeEval n (a :: w) = freeLetter n a * freeEval n w := rfl
@[simp] theorem freeEval_append (n : Nat) (u v : Word) :
    freeEval n (u ++ v) = freeEval n u * freeEval n v := by simp [freeEval]

@[simp] theorem freeEval_inverse (n : Nat) (w : Word) :
    freeEval n (inverse w) = (freeEval n w)⁻¹ := by
  induction w with
  | nil => simp
  | cons a w ih =>
    rw [inverse_cons, freeEval_append, ih]
    simp only [freeEval_cons, freeEval_nil, freeLetter_flip, mul_one, mul_inv_rev]

def relators (P : Presentation) : Set (FreeGroup (Fin (genCount P))) :=
  {r | r ∈ P.2.map (freeEval (genCount P))}

abbrev GroupOf (P : Presentation) := PresentedGroup (relators P)

def letter (P : Presentation) (a : Nat) : GroupOf P :=
  PresentedGroup.mk (relators P) (freeLetter (genCount P) a)

def value (P : Presentation) (w : Word) : GroupOf P := (w.map (letter P)).prod

@[simp] theorem letter_flip (P : Presentation) (a : Nat) :
    letter P (flip a) = (letter P a)⁻¹ := by simp only [letter, freeLetter_flip, map_inv]

@[simp] theorem value_nil (P : Presentation) : value P [] = 1 := rfl
@[simp] theorem value_cons (P : Presentation) (a : Nat) (w : Word) :
    value P (a :: w) = letter P a * value P w := rfl
@[simp] theorem value_append (P : Presentation) (u v : Word) :
    value P (u ++ v) = value P u * value P v := by simp [value]

@[simp] theorem value_inverse (P : Presentation) (w : Word) :
    value P (inverse w) = (value P w)⁻¹ := by
  induction w with
  | nil => simp
  | cons a w ih =>
    rw [inverse_cons, value_append, ih]
    simp only [value_cons, value_nil, letter_flip, mul_one, mul_inv_rev]

theorem value_eq_mk (P : Presentation) (w : Word) :
    value P w = PresentedGroup.mk (relators P) (freeEval (genCount P) w) := by
  induction w with
  | nil => simp
  | cons a w ih => simp only [value_cons, freeEval_cons, map_mul, letter, ih]

theorem value_surjective_valid (P : Presentation) (g : GroupOf P) :
    ∃ w : Word, ValidWord P w ∧ value P w = g := by
  obtain ⟨x, rfl⟩ := PresentedGroup.mk_surjective (relators P) g
  induction x using FreeGroup.induction_on with
  | C1 => exact ⟨[], by simp, by simp⟩
  | of i =>
    refine ⟨[2 * i.val], ?_, ?_⟩
    · intro a ha
      have he : a = 2 * i.val := List.mem_singleton.mp ha
      rw [he]
      have hi := i.isLt
      omega
    · simp only [value_cons, value_nil, mul_one, letter, freeLetter_even]
  | inv_of i ih =>
    obtain ⟨w, hw, he⟩ := ih
    exact ⟨inverse w, validWord_inverse P w hw, by rw [value_inverse, he, map_inv]⟩
  | mul x y ihx ihy =>
    obtain ⟨u, hu, heu⟩ := ihx
    obtain ⟨v, hv, hev⟩ := ihy
    exact ⟨u ++ v, (validWord_append P u v).mpr ⟨hu, hv⟩, by rw [value_append, heu, hev, map_mul]⟩

def encodeLetter (a : Nat × Bool) : Nat := 2 * a.1 + if a.2 then 0 else 1
def decodeLetter (a : Nat) : Nat × Bool := (a / 2, decide (a % 2 = 0))
def encodeRaw (w : List (Nat × Bool)) : Word := w.map encodeLetter
def decodeRaw (w : Word) : List (Nat × Bool) := w.map decodeLetter

@[simp] theorem decode_encode_letter (a : Nat × Bool) : decodeLetter (encodeLetter a) = a := by
  rcases a with ⟨i, b⟩
  cases b <;> simp [decodeLetter, encodeLetter, Nat.add_div, Nat.add_mod]

@[simp] theorem encode_decode_letter (a : Nat) : encodeLetter (decodeLetter a) = a := by
  unfold encodeLetter decodeLetter
  simp only [decide_eq_true_eq]
  split <;> omega

@[simp] theorem decode_encode_raw (w : List (Nat × Bool)) : decodeRaw (encodeRaw w) = w := by
  simp [decodeRaw, encodeRaw, List.map_map, Function.comp_def]

@[simp] theorem encode_decode_raw (w : Word) : encodeRaw (decodeRaw w) = w := by
  simp [decodeRaw, encodeRaw, List.map_map, Function.comp_def]

theorem encodeRaw_valid (n : Nat) (w : List (Nat × Bool))
    (hw : ∀ a ∈ w, a.1 < n) : ∀ a ∈ encodeRaw w, a < 2 * n := by
  intro a ha
  obtain ⟨⟨i, b⟩, hb, rfl⟩ := List.mem_map.mp ha
  have hi := hw (i, b) hb
  cases b <;> simp only [encodeLetter, Bool.false_eq_true, if_false, if_true] <;> omega

theorem decodeRaw_valid (n : Nat) (w : Word) (hw : ∀ a ∈ w, a < 2 * n) :
    ∀ a ∈ decodeRaw w, a.1 < n := by
  intro a ha
  obtain ⟨b, hb, rfl⟩ := List.mem_map.mp ha
  have hi := hw b hb
  change b / 2 < n
  omega

theorem genCount_primrec : Primrec genCount := Primrec.fst

theorem validWord_primrec : PrimrecRel ValidWord := by
  have hr : PrimrecRel (fun a k : Nat => a < 2 * k) :=
    Primrec.nat_lt.comp Primrec.fst (Primrec.nat_mul.comp (Primrec.const 2) Primrec.snd)
  exact hr.forall_mem_list.comp Primrec.snd (genCount_primrec.comp Primrec.fst)

theorem flip_primrec : Primrec flip := by
  have he : PrimrecPred (fun a : Nat => a % 2 = 0) :=
    Primrec.eq.comp (Primrec.nat_mod.comp Primrec.id (Primrec.const 2)) (Primrec.const 0)
  exact (Primrec.cond he.decide Primrec.succ
    (Primrec.nat_sub.comp Primrec.id (Primrec.const 1))).of_eq
      (fun a => by simp only [Bool.cond_decide]; rfl)

theorem inverse_primrec : Primrec inverse :=
  Primrec.list_map Primrec.list_reverse (Primrec.to₂ (flip_primrec.comp Primrec.snd))

theorem encodeLetter_primrec : Primrec encodeLetter := by
  have hs : Primrec (fun a : Nat × Bool => if a.2 then 0 else 1) :=
    (Primrec.cond Primrec.snd (Primrec.const 0) (Primrec.const 1)).of_eq
      (fun a => by cases a.2 <;> rfl)
  exact Primrec.nat_add.comp (Primrec.nat_mul.comp (Primrec.const 2) Primrec.fst) hs

theorem decodeLetter_primrec : Primrec decodeLetter :=
  (Primrec.nat_div.comp Primrec.id (Primrec.const 2)).pair
    (Primrec.eq.comp (Primrec.nat_mod.comp Primrec.id (Primrec.const 2)) (Primrec.const 0)).decide

theorem encodeRaw_primrec : Primrec encodeRaw :=
  Primrec.list_map Primrec.id (Primrec.to₂ (encodeLetter_primrec.comp Primrec.snd))

theorem decodeRaw_primrec : Primrec decodeRaw :=
  Primrec.list_map Primrec.id (Primrec.to₂ (decodeLetter_primrec.comp Primrec.snd))

end DCPv7.FinitePresentation
