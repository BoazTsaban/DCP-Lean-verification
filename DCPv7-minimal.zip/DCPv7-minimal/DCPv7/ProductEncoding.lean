import Std

/-! A concrete input encoding for Corollary `cor:products`.

Product words use the union of the coordinate-supported standard generators.
Projecting a supplied generating word retains exactly its letters in the chosen
coordinate. Projection is also proved to commute with substitution in the
original supplied subgroup generators, which is needed for the paper's final
coordinatewise witness test.
-/
namespace DCPv7.ProductEncoding

abbrev Letter := Nat × Bool
abbrev Word := List Letter
abbrev ProductLetter := Nat × Letter
abbrev ProductWord := List ProductLetter

def flip (a : Letter) : Letter := (a.1, !a.2)
def productFlip (a : ProductLetter) : ProductLetter := (a.1, flip a.2)
def inverse (w : Word) : Word := w.reverse.map flip
def productInverse (w : ProductWord) : ProductWord := w.reverse.map productFlip

def project (i : Nat) : ProductWord → Word
  | [] => []
  | (j, a) :: w => if j = i then a :: project i w else project i w

@[simp] theorem project_nil (i : Nat) : project i [] = [] := rfl

@[simp] theorem project_append (i : Nat) (u v : ProductWord) :
    project i (u ++ v) = project i u ++ project i v := by
  induction u with
  | nil => rfl
  | cons a u ih =>
    rcases a with ⟨j, a⟩
    by_cases h : j = i <;> simp [project, h, ih]

@[simp] theorem inverse_nil : inverse [] = [] := rfl
@[simp] theorem productInverse_nil : productInverse [] = [] := rfl

theorem inverse_cons (a : Letter) (w : Word) :
    inverse (a :: w) = inverse w ++ [flip a] := by
  simp [inverse]

theorem productInverse_cons (a : ProductLetter) (w : ProductWord) :
    productInverse (a :: w) = productInverse w ++ [productFlip a] := by
  simp [productInverse]

@[simp] theorem project_inverse (i : Nat) (w : ProductWord) :
    project i (productInverse w) = inverse (project i w) := by
  induction w with
  | nil => rfl
  | cons a w ih =>
    rcases a with ⟨j, a⟩
    rw [productInverse_cons, project_append, ih]
    by_cases h : j = i <;> simp [project, productFlip, h, inverse_cons]

theorem project_getD (i : Nat) (s : List ProductWord) (j : Nat) :
    project i (s.getD j []) = (s.map (project i)).getD j [] := by
  induction s generalizing j with
  | nil => simp
  | cons u s ih =>
    cases j with
    | zero => rfl
    | succ j => simpa using ih j

def chunk (s : List Word) (a : Letter) : Word :=
  if a.2 then s.getD a.1 [] else inverse (s.getD a.1 [])

def productChunk (s : List ProductWord) (a : Letter) : ProductWord :=
  if a.2 then s.getD a.1 [] else productInverse (s.getD a.1 [])

def substitute (s : List Word) (w : Word) : Word := w.flatMap (chunk s)
def productSubstitute (s : List ProductWord) (w : Word) : ProductWord :=
  w.flatMap (productChunk s)

theorem project_chunk (i : Nat) (s : List ProductWord) (a : Letter) :
    project i (productChunk s a) = chunk (s.map (project i)) a := by
  rcases a with ⟨j, b⟩
  cases b with
  | false =>
    change project i (productInverse (s.getD j [])) =
      inverse ((s.map (project i)).getD j [])
    rw [project_inverse, project_getD]
  | true => exact project_getD i s j

theorem project_substitute (i : Nat) (s : List ProductWord) (w : Word) :
    project i (productSubstitute s w) = substitute (s.map (project i)) w := by
  induction w with
  | nil => rfl
  | cons a w ih =>
    change project i (productChunk s a ++ productSubstitute s w) =
      chunk (s.map (project i)) a ++ substitute (s.map (project i)) w
    rw [project_append, project_chunk, ih]

/-- Tags are 0=braid, 1=B, 2=D, 3=E, 4=H; H of rank two is I₂(5). -/
abbrev FactorCode := Nat × Nat

def generatorCount (c : FactorCode) : Nat := if c.1 = 0 then c.2 - 1 else c.2

/-- Exactly the source types and ranks in the manuscript's two corollaries. -/
def ValidFactor (c : FactorCode) : Prop :=
  (c.1 = 0 ∧ 1 ≤ c.2) ∨ (c.1 = 1 ∧ 2 ≤ c.2) ∨
  (c.1 = 2 ∧ 4 ≤ c.2) ∨ (c.1 = 3 ∧ (c.2 = 6 ∨ c.2 = 7)) ∨
  (c.1 = 4 ∧ (c.2 = 2 ∨ c.2 = 3))

abbrev Input := List FactorCode ×
  (List ProductWord × (List ProductWord × (ProductWord × ProductWord)))

abbrev CoordinateInput := FactorCode × (List Word × (List Word × (Word × Word)))

def coordinateInput (p : Input) (i : Nat) : CoordinateInput :=
  (p.1.getD i (0, 1),
    ((p.2.1.map (project i)),
      ((p.2.2.1.map (project i)), (project i p.2.2.2.1, project i p.2.2.2.2))))

def WordValid (factors : List FactorCode) (w : ProductWord) : Prop :=
  ∀ a ∈ w, a.1 < factors.length ∧ a.2.1 < generatorCount (factors.getD a.1 (0, 1))

theorem project_valid (factors : List FactorCode) (i : Nat) (w : ProductWord)
    (hw : WordValid factors w) :
    ∀ a ∈ project i w, a.1 < generatorCount (factors.getD i (0, 1)) := by
  induction w with
  | nil => simp
  | cons a w ih =>
    rcases a with ⟨j, a⟩
    have ha := hw (j, a) (by simp)
    have ht : WordValid factors w := fun b hb => hw b (by simp [hb])
    by_cases h : j = i
    · subst j
      rw [project, if_pos rfl]
      intro b hb
      rcases List.mem_cons.mp hb with he | hm
      · subst b
        exact ha.2
      · exact ih ht b hm
    · simpa only [project, if_neg h] using ih ht

end DCPv7.ProductEncoding
