import DCPv7.EncodedAutomatonPaths
import Mathlib.Data.List.GetD
import Mathlib.Data.Nat.Pairing

/-! An explicit finite-table intersection construction. Pairing may allocate
unused states; this affects efficiency, not finiteness or computability.
-/
namespace DCPv7.EncodedAutomaton
set_option backward.isDefEq.respectTransparency false

def intersectionStates (D E : Code) : Nat := Nat.pair (totalStates D) (totalStates E) + 1

def intersectionRow (D E : Code) (q : Nat) : List Nat :=
  (List.range (min (alphabetSize D) (alphabetSize E))).map fun a =>
    Nat.pair (step D q.unpair.1 a) (step E q.unpair.2 a)

def intersectionFlag (D E : Code) (q : Nat) : Bool :=
  acceptState D q.unpair.1 && acceptState E q.unpair.2

def intersection (D E : Code) : Code :=
  (min (alphabetSize D) (alphabetSize E),
    (Nat.pair (totalStates D) (totalStates E),
      (Nat.pair (startState D) (startState E),
        ((List.range (intersectionStates D E)).map (intersectionRow D E),
          (List.range (intersectionStates D E)).map (intersectionFlag D E)))))

theorem pair_lt_intersectionStates (D E : Code) (q r : Nat)
    (hq : q < totalStates D) (hr : r < totalStates E) :
    Nat.pair q r < intersectionStates D E := by
  have h := (Nat.pair_lt_pair_left r hq).trans (Nat.pair_lt_pair_right (totalStates D) hr)
  exact Nat.lt_succ_of_lt h

theorem getD_map_range {α : Type} (f : Nat → α) (n i : Nat) (hi : i < n) (d : α) :
    ((List.range n).map f).getD i d = f i := by
  rw [List.getD_eq_getElem _ d (by simpa using hi)]
  simp only [List.getElem_map, List.getElem_range]

theorem intersection_start (D E : Code) :
    startState (intersection D E) = Nat.pair (startState D) (startState E) + 1 := by
  have h := pair_lt_intersectionStates D E _ _ (startState_lt D) (startState_lt E)
  change Nat.pair (startState D) (startState E) % intersectionStates D E + 1 = _
  rw [Nat.mod_eq_of_lt h]

theorem intersection_step (D E : Code) (q r a : Nat)
    (hq : q < totalStates D) (hr : r < totalStates E)
    (ha : a < min (alphabetSize D) (alphabetSize E)) :
    step (intersection D E) (Nat.pair q r + 1) a =
      Nat.pair (step D q a) (step E r a) + 1 := by
  have ha' : a < alphabetSize (intersection D E) := ha
  rw [step, if_neg (by omega), if_pos ha']
  change ((((List.range (intersectionStates D E)).map (intersectionRow D E)).getD
    (Nat.pair q r + 1 - 1) []).getD a 0) % intersectionStates D E + 1 = _
  rw [Nat.add_sub_cancel, getD_map_range _ _ _ (pair_lt_intersectionStates D E q r hq hr)]
  unfold intersectionRow
  rw [getD_map_range _ _ _ ha]
  simp only [Nat.unpair_pair]
  rw [Nat.mod_eq_of_lt (pair_lt_intersectionStates D E _ _ (step_lt D q a) (step_lt E r a))]

theorem intersection_accept (D E : Code) (q r : Nat)
    (hq : q < totalStates D) (hr : r < totalStates E) :
    acceptState (intersection D E) (Nat.pair q r + 1) = (acceptState D q && acceptState E r) := by
  rw [acceptState, if_neg (by omega)]
  change ((List.range (intersectionStates D E)).map (intersectionFlag D E)).getD
    (Nat.pair q r + 1 - 1) false = _
  rw [Nat.add_sub_cancel, getD_map_range _ _ _ (pair_lt_intersectionStates D E q r hq hr)]
  simp only [intersectionFlag, Nat.unpair_pair]

theorem evalFrom_lt (D : Code) (q : Nat) (hq : q < totalStates D) (w : List Nat) :
    evalFrom D q w < totalStates D := by
  induction w generalizing q with
  | nil => exact hq
  | cons a w ih => exact ih (step D q a) (step_lt D q a)

theorem intersection_evalFrom (D E : Code) (q r : Nat)
    (hq : q < totalStates D) (hr : r < totalStates E)
    (w : List Nat) (hw : ∀ a ∈ w, a < min (alphabetSize D) (alphabetSize E)) :
    evalFrom (intersection D E) (Nat.pair q r + 1) w =
      Nat.pair (evalFrom D q w) (evalFrom E r w) + 1 := by
  induction w generalizing q r with
  | nil => rfl
  | cons a w ih =>
    rw [evalFrom_cons, intersection_step D E q r a hq hr (hw a (by simp))]
    exact ih (step D q a) (step E r a) (step_lt D q a) (step_lt E r a)
      (fun b hb => hw b (by simp [hb]))

theorem intersection_correct (D E : Code) (w : List Nat) :
    (machine (intersection D E)).Accepts w ↔ (machine D).Accepts w ∧ (machine E).Accepts w := by
  change acceptState (intersection D E)
    ((machine (intersection D E)).evalFrom (machine (intersection D E)).start w).val = true ↔
      (machine D).Accepts w ∧ (machine E).Accepts w
  rw [machine_evalFrom]
  change acceptState (intersection D E) (evalFrom (intersection D E) (startState (intersection D E)) w) = true ↔
    acceptState D ((machine D).evalFrom (machine D).start w).val = true ∧
      acceptState E ((machine E).evalFrom (machine E).start w).val = true
  rw [machine_evalFrom, machine_evalFrom]
  by_cases hw : ∀ a ∈ w, a < min (alphabetSize D) (alphabetSize E)
  · rw [intersection_start, intersection_evalFrom D E _ _ (startState_lt D) (startState_lt E) w hw,
      intersection_accept D E _ _ (evalFrom_lt D _ (startState_lt D) w)
        (evalFrom_lt E _ (startState_lt E) w)]
    simp only [Bool.and_eq_true]
    rfl
  · constructor
    · intro h
      exact False.elim (hw (accepted_alphabet (intersection D E) _ w h))
    · rintro ⟨hD, hE⟩
      exact False.elim (hw (fun a ha => lt_min
        (accepted_alphabet D _ w hD a ha) (accepted_alphabet E _ w hE a ha)))

theorem intersectionRow_primrec : Primrec₂ (fun p : Code × Code => intersectionRow p.1 p.2) := by
  have hq : Primrec (fun p : ((Code × Code) × Nat) × Nat => p.1.2.unpair) :=
    Primrec.unpair.comp (Primrec.snd.comp Primrec.fst)
  have hpD : Primrec (fun p : ((Code × Code) × Nat) × Nat =>
      (p.1.1.1, (p.1.2.unpair.1, p.2))) :=
    (Primrec.fst.comp (Primrec.fst.comp Primrec.fst)).pair ((Primrec.fst.comp hq).pair Primrec.snd)
  have hpE : Primrec (fun p : ((Code × Code) × Nat) × Nat =>
      (p.1.1.2, (p.1.2.unpair.2, p.2))) :=
    (Primrec.snd.comp (Primrec.fst.comp Primrec.fst)).pair ((Primrec.snd.comp hq).pair Primrec.snd)
  have hD := Primrec.comp step_primrec hpD
  have hE := Primrec.comp step_primrec hpE
  have hpair : Primrec₂ (fun p : (Code × Code) × Nat => fun a : Nat =>
      Nat.pair (step p.1.1 p.2.unpair.1 a) (step p.1.2 p.2.unpair.2 a)) :=
    (Primrec₂.natPair.comp hD hE).of_eq (fun p => rfl)
  have ha : Primrec (fun p : (Code × Code) × Nat =>
      List.range (min (alphabetSize p.1.1) (alphabetSize p.1.2))) :=
    Primrec.list_range.comp (Primrec.nat_min.comp
      (alphabetSize_primrec.comp (Primrec.fst.comp Primrec.fst))
      (alphabetSize_primrec.comp (Primrec.snd.comp Primrec.fst)))
  exact Primrec.list_map ha hpair

theorem intersectionFlag_primrec : Primrec₂ (fun p : Code × Code => intersectionFlag p.1 p.2) := by
  have hq : Primrec (fun p : (Code × Code) × Nat => p.2.unpair) := Primrec.unpair.comp Primrec.snd
  exact Primrec.and.comp
    (acceptState_primrec.comp (Primrec.fst.comp Primrec.fst) (Primrec.fst.comp hq))
    (acceptState_primrec.comp (Primrec.snd.comp Primrec.fst) (Primrec.snd.comp hq))

theorem intersection_primrec : Primrec₂ intersection := by
  have hn : Primrec (fun p : Code × Code => Nat.pair (totalStates p.1) (totalStates p.2)) :=
    Primrec₂.natPair.comp (totalStates_primrec.comp Primrec.fst) (totalStates_primrec.comp Primrec.snd)
  have hs : Primrec (fun p : Code × Code => Nat.pair (startState p.1) (startState p.2)) :=
    Primrec₂.natPair.comp (startState_primrec.comp Primrec.fst) (startState_primrec.comp Primrec.snd)
  have hrange := Primrec.list_range.comp (Primrec.succ.comp hn)
  have hrows := Primrec.list_map hrange intersectionRow_primrec
  have hflags := Primrec.list_map hrange intersectionFlag_primrec
  have halpha := Primrec.nat_min.comp
    (alphabetSize_primrec.comp Primrec.fst) (alphabetSize_primrec.comp Primrec.snd)
  exact halpha.pair (hn.pair (hs.pair (hrows.pair hflags)))

def intersectAll (base : Code) (others : List Code) : Code := others.foldl intersection base

theorem intersectAll_primrec : Primrec₂ intersectAll := foldl_primrec intersection intersection_primrec

theorem intersectAll_correct (base : Code) (others : List Code) (w : List Nat) :
    (machine (intersectAll base others)).Accepts w ↔
      (machine base).Accepts w ∧ ∀ D ∈ others, (machine D).Accepts w := by
  induction others generalizing base with
  | nil => simp [intersectAll]
  | cons D ds ih =>
    change (machine (intersectAll (intersection base D) ds)).Accepts w ↔ _
    rw [ih, intersection_correct]
    simp only [List.mem_cons, forall_eq_or_imp, and_assoc]

end DCPv7.EncodedAutomaton
