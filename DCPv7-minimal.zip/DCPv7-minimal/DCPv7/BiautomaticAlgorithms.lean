import DCPv7.BiautomaticInterfaces

/-! Promise-partial composition of the cited presentation-to-structure and
word-problem procedures with the finite automaton deductions of the paper.
No termination on non-biautomatic presentations is asserted.
-/
namespace DCPv7.Biautomatic
open FinitePresentation
set_option backward.isDefEq.respectTransparency false

def wordRun (B : StructureConstruction) (W : WordProblemConstruction)
    (p : Presentation × (Word × Word)) : Part Bool :=
  (B.run p.1).bind fun s => W.run ((p.1, s), p.2)

theorem wordRun_partrec (B : StructureConstruction) (W : WordProblemConstruction) :
    Partrec (wordRun B W) := by
  have hb : Partrec (fun p : Presentation × (Word × Word) => B.run p.1) :=
    B.partrec.comp Computable.fst
  have hargs : Computable (fun q : (Presentation × (Word × Word)) × StructureCode =>
      ((q.1.1, q.2), q.1.2)) :=
    ((Computable.fst.comp Computable.fst).pair Computable.snd).pair
      (Computable.snd.comp Computable.fst)
  have hw := W.partrec.comp hargs
  exact Partrec.bind hb hw

theorem wordRun_spec (B : StructureConstruction) (W : WordProblemConstruction)
    (P : Presentation) (hP : IsBiautomatic P) (u v : Word)
    (hu : ValidWord P u) (hv : ValidWord P v) :
    (wordRun B W (P, (u, v))).Dom ∧
      ∀ b ∈ wordRun B W (P, (u, v)), (b = true ↔ value P u = value P v) := by
  have hB := B.correct P hP
  constructor
  · obtain ⟨s, hs⟩ := Part.dom_iff_mem.mp hB.1
    obtain ⟨b, hb⟩ := Part.dom_iff_mem.mp (W.correct P s (hB.2 s hs) u v hu hv).1
    exact Part.dom_iff_mem.mpr ⟨b, Part.mem_bind hs hb⟩
  · intro b hb
    obtain ⟨s, hs, hword⟩ := Part.mem_bind_iff.mp hb
    exact (W.correct P s (hB.2 s hs) u v hu hv).2 b hword

def centralizerRun (B : StructureConstruction) (A : StructuredAlgorithms)
    (p : Presentation × List Word) : Part (List Word) :=
  (B.run p.1).map fun s => A.centralizer ((p.1, s), p.2)

theorem centralizerRun_partrec (B : StructureConstruction) (A : StructuredAlgorithms) :
    Partrec (centralizerRun B A) := by
  have hb : Partrec (fun p : Presentation × List Word => B.run p.1) :=
    B.partrec.comp Computable.fst
  have hargs : Computable (fun q : (Presentation × List Word) × StructureCode =>
      ((q.1.1, q.2), q.1.2)) :=
    ((Computable.fst.comp Computable.fst).pair Computable.snd).pair
      (Computable.snd.comp Computable.fst)
  exact Partrec.map hb (A.centralizer_computable.comp hargs)

theorem centralizerRun_spec (B : StructureConstruction) (A : StructuredAlgorithms)
    (P : Presentation) (hP : IsBiautomatic P) (s : List Word)
    (hs : ∀ w ∈ s, ValidWord P w) :
    (centralizerRun B A (P, s)).Dom ∧ ∀ t ∈ centralizerRun B A (P, s),
      (∀ w ∈ t, ValidWord P w) ∧ Subgroup.closure {g | g ∈ t.map (value P)} =
        Subgroup.centralizer (subgroup P s : Set (GroupOf P)) := by
  have hB := B.correct P hP
  constructor
  · exact hB.1
  · intro t ht
    obtain ⟨c, hc, he⟩ := (Part.mem_map_iff _).mp ht
    rw [← he]
    exact A.centralizer_spec P c (hB.2 c hc) s hs

def simultaneousRun (B : StructureConstruction) (A : StructuredAlgorithms)
    (p : Presentation × List (Word × Word)) : Part Bool :=
  (B.run p.1).map fun s => A.simultaneous ((p.1, s), p.2)

theorem simultaneousRun_partrec (B : StructureConstruction) (A : StructuredAlgorithms) :
    Partrec (simultaneousRun B A) := by
  have hb : Partrec (fun p : Presentation × List (Word × Word) => B.run p.1) :=
    B.partrec.comp Computable.fst
  have hargs : Computable (fun q : (Presentation × List (Word × Word)) × StructureCode =>
      ((q.1.1, q.2), q.1.2)) :=
    ((Computable.fst.comp Computable.fst).pair Computable.snd).pair
      (Computable.snd.comp Computable.fst)
  exact Partrec.map hb (A.simultaneous_computable.comp hargs)

theorem simultaneousRun_spec (B : StructureConstruction) (A : StructuredAlgorithms)
    (P : Presentation) (hP : IsBiautomatic P) (e : List (Word × Word)) (he : InstanceValid P e) :
    (simultaneousRun B A (P, e)).Dom ∧ ∀ b ∈ simultaneousRun B A (P, e),
      (b = true ↔ InstanceSolvable P e) := by
  have hB := B.correct P hP
  constructor
  · exact hB.1
  · intro b hb
    obtain ⟨s, hs, hvalue⟩ := (Part.mem_map_iff _).mp hb
    rw [← hvalue]
    exact A.simultaneous_spec P s (hB.2 s hs) e he

def ofStructure (B : StructureConstruction) (W : WordProblemConstruction)
    (A : StructuredAlgorithms) : Algorithms where
  word := wordRun B W
  word_partrec := wordRun_partrec B W
  word_spec := wordRun_spec B W
  centralizer := centralizerRun B A
  centralizer_partrec := centralizerRun_partrec B A
  centralizer_spec := centralizerRun_spec B A
  simultaneous := simultaneousRun B A
  simultaneous_partrec := simultaneousRun_partrec B A
  simultaneous_spec := simultaneousRun_spec B A

end DCPv7.Biautomatic
