import DCPv7.BiautomaticInterfaces
import DCPv7.MultiplierLanguages

/-! The local R_u ∩ S_v, first-coordinate projection deduction in the paper.
The fixed multipliers are cited inputs; the projection compiler is a verified
standard automata operation. The conjugator conclusion is proved here.
-/
namespace DCPv7.Biautomatic
open FinitePresentation
set_option backward.isDefEq.respectTransparency false

abbrev ConjugatorInput := (Presentation × StructureCode) × (Word × Word)

def conjugatorCode (M : FixedMultipliers) (proj : PaddedWords.ProjectionCompiler)
    (p : ConjugatorInput) : Code :=
  proj.code (2 * genCount p.1.1,
    EncodedAutomaton.intersection (M.leftCode (p.1.2, p.2.1)) (M.rightCode (p.1.2, p.2.2)))

theorem conjugatorCode_computable (M : FixedMultipliers) (proj : PaddedWords.ProjectionCompiler) :
    Computable (conjugatorCode M proj) := by
  have hL : Computable (fun p : ConjugatorInput => M.leftCode (p.1.2, p.2.1)) :=
    M.left_computable.comp
      ((Computable.snd.comp Computable.fst).pair (Computable.fst.comp Computable.snd))
  have hR : Computable (fun p : ConjugatorInput => M.rightCode (p.1.2, p.2.2)) :=
    M.right_computable.comp
      ((Computable.snd.comp Computable.fst).pair (Computable.snd.comp Computable.snd))
  have hrel := EncodedAutomaton.intersection_primrec.to_comp.comp hL hR
  have hn : Primrec (fun p : ConjugatorInput => 2 * genCount p.1.1) :=
    Primrec.nat_mul.comp (Primrec.const 2) (Primrec.fst.comp (Primrec.fst.comp Primrec.fst))
  exact proj.computable.comp (hn.to_comp.pair hrel)

theorem conjugatorCode_alphabet (M : FixedMultipliers) (proj : PaddedWords.ProjectionCompiler)
    (P : Presentation) (s : StructureCode) (u v : Word) :
    EncodedAutomaton.alphabetSize (conjugatorCode M proj ((P, s), (u, v))) = 2 * genCount P :=
  proj.alphabet _ _

theorem conjugatorCode_correct (M : FixedMultipliers) (proj : PaddedWords.ProjectionCompiler)
    (P : Presentation) (s : StructureCode) (hs : StructureSpec P s)
    (u v : Word) (hu : ValidWord P u) (hv : ValidWord P v) (w : Word) :
    (EncodedAutomaton.machine (conjugatorCode M proj ((P, s), (u, v)))).Accepts w ↔
      Accepts s w ∧ (value P w)⁻¹ * value P u * value P w = value P v := by
  rw [conjugatorCode, proj.correct]
  constructor
  · rintro ⟨_, t, ht, hfirst⟩
    obtain ⟨hL, hR⟩ := (EncodedAutomaton.intersection_correct _ _ t).mp ht
    obtain ⟨p, q, rfl, hp, hq, heL⟩ := (M.left_spec P s hs u hu t).mp hL
    obtain ⟨p', q', he, _, _, heR⟩ :=
      (M.right_spec P s hs v hv (PaddedWords.pad p q)).mp hR
    obtain ⟨hpp, hqq⟩ := PaddedWords.pad_injective he
    subst p'
    subst q'
    have hpw : p = w := by simpa only [PaddedWords.firstProjection_pad] using hfirst
    subst w
    simp only [PaddedWords.firstProjection_pad]
    apply (MultiplierLanguages.conjugatorLanguage_iff (Accepts s) (value P)
      hs.representatives (value P u) (value P v) p).mp
    exact ⟨q, ⟨hp, hq, heL⟩, ⟨hp, hq, heR⟩⟩
  · intro h
    obtain ⟨q, hL, hR⟩ := (MultiplierLanguages.conjugatorLanguage_iff (Accepts s) (value P)
      hs.representatives (value P u) (value P v) w).mpr h
    refine ⟨accepted_valid P s hs w h.1, PaddedWords.pad w q,
      (EncodedAutomaton.intersection_correct _ _ _).mpr ⟨?_, ?_⟩,
      PaddedWords.firstProjection_pad w q⟩
    · exact (M.left_spec P s hs u hu _).mpr ⟨w, q, rfl, h.1, hL.2.1, hL.2.2⟩
    · exact (M.right_spec P s hs v hv _).mpr ⟨w, q, rfl, h.1, hR.2.1, hR.2.2⟩

def ofMultipliers (M : FixedMultipliers) (proj : PaddedWords.ProjectionCompiler) : ConjugatorCompiler where
  code := conjugatorCode M proj
  computable := conjugatorCode_computable M proj
  alphabet := conjugatorCode_alphabet M proj
  correct := conjugatorCode_correct M proj

end DCPv7.Biautomatic
