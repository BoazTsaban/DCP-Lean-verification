import DCPv7.RestrictedAutomatonPaths
import DCPv7.LengthComputability
import DCPv7.FiniteScan

/-! Natural-number/list codes for actual finite automata. State zero is a
rejecting sink, including for symbols outside the declared alphabet. The real
state count is positive; the alphabet may be empty. No reachability or language
decision oracle is included in the code.
-/
namespace DCPv7.EncodedAutomaton
set_option backward.isDefEq.respectTransparency false

abbrev Code := Nat × (Nat × (Nat × (List (List Nat) × List Bool)))

def alphabetSize (D : Code) : Nat := D.1
def realStates (D : Code) : Nat := D.2.1 + 1
def transitions (D : Code) : List (List Nat) := D.2.2.2.1
def accepting (D : Code) : List Bool := D.2.2.2.2
def startState (D : Code) : Nat := D.2.2.1 % realStates D + 1
def totalStates (D : Code) : Nat := realStates D + 1

def step (D : Code) (q a : Nat) : Nat :=
  if q = 0 then 0 else
  if a < alphabetSize D then
    ((transitions D).getD (q - 1) []).getD a 0 % realStates D + 1
  else 0

def acceptState (D : Code) (q : Nat) : Bool :=
  if q = 0 then false else (accepting D).getD (q - 1) false

def evalFrom (D : Code) (q : Nat) (w : List Nat) : Nat := w.foldl (step D) q

@[simp] theorem evalFrom_nil (D : Code) (q : Nat) : evalFrom D q [] = q := rfl
@[simp] theorem evalFrom_cons (D : Code) (q a : Nat) (w : List Nat) :
    evalFrom D q (a :: w) = evalFrom D (step D q a) w := rfl

theorem startState_lt (D : Code) : startState D < totalStates D := by
  have h := Nat.mod_lt D.2.2.1 (show 0 < realStates D by simp [realStates])
  unfold startState totalStates
  omega

theorem step_lt (D : Code) (q a : Nat) : step D q a < totalStates D := by
  have h := Nat.mod_lt (((transitions D).getD (q - 1) []).getD a 0)
    (show 0 < realStates D by simp [realStates])
  unfold step totalStates
  split
  · simp [realStates]
  · split <;> omega

@[simp] theorem step_zero (D : Code) (a : Nat) : step D 0 a = 0 := by simp [step]
@[simp] theorem acceptState_zero (D : Code) : acceptState D 0 = false := by simp [acceptState]

@[simp] theorem evalFrom_zero (D : Code) (w : List Nat) : evalFrom D 0 w = 0 := by
  induction w with
  | nil => rfl
  | cons a w ih => simpa only [evalFrom_cons, step_zero] using ih

theorem accepted_alphabet (D : Code) (q : Nat) (w : List Nat)
    (hw : acceptState D (evalFrom D q w) = true) : ∀ a ∈ w, a < alphabetSize D := by
  induction w generalizing q with
  | nil => simp
  | cons a w ih =>
    have ha : a < alphabetSize D := by
      by_contra hn
      have hz : step D q a = 0 := by simp [step, hn]
      simp only [evalFrom_cons, hz, evalFrom_zero, acceptState_zero, Bool.false_eq_true] at hw
    intro b hb
    rcases List.mem_cons.mp hb with rfl | hb
    · exact ha
    · exact ih (step D q a) hw b hb

def machine (D : Code) : WordAutomaton Nat (Fin (totalStates D)) where
  start := ⟨startState D, startState_lt D⟩
  step q a := ⟨step D q.val a, step_lt D q.val a⟩
  accept q := acceptState D q.val = true

instance (D : Code) : DecidablePred (machine D).accept := fun q =>
  inferInstanceAs (Decidable (acceptState D q.val = true))

theorem machine_evalFrom (D : Code) (q : Fin (totalStates D)) (w : List Nat) :
    ((machine D).evalFrom q w).val = evalFrom D q.val w := by
  induction w generalizing q with
  | nil => rfl
  | cons a w ih => exact ih ((machine D).step q a)

theorem useful_alphabet (D : Code) (q : Fin (totalStates D)) (hq : (machine D).Useful q) :
    (machine D).AlphabetUseful (List.range (alphabetSize D)) q := by
  obtain ⟨p, t, hp, ht⟩ := hq
  have hw : (machine D).Accepts (p ++ t) := by
    simp only [WordAutomaton.Accepts, WordAutomaton.evalFrom_append, hp]
    exact ht
  change acceptState D ((machine D).evalFrom (machine D).start (p ++ t)).val = true at hw
  rw [machine_evalFrom] at hw
  have hletters := accepted_alphabet D (startState D) (p ++ t) hw
  refine ⟨p, t, hp, ht, ?_, ?_⟩
  · intro a ha
    exact List.mem_range.mpr (hletters a (List.mem_append_left t ha))
  · intro a ha
    exact List.mem_range.mpr (hletters a (List.mem_append_right p ha))

def trimPaths (D : Code) : (machine D).TrimPaths :=
  (machine D).restrictedTrimPaths (List.range (alphabetSize D)) (useful_alphabet D)

theorem alphabetSize_primrec : Primrec alphabetSize := Primrec.fst
theorem realStates_primrec : Primrec realStates :=
  Primrec.succ.comp (Primrec.fst.comp Primrec.snd)
theorem transitions_primrec : Primrec transitions :=
  Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))
theorem accepting_primrec : Primrec accepting :=
  Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))
theorem startState_primrec : Primrec startState :=
  Primrec.succ.comp (Primrec.nat_mod.comp
    (Primrec.fst.comp (Primrec.snd.comp Primrec.snd)) realStates_primrec)
theorem totalStates_primrec : Primrec totalStates := Primrec.succ.comp realStates_primrec

theorem step_primrec : Primrec (fun p : Code × (Nat × Nat) => step p.1 p.2.1 p.2.2) := by
  have hq : Primrec (fun p : Code × (Nat × Nat) => p.2.1 - 1) :=
    Primrec.nat_sub.comp (Primrec.fst.comp Primrec.snd) (Primrec.const 1)
  have hrow : Primrec (fun p : Code × (Nat × Nat) => (transitions p.1).getD (p.2.1 - 1) []) :=
    (Primrec.list_getD []).comp (transitions_primrec.comp Primrec.fst) hq
  have hentry : Primrec (fun p : Code × (Nat × Nat) =>
      ((transitions p.1).getD (p.2.1 - 1) []).getD p.2.2 0) :=
    (Primrec.list_getD 0).comp hrow (Primrec.snd.comp Primrec.snd)
  have hzero : PrimrecPred (fun p : Code × (Nat × Nat) => p.2.1 = 0) :=
    Primrec.eq.comp (Primrec.fst.comp Primrec.snd) (Primrec.const 0)
  have hletter : PrimrecPred (fun p : Code × (Nat × Nat) => p.2.2 < alphabetSize p.1) :=
    Primrec.nat_lt.comp (Primrec.snd.comp Primrec.snd) (alphabetSize_primrec.comp Primrec.fst)
  exact (Primrec.cond hzero.decide (Primrec.const 0)
    (Primrec.cond hletter.decide
      (Primrec.succ.comp (Primrec.nat_mod.comp hentry (realStates_primrec.comp Primrec.fst)))
      (Primrec.const 0))).of_eq (fun p => by simp only [Bool.cond_decide]; rfl)

theorem acceptState_primrec : Primrec₂ acceptState := by
  have hzero : PrimrecPred (fun p : Code × Nat => p.2 = 0) :=
    Primrec.eq.comp Primrec.snd (Primrec.const 0)
  have hget : Primrec (fun p : Code × Nat => (accepting p.1).getD (p.2 - 1) false) :=
    (Primrec.list_getD false).comp (accepting_primrec.comp Primrec.fst)
      (Primrec.nat_sub.comp Primrec.snd (Primrec.const 1))
  exact (Primrec.cond hzero.decide (Primrec.const false) hget).of_eq
    (fun p => by simp only [Bool.cond_decide]; rfl)

theorem evalFrom_primrec : Primrec (fun p : (Code × Nat) × List Nat => evalFrom p.1.1 p.1.2 p.2) := by
  have hp : Primrec₂ (fun p : (Code × Nat) × List Nat => fun qa : Nat × Nat => (p.1.1, qa)) :=
    context_pair_primrec
  have hs' := Primrec.comp step_primrec hp
  have hs : Primrec₂ (fun p : (Code × Nat) × List Nat => fun qa : Nat × Nat =>
      step p.1.1 qa.1 qa.2) :=
    hs'.of_eq (fun p => rfl)
  have hf := Primrec.list_foldl Primrec.snd (Primrec.snd.comp Primrec.fst) hs
  exact hf.of_eq (fun p => rfl)

end DCPv7.EncodedAutomaton
