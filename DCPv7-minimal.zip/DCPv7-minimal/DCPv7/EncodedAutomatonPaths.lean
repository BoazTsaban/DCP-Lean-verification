import DCPv7.EncodedAutomaton
import DCPv7.FiniteScan

/-! Uniform primitive-recursive bounded path searches for the encoded DFA. -/
namespace DCPv7.EncodedAutomaton
set_option backward.isDefEq.respectTransparency false

def candidates (D : Code) : List (List Nat) :=
  WordAutomaton.boundedWords (List.range (alphabetSize D)) (totalStates D)

theorem candidates_primrec : Primrec candidates :=
  WordAutomaton.boundedWords_primrec.comp
    (Primrec.list_range.comp alphabetSize_primrec) totalStates_primrec

def prefixTest (p : Code × Nat) (w : List Nat) : Bool :=
  decide (evalFrom p.1 (startState p.1) w = p.2)

def suffixTest (p : Code × Nat) (w : List Nat) : Bool :=
  acceptState p.1 (evalFrom p.1 p.2 w)

theorem prefixTest_primrec : Primrec₂ prefixTest := by
  have hs : Primrec (fun p : Code × Nat => (p.1, startState p.1)) :=
    Primrec.fst.pair (startState_primrec.comp Primrec.fst)
  have hp : Primrec₂ (fun p : Code × Nat => fun w : List Nat => ((p.1, startState p.1), w)) :=
    Primrec₂.pair.comp₂ (hs.comp₂ Primrec₂.left) Primrec₂.right
  have he' := Primrec.comp evalFrom_primrec hp
  have he : Primrec (fun p : (Code × Nat) × List Nat => evalFrom p.1.1 (startState p.1.1) p.2) :=
    he'.of_eq (fun p => rfl)
  exact (Primrec.eq.comp he (Primrec.snd.comp Primrec.fst)).decide

theorem suffixTest_primrec : Primrec₂ suffixTest :=
  acceptState_primrec.comp (Primrec.fst.comp Primrec.fst) evalFrom_primrec

def prefixPath (D : Code) (q : Nat) : Option (List Nat) :=
  LengthEnumeration.first (prefixTest (D, q)) (candidates D)

def suffixPath (D : Code) (q : Nat) : Option (List Nat) :=
  LengthEnumeration.first (suffixTest (D, q)) (candidates D)

theorem prefixPath_primrec : Primrec₂ prefixPath :=
  (LengthEnumeration.first_primrec prefixTest prefixTest_primrec).comp
    Primrec.id (candidates_primrec.comp Primrec.fst)

theorem suffixPath_primrec : Primrec₂ suffixPath :=
  (LengthEnumeration.first_primrec suffixTest suffixTest_primrec).comp
    Primrec.id (candidates_primrec.comp Primrec.fst)

theorem prefixPath_spec (D : Code) (q : Fin (totalStates D)) :
    prefixPath D q.val =
      (machine D).prefixPath (List.range (alphabetSize D)) q := by
  unfold prefixPath WordAutomaton.prefixPath candidates
  simp only [Fintype.card_fin]
  congr 1
  funext w
  unfold prefixTest
  simp only [Fin.ext_iff, machine_evalFrom]
  rfl

theorem suffixPath_spec (D : Code) (q : Fin (totalStates D)) :
    suffixPath D q.val =
      (machine D).suffixPath (List.range (alphabetSize D)) q := by
  unfold suffixPath WordAutomaton.suffixPath candidates
  simp only [Fintype.card_fin]
  congr 1
  funext w
  change acceptState D (evalFrom D q.val w) =
    decide (acceptState D ((machine D).evalFrom q w).val = true)
  rw [machine_evalFrom]
  simp

def nonemptyDecision (D : Code) : Bool := (suffixPath D (startState D)).isSome

theorem nonemptyDecision_primrec : Primrec nonemptyDecision :=
  Primrec.option_isSome.comp (suffixPath_primrec.comp Primrec.id startState_primrec)

theorem nonemptyDecision_correct (D : Code) :
    nonemptyDecision D = true ↔ ∃ w, (machine D).Accepts w := by
  unfold nonemptyDecision
  rw [show startState D = (machine D).start.val from rfl, suffixPath_spec]
  simp only [Option.isSome_iff_exists]
  constructor
  · rintro ⟨w, hw⟩
    exact ⟨w, (machine D).suffixPath_sound _ _ w hw⟩
  · rintro ⟨w, hw⟩
    exact (machine D).suffixPath_exists_restricted _ _
      (useful_alphabet D _ ((machine D).useful_start hw))

def trimmed (D : Code) (q : Nat) : Bool :=
  (prefixPath D q).isSome && (suffixPath D q).isSome

theorem trimmed_primrec : Primrec₂ trimmed :=
  Primrec.and.comp (Primrec.option_isSome.comp prefixPath_primrec)
    (Primrec.option_isSome.comp suffixPath_primrec)

theorem trimmed_correct (D : Code) (q : Fin (totalStates D)) :
    trimmed D q.val = true ↔ (machine D).Useful q := by
  rw [trimmed, prefixPath_spec, suffixPath_spec]
  exact (machine D).trimmed_iff_restricted _ (useful_alphabet D) q

end DCPv7.EncodedAutomaton
