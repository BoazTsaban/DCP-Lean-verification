import DCPv7.ProductEncoding
import DCPVerification.FiniteChecks

/-! Computability of the concrete coordinate encoder, with the list of factor
types and ranks and the number of factors included in the input.
-/
namespace DCPv7.ProductEncoding

theorem project_filterMap (i : Nat) (w : ProductWord) :
    project i w = w.filterMap (fun a => if a.1 = i then some a.2 else none) := by
  induction w with
  | nil => rfl
  | cons a w ih =>
    rcases a with ⟨j, a⟩
    by_cases h : j = i <;> simp [project, h, ih]

theorem project_primrec : Primrec₂ project := by
  have hc : PrimrecPred (fun q : (Nat × ProductWord) × ProductLetter => q.2.1 = q.1.1) :=
    Primrec.eq.comp (Primrec.fst.comp Primrec.snd) (Primrec.fst.comp Primrec.fst)
  have hf : Primrec₂ (fun q : Nat × ProductWord => fun a : ProductLetter =>
      if a.1 = q.1 then some a.2 else none) :=
    (Primrec.cond hc.decide (Primrec.option_some.comp (Primrec.snd.comp Primrec.snd))
      (Primrec.const none)).of_eq (fun q => by simp only [Bool.cond_decide])
  exact (Primrec.listFilterMap Primrec.snd hf).of_eq
    (fun q => (project_filterMap q.1 q.2).symm)

theorem projectList_primrec : Primrec₂ (fun (i : Nat) (s : List ProductWord) => s.map (project i)) :=
  Primrec.list_map Primrec.snd
    (Primrec.to₂ (project_primrec.comp (Primrec.fst.comp Primrec.fst) Primrec.snd))

theorem coordinateInput_primrec : Primrec₂ coordinateInput := by
  have ht : Primrec (fun q : Input × Nat => q.1.1.getD q.2 (0, 1)) :=
    (Primrec.list_getD (0, 1)).comp (Primrec.fst.comp Primrec.fst) Primrec.snd
  have hL : Primrec (fun q : Input × Nat => q.1.2.1.map (project q.2)) :=
    projectList_primrec.comp Primrec.snd (Primrec.fst.comp (Primrec.snd.comp Primrec.fst))
  have hR : Primrec (fun q : Input × Nat => q.1.2.2.1.map (project q.2)) :=
    projectList_primrec.comp Primrec.snd
      (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)))
  have hg : Primrec (fun q : Input × Nat => project q.2 q.1.2.2.2.1) :=
    project_primrec.comp Primrec.snd
      (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst))))
  have hh : Primrec (fun q : Input × Nat => project q.2 q.1.2.2.2.2) :=
    project_primrec.comp Primrec.snd
      (Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst))))
  exact ht.pair (hL.pair (hR.pair (hg.pair hh)))

def productDecision (factorDecision : CoordinateInput → Bool) (p : Input) : Bool :=
  DCPVerification.allChecks (fun p i => factorDecision (coordinateInput p i)) p
    (List.range p.1.length)

theorem productDecision_computable (factorDecision : CoordinateInput → Bool)
    (hd : Computable factorDecision) : Computable (productDecision factorDecision) :=
  (DCPVerification.allChecks_computable _ (hd.comp coordinateInput_primrec.to_comp).to₂).comp
    Computable.id (Primrec.list_range.comp (Primrec.list_length.comp Primrec.fst)).to_comp

theorem productDecision_correct (factorDecision : CoordinateInput → Bool) (p : Input) :
    productDecision factorDecision p = true ↔
      ∀ i < p.1.length, factorDecision (coordinateInput p i) = true := by
  rw [productDecision, DCPVerification.allChecks_spec]
  simp only [List.mem_range]

end DCPv7.ProductEncoding
