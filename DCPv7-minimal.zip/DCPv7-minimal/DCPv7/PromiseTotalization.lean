import Mathlib.Computability.Partrec

/-! Totalization on a decidable promise, with an explicit default outside it.
The partial algorithm is only evaluated on inputs for which termination has
been proved. This does not assume termination beyond the promise.
-/
namespace DCPv7.PromiseTotalization
set_option backward.isDefEq.respectTransparency false

variable {α β : Type} [Primcodable α] [Primcodable β]
variable (promise : α → Prop) [DecidablePred promise] (f : α → Part β) (defaultValue : β)

def guarded (a : α) : Part β := if promise a then f a else Part.some defaultValue

theorem guarded_partrec (hp : PrimrecPred promise) (hf : Partrec f) :
    Partrec (guarded promise f defaultValue) := by
  have ho : Computable (fun a : α => if promise a then some () else none) :=
    (Primrec.ite hp (Primrec.const (some ())) (Primrec.const none)).to_comp
  have hg : Partrec₂ (fun a : α => fun _ : Unit => f a) := hf.comp Computable.fst
  exact (Partrec.optionCasesOn_right ho (Computable.const defaultValue) hg).of_eq
    (fun a => by by_cases ha : promise a <;> simp [guarded, ha])

variable (terminates : ∀ a, promise a → (f a).Dom)
include terminates

omit [Primcodable α] [Primcodable β] in
theorem guarded_dom (a : α) : (guarded promise f defaultValue a).Dom := by
  by_cases ha : promise a
  · simpa only [guarded, if_pos ha] using terminates a ha
  · simp only [guarded, if_neg ha, Part.some_dom]

noncomputable def totalize (a : α) : β :=
  (guarded promise f defaultValue a).get (guarded_dom promise f defaultValue terminates a)

omit [Primcodable α] [Primcodable β] in
theorem totalize_mem_guarded (a : α) :
    totalize promise f defaultValue terminates a ∈ guarded promise f defaultValue a :=
  Part.get_mem _

omit [Primcodable α] [Primcodable β] in
theorem totalize_mem (a : α) (ha : promise a) :
    totalize promise f defaultValue terminates a ∈ f a := by
  simpa only [guarded, if_pos ha] using totalize_mem_guarded promise f defaultValue terminates a

theorem totalize_computable (hp : PrimrecPred promise) (hf : Partrec f) :
    Computable (totalize promise f defaultValue terminates) :=
  (guarded_partrec promise f defaultValue hp hf).of_eq_tot
    (totalize_mem_guarded promise f defaultValue terminates)

end DCPv7.PromiseTotalization
