import DCPv7.AutomatonGenerators
import DCPv7.AutomatonFinitePaths

/-! The actual finite list of words p_q a p_r⁻¹ and p_f. The accepted-path
argument proves that this list generates the represented subgroup.
-/
namespace DCPv7

variable {α Q G : Type} [Group G]

theorem wordValue_reverse_map (letter : α → G) (flip : α → α)
    (hflip : ∀ a, letter (flip a) = (letter a)⁻¹) (w : List α) :
    wordValue letter (w.reverse.map flip) = (wordValue letter w)⁻¹ := by
  induction w with
  | nil => simp
  | cons a w ih =>
    have he : (a :: w).reverse.map flip = w.reverse.map flip ++ [flip a] := by simp
    rw [he, wordValue_append, ih]
    simp only [wordValue_cons, wordValue_nil, mul_one, hflip, mul_inv_rev]

namespace WordAutomaton

variable (M : WordAutomaton α Q) (paths : M.TrimPaths) (flip : α → α)

def edgeWord (q : Q) (a : α) : List α :=
  paths.prefixWord q ++ [a] ++ (paths.prefixWord (M.step q a)).reverse.map flip

theorem edgeWord_value (letter : α → G)
    (hflip : ∀ a, letter (flip a) = (letter a)⁻¹) (q : Q) (a : α) :
    wordValue letter (M.edgeWord paths flip q a) = M.edgeValue paths letter q a := by
  simp only [edgeWord, wordValue_append, wordValue_cons, wordValue_nil, mul_one,
    wordValue_reverse_map letter flip hflip, edgeValue]

variable [DecidablePred M.Useful] [DecidablePred M.accept]

def generatorWords (states : List Q) (alphabet : List α) : List (List α) :=
  ((states.product alphabet).filter fun qa =>
    decide (M.Useful qa.1 ∧ M.Useful (M.step qa.1 qa.2))).map
      (fun qa => M.edgeWord paths flip qa.1 qa.2) ++
  (states.filter fun q => decide (M.Useful q ∧ M.accept q)).map paths.prefixWord

theorem generatorWords_values (states : List Q) (alphabet : List α)
    (hstates : ∀ q, M.Useful q → q ∈ states) (halphabet : ∀ a : α, a ∈ alphabet)
    (letter : α → G) (hflip : ∀ a, letter (flip a) = (letter a)⁻¹) :
    {g | g ∈ (M.generatorWords paths flip states alphabet).map (wordValue letter)} =
      M.generatorSet paths letter := by
  ext g
  constructor
  · intro hg
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hg
    rcases List.mem_append.mp hw with hw | hw
    · obtain ⟨⟨q, a⟩, hqa, rfl⟩ := List.mem_map.mp hw
      have hkeep := (List.mem_filter.mp hqa).2
      have hu : M.Useful q ∧ M.Useful (M.step q a) := of_decide_eq_true hkeep
      exact Or.inl ⟨q, a, hu.1, hu.2, M.edgeWord_value paths flip letter hflip q a⟩
    · obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hw
      have hu : M.Useful q ∧ M.accept q := of_decide_eq_true (List.mem_filter.mp hq).2
      exact Or.inr ⟨q, hu.1, hu.2, rfl⟩
  · intro hg
    rcases hg with ⟨q, a, hq, hr, rfl⟩ | ⟨q, hq, hf, rfl⟩
    · apply List.mem_map.mpr
      refine ⟨M.edgeWord paths flip q a, List.mem_append.mpr (Or.inl ?_),
        M.edgeWord_value paths flip letter hflip q a⟩
      apply List.mem_map.mpr
      exact ⟨(q, a), List.mem_filter.mpr
        ⟨List.mem_product.mpr ⟨hstates q hq, halphabet a⟩, by simp [hq, hr]⟩, rfl⟩
    · apply List.mem_map.mpr
      refine ⟨paths.prefixWord q, List.mem_append.mpr (Or.inr ?_), rfl⟩
      exact List.mem_map.mpr ⟨q,
        List.mem_filter.mpr ⟨hstates q hq, by simp [hq, hf]⟩, rfl⟩

theorem finite_words_generate (states : List Q) (alphabet : List α)
    (hstates : ∀ q, M.Useful q → q ∈ states) (halphabet : ∀ a : α, a ∈ alphabet)
    (letter : α → G) (hflip : ∀ a, letter (flip a) = (letter a)⁻¹)
    (H : Subgroup G)
    (accepted_mem : ∀ w, M.Accepts w → wordValue letter w ∈ H)
    (represented : ∀ h ∈ H, ∃ w, M.Accepts w ∧ wordValue letter w = h) :
    Subgroup.closure
      {g | g ∈ (M.generatorWords paths flip states alphabet).map (wordValue letter)} = H := by
  rw [M.generatorWords_values paths flip states alphabet hstates halphabet letter hflip]
  exact M.generates_subgroup paths letter H accepted_mem represented

end WordAutomaton
end DCPv7
