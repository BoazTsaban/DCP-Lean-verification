import DCPv7.BiautomaticInterfaces
import DCPv7.EncodedGeneratorComputability

/-! The finite-intersection, emptiness and explicit generator arguments in the
biautomatic lemma. All constructions are deduced from a conjugator compiler;
no centralizer or simultaneous-conjugacy algorithm is assumed.
-/
namespace DCPv7.Biautomatic
open FinitePresentation
set_option backward.isDefEq.respectTransparency false

theorem list_map_computable {P A B : Type} [Primcodable P] [Primcodable A] [Primcodable B]
    [Inhabited A] (f : P → A → B) (hf : Computable₂ f) :
    Computable₂ (fun (p : P) (l : List A) => l.map (f p)) := by
  have hget : Computable (fun q : (P × List A) × (Nat × List B) => q.1.2.getD q.2.1 default) :=
    (Primrec.list_getD default).to_comp.comp (Computable.snd.comp Computable.fst)
      (Computable.fst.comp Computable.snd)
  have hval := hf.comp (Computable.fst.comp Computable.fst) hget
  have hs : Computable₂ (fun q : P × List A => fun r : Nat × List B =>
      r.2 ++ [f q.1 (q.2.getD r.1 default)]) :=
    Computable.list_append.comp (Computable.snd.comp Computable.snd)
      (Computable.list_cons.comp hval (Computable.const []))
  have hn := Computable.nat_rec (Computable.list_length.comp Computable.snd)
    (Computable.const []) hs
  exact hn.of_eq fun q => by
    have hr : ∀ n, Nat.rec []
        (fun i acc => acc ++ [f q.1 (q.2.getD i default)]) n =
          (List.range n).map (fun i => f q.1 (q.2.getD i default)) := by
      intro n
      induction n with
      | zero => rfl
      | succ n ih => simp only [List.range_succ, List.map_append, List.map_cons, List.map_nil, ih]
    rw [hr]
    apply List.ext_getElem
    · simp
    · intro i hi _
      simp only [List.length_map, List.length_range] at hi
      simp only [List.getElem_map, List.getElem_range, List.getD_eq_getElem q.2 default hi]

def systemCode (C : ConjugatorCompiler)
    (p : (Presentation × StructureCode) × List (Word × Word)) : Code :=
  EncodedAutomaton.intersectAll (language p.1.2) (p.2.map fun uv => C.code (p.1, uv))

theorem systemCode_computable (C : ConjugatorCompiler) : Computable (systemCode C) := by
  have hm : Computable₂ (fun p : Presentation × StructureCode => fun uv : Word × Word => C.code (p, uv)) :=
    C.computable
  have hmap := list_map_computable _ hm
  exact EncodedAutomaton.intersectAll_primrec.to_comp.comp
    (Primrec.fst.comp (Primrec.snd.comp Primrec.fst)).to_comp hmap

theorem systemCode_spec (C : ConjugatorCompiler) (P : Presentation) (s : StructureCode)
    (hs : StructureSpec P s) (e : List (Word × Word)) (he : InstanceValid P e) (w : Word) :
    (EncodedAutomaton.machine (systemCode C ((P, s), e))).Accepts w ↔
      Accepts s w ∧ ∀ uv ∈ e, (value P w)⁻¹ * value P uv.1 * value P w = value P uv.2 := by
  rw [systemCode, EncodedAutomaton.intersectAll_correct]
  constructor
  · rintro ⟨hw, hall⟩
    refine ⟨hw, ?_⟩
    intro uv huv
    exact ((C.correct P s hs uv.1 uv.2 (he uv huv).1 (he uv huv).2 w).mp
      (hall _ (List.mem_map.mpr ⟨uv, huv, rfl⟩))).2
  · rintro ⟨hw, hall⟩
    refine ⟨hw, ?_⟩
    intro D hD
    obtain ⟨uv, huv, rfl⟩ := List.mem_map.mp hD
    exact (C.correct P s hs uv.1 uv.2 (he uv huv).1 (he uv huv).2 w).mpr ⟨hw, hall uv huv⟩

theorem intersectAll_alphabet (base : Code) (others : List Code) (k : Nat)
    (hbase : EncodedAutomaton.alphabetSize base = k)
    (hothers : ∀ D ∈ others, EncodedAutomaton.alphabetSize D = k) :
    EncodedAutomaton.alphabetSize (EncodedAutomaton.intersectAll base others) = k := by
  induction others generalizing base with
  | nil => exact hbase
  | cons D ds ih =>
    change EncodedAutomaton.alphabetSize
      (EncodedAutomaton.intersectAll (EncodedAutomaton.intersection base D) ds) = k
    apply ih
    · change min (EncodedAutomaton.alphabetSize base) (EncodedAutomaton.alphabetSize D) = k
      rw [hbase, hothers D (by simp), min_self]
    · intro E hE
      exact hothers E (by simp [hE])

theorem systemCode_alphabet (C : ConjugatorCompiler) (P : Presentation) (s : StructureCode)
    (hs : StructureSpec P s) (e : List (Word × Word)) :
    EncodedAutomaton.alphabetSize (systemCode C ((P, s), e)) = 2 * genCount P := by
  apply intersectAll_alphabet _ _ _ hs.alphabet
  intro D hD
  obtain ⟨uv, _, rfl⟩ := List.mem_map.mp hD
  exact C.alphabet P s uv.1 uv.2

def centralizerCode (C : ConjugatorCompiler) (p : (Presentation × StructureCode) × List Word) : Code :=
  systemCode C (p.1, p.2.map fun u => (u, u))

theorem centralizerCode_computable (C : ConjugatorCompiler) : Computable (centralizerCode C) := by
  have hd : Primrec (fun p : (Presentation × StructureCode) × List Word =>
      p.2.map (fun u => (u, u))) :=
    Primrec.list_map Primrec.snd (Primrec.to₂ (Primrec.snd.pair Primrec.snd))
  exact (systemCode_computable C).comp (Computable.fst.pair hd.to_comp)

theorem centralizer_fixed_iff (P : Presentation) (u : List Word) (x : GroupOf P) :
    x ∈ Subgroup.centralizer (subgroup P u : Set (GroupOf P)) ↔
      ∀ w ∈ u, x⁻¹ * value P w * x = value P w := by
  rw [subgroup, Subgroup.centralizer_closure]
  constructor
  · intro hx w hw
    have he := hx _ (List.mem_map.mpr ⟨w, hw, rfl⟩)
    calc
      x⁻¹ * value P w * x = x⁻¹ * (value P w * x) := mul_assoc _ _ _
      _ = x⁻¹ * (x * value P w) := by rw [he]
      _ = value P w := inv_mul_cancel_left _ _
  · intro hx g hg
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hg
    calc
      value P w * x = x * (x⁻¹ * value P w * x) := by simp [mul_assoc]
      _ = x * value P w := by rw [hx w hw]

theorem centralizerCode_spec (C : ConjugatorCompiler) (P : Presentation) (s : StructureCode)
    (hs : StructureSpec P s) (u : List Word) (hu : ∀ w ∈ u, ValidWord P w) (w : Word) :
    (EncodedAutomaton.machine (centralizerCode C ((P, s), u))).Accepts w ↔
      Accepts s w ∧ value P w ∈ Subgroup.centralizer (subgroup P u : Set (GroupOf P)) := by
  have he : InstanceValid P (u.map fun v => (v, v)) := by
    intro uv huv
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp huv
    exact ⟨hu v hv, hu v hv⟩
  rw [centralizerCode, systemCode_spec C P s hs _ he w, centralizer_fixed_iff]
  constructor
  · rintro ⟨hw, hall⟩
    exact ⟨hw, fun v hv => hall (v, v) (List.mem_map.mpr ⟨v, hv, rfl⟩)⟩
  · rintro ⟨hw, hall⟩
    refine ⟨hw, ?_⟩
    intro uv huv
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp huv
    exact hall v hv

def centralizerWords (C : ConjugatorCompiler) (p : (Presentation × StructureCode) × List Word) : List Word :=
  EncodedAutomaton.generatorWords (centralizerCode C p) flip

theorem centralizerWords_computable (C : ConjugatorCompiler) : Computable (centralizerWords C) :=
  (EncodedAutomaton.generatorWords_primrec flip flip_primrec).to_comp.comp (centralizerCode_computable C)

theorem centralizerWords_spec (C : ConjugatorCompiler) (P : Presentation) (s : StructureCode)
    (hs : StructureSpec P s) (u : List Word) (hu : ∀ w ∈ u, ValidWord P w) :
    (∀ w ∈ centralizerWords C ((P, s), u), ValidWord P w) ∧
      Subgroup.closure {g | g ∈ (centralizerWords C ((P, s), u)).map (value P)} =
        Subgroup.centralizer (subgroup P u : Set (GroupOf P)) := by
  have halpha : EncodedAutomaton.alphabetSize (centralizerCode C ((P, s), u)) = 2 * genCount P :=
    systemCode_alphabet C P s hs _
  constructor
  · intro w hw
    have hflip : ∀ a < EncodedAutomaton.alphabetSize (centralizerCode C ((P, s), u)),
        flip a < EncodedAutomaton.alphabetSize (centralizerCode C ((P, s), u)) := by
      rw [halpha]
      exact fun a ha => flip_lt a (genCount P) ha
    have hvalid := EncodedAutomaton.generatorWords_alphabet _ flip hflip w hw
    simpa only [ValidWord, halpha] using hvalid
  · apply EncodedAutomaton.generatorWords_generate _ flip (letter P) (letter_flip P)
    · intro w hw
      exact ((centralizerCode_spec C P s hs u hu w).mp hw).2
    · intro g hg
      obtain ⟨w, hw, he⟩ := hs.representatives g
      refine ⟨w, (centralizerCode_spec C P s hs u hu w).mpr ⟨hw, ?_⟩, he⟩
      simpa only [he] using hg

def simultaneousDecision (C : ConjugatorCompiler)
    (p : (Presentation × StructureCode) × List (Word × Word)) : Bool :=
  EncodedAutomaton.nonemptyDecision (systemCode C p)

theorem simultaneousDecision_computable (C : ConjugatorCompiler) : Computable (simultaneousDecision C) :=
  EncodedAutomaton.nonemptyDecision_primrec.to_comp.comp (systemCode_computable C)

theorem simultaneousDecision_spec (C : ConjugatorCompiler) (P : Presentation) (s : StructureCode)
    (hs : StructureSpec P s) (e : List (Word × Word)) (he : InstanceValid P e) :
    simultaneousDecision C ((P, s), e) = true ↔ InstanceSolvable P e := by
  rw [simultaneousDecision, EncodedAutomaton.nonemptyDecision_correct]
  constructor
  · rintro ⟨w, hw⟩
    exact ⟨value P w, ((systemCode_spec C P s hs e he w).mp hw).2⟩
  · rintro ⟨x, hx⟩
    obtain ⟨w, hw, hvalue⟩ := hs.representatives x
    refine ⟨w, (systemCode_spec C P s hs e he w).mpr ⟨hw, ?_⟩⟩
    simpa only [hvalue] using hx

def ofConjugatorCompiler (C : ConjugatorCompiler) : StructuredAlgorithms where
  centralizer := centralizerWords C
  centralizer_computable := centralizerWords_computable C
  centralizer_spec := centralizerWords_spec C
  simultaneous := simultaneousDecision C
  simultaneous_computable := simultaneousDecision_computable C
  simultaneous_spec := simultaneousDecision_spec C

end DCPv7.Biautomatic
