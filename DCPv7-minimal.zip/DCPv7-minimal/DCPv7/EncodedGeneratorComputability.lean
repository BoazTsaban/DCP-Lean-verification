import DCPv7.EncodedAutomatonGenerators

/-! Uniform primitive-recursive extraction of the finite generator-word list. -/
namespace DCPv7.EncodedAutomaton
set_option backward.isDefEq.respectTransparency false

theorem prefixWord_primrec : Primrec₂ prefixWord := by
  have he : PrimrecPred (fun p : Code × Nat => p.2 = startState p.1) :=
    Primrec.eq.comp Primrec.snd (startState_primrec.comp Primrec.fst)
  have hg : Primrec (fun p : Code × Nat => (prefixPath p.1 p.2).getD []) :=
    Primrec.option_getD.comp prefixPath_primrec (Primrec.const [])
  exact (Primrec.cond he.decide (Primrec.const []) hg).of_eq
    (fun p => by simp only [Bool.cond_decide]; rfl)

theorem edgeWord_primrec (flip : Nat → Nat) (hflip : Primrec flip) :
    Primrec (fun p : Code × (Nat × Nat) => edgeWord p.1 flip p.2.1 p.2.2) := by
  have hp : Primrec (fun p : Code × (Nat × Nat) => prefixWord p.1 p.2.1) :=
    prefixWord_primrec.comp Primrec.fst (Primrec.fst.comp Primrec.snd)
  have hr : Primrec (fun p : Code × (Nat × Nat) => prefixWord p.1 (step p.1 p.2.1 p.2.2)) :=
    prefixWord_primrec.comp Primrec.fst step_primrec
  have hi : Primrec (fun w : List Nat => w.reverse.map flip) :=
    Primrec.list_map Primrec.list_reverse (Primrec.to₂ (hflip.comp Primrec.snd))
  exact Primrec.list_append.comp
    (Primrec.list_append.comp hp
      (Primrec.list_cons.comp (Primrec.snd.comp Primrec.snd) (Primrec.const [])))
    (hi.comp hr)

theorem edgeKeep_primrec : Primrec₂ edgeKeep :=
  Primrec.and.comp (trimmed_primrec.comp Primrec.fst (Primrec.fst.comp Primrec.snd))
    (trimmed_primrec.comp Primrec.fst step_primrec)

theorem finalKeep_primrec : Primrec₂ finalKeep := Primrec.and.comp trimmed_primrec acceptState_primrec

theorem natProduct_primrec : Primrec₂ (@List.product Nat Nat) := by
  have hm : Primrec₂ (fun p : List Nat × List Nat => fun a : Nat => p.2.map (fun b => (a, b))) :=
    Primrec.list_map (Primrec.snd.comp Primrec.fst) LengthEnumeration.pair_snd_primrec
  exact Primrec.list_flatMap Primrec.fst hm

theorem edgeStates_primrec : Primrec edgeStates := by
  have hp : Primrec (fun D : Code => (List.range (totalStates D)).product (List.range (alphabetSize D))) :=
    natProduct_primrec.comp (Primrec.list_range.comp totalStates_primrec)
      (Primrec.list_range.comp alphabetSize_primrec)
  have hr : PrimrecRel (fun qa : Nat × Nat => fun D : Code => edgeKeep D qa = true) :=
    Primrec.eq.comp (edgeKeep_primrec.comp Primrec.snd Primrec.fst) (Primrec.const true)
  exact hr.listFilter.comp hp Primrec.id

theorem finalStates_primrec : Primrec finalStates := by
  have hr : PrimrecRel (fun q : Nat => fun D : Code => finalKeep D q = true) :=
    Primrec.eq.comp (finalKeep_primrec.comp Primrec.snd Primrec.fst) (Primrec.const true)
  exact hr.listFilter.comp (Primrec.list_range.comp totalStates_primrec) Primrec.id

theorem generatorWords_primrec (flip : Nat → Nat) (hflip : Primrec flip) :
    Primrec (fun D : Code => generatorWords D flip) := by
  have he : Primrec₂ (fun D : Code => fun qa : Nat × Nat => edgeWord D flip qa.1 qa.2) :=
    edgeWord_primrec flip hflip
  have hedges := Primrec.list_map edgeStates_primrec he
  have hfinals := Primrec.list_map finalStates_primrec prefixWord_primrec
  exact Primrec.list_append.comp hedges hfinals

end DCPv7.EncodedAutomaton
