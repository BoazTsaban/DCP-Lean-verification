import DCPv7.LengthComputability

/-! Uniform length-ordered search over signed words in two supplied lists. -/
namespace DCPv7.SignedSearch
open LengthEnumeration

abbrev Letter := Nat × Bool
abbrev Word := List Letter
abbrev Candidate := Word × Word

def alphabet (k : Nat) : List Letter :=
  (List.range k).flatMap fun i => [(i, true), (i, false)]

theorem mem_alphabet (k : Nat) (a : Letter) : a ∈ alphabet k ↔ a.1 < k := by
  rcases a with ⟨i, b⟩
  cases b <;> simp [alphabet]

theorem alphabet_primrec : Primrec alphabet := by
  apply Primrec.list_flatMap Primrec.list_range
  exact Primrec.to₂ (Primrec.list_cons.comp
    (Primrec.snd.pair (Primrec.const true))
    (Primrec.list_cons.comp (Primrec.snd.pair (Primrec.const false)) (Primrec.const [])))

variable {P : Type} [Primcodable P]

def run (leftSize rightSize : P → Nat) (test : P → Candidate → Bool) : P → Part Candidate :=
  lengthSearch (alphabet ∘ leftSize) (alphabet ∘ rightSize) test

theorem run_partrec (leftSize rightSize : P → Nat) (test : P → Candidate → Bool)
    (hleft : Computable leftSize) (hright : Computable rightSize)
    (htest : Computable₂ test) : Partrec (run leftSize rightSize test) :=
  lengthSearch_partrec _ _ _ (alphabet_primrec.to_comp.comp hleft)
    (alphabet_primrec.to_comp.comp hright) htest

omit [Primcodable P] in
theorem run_sound (leftSize rightSize : P → Nat) (test : P → Candidate → Bool)
    (p : P) (w : Candidate) (hw : w ∈ run leftSize rightSize test p) :
    (∀ a ∈ w.1, a.1 < leftSize p) ∧
      (∀ b ∈ w.2, b.1 < rightSize p) ∧ test p w = true := by
  simpa only [mem_alphabet, Function.comp_apply] using
    lengthSearch_sound (alphabet ∘ leftSize) (alphabet ∘ rightSize) test p w hw

omit [Primcodable P] in
theorem run_dom (leftSize rightSize : P → Nat) (test : P → Candidate → Bool) (p : P) :
    (run leftSize rightSize test p).Dom ↔ ∃ w : Candidate,
      (∀ a ∈ w.1, a.1 < leftSize p) ∧
        (∀ b ∈ w.2, b.1 < rightSize p) ∧ test p w = true := by
  simpa only [run, mem_alphabet, Function.comp_apply] using
    lengthSearch_dom (alphabet ∘ leftSize) (alphabet ∘ rightSize) test p

end DCPv7.SignedSearch
