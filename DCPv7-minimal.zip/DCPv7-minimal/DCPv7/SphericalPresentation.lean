import DCPv7.FinitePresentation
import BraidGroup.ArtinWords

/-! The explicit standard finite presentation of every diagram in the paper.
No algorithmic or structural group-theoretic conclusion is assumed here.
-/
namespace DCPv7.SphericalPresentation
open FinitePresentation
set_option backward.isDefEq.respectTransparency false

def pairEdge (i j a b : Nat) : Prop := (i = a ∧ j = b) ∨ (i = b ∧ j = a)
instance (i j a b : Nat) : Decidable (pairEdge i j a b) :=
  inferInstanceAs (Decidable ((i = a ∧ j = b) ∨ (i = b ∧ j = a)))

def matrixEntry (X : FiniteArtinGroup.Diagram) (i j : Nat) : Nat :=
  if i = j then 1 else
  if X.1 = 0 then
    if pairEdge i j 0 1 then 4 else if i + 1 = j ∨ j + 1 = i then 3 else 2
  else if X.1 = 1 then
    if pairEdge i j 0 2 ∨ pairEdge i j 1 2 ∨
      (2 ≤ i ∧ 2 ≤ j ∧ (i + 1 = j ∨ j + 1 = i)) then 3 else 2
  else if X.1 = 2 then
    if pairEdge i j 0 2 ∨ pairEdge i j 1 3 ∨
      (2 ≤ i ∧ 2 ≤ j ∧ (i + 1 = j ∨ j + 1 = i)) then 3 else 2
  else
    if pairEdge i j 0 1 then 5 else if i + 1 = j ∨ j + 1 = i then 3 else 2

theorem matrixEntry_eq (X : FiniteArtinGroup.Diagram) (i j : Fin X.2) :
    matrixEntry X i.val j.val = FiniteArtinGroup.matrix X i j := by
  simp only [matrixEntry, FiniteArtinGroup.matrix, pairEdge, FiniteArtinGroup.pairEdge, Fin.ext_iff]

def alternatingPair (i j : Nat) : Nat → Word × Word
  | 0 => ([], [])
  | n + 1 =>
    let p := alternatingPair i j n
    (2 * i :: p.2, 2 * j :: p.1)

def relatorWord (X : FiniteArtinGroup.Diagram) (i j : Nat) : Word :=
  let p := alternatingPair i j (matrixEntry X i j)
  p.1 ++ inverse p.2

def relationList (X : FiniteArtinGroup.Diagram) : List Word :=
  (List.range X.2).flatMap fun i => (List.range X.2).filterMap fun j =>
    if i = j then none else some (relatorWord X i j)

def code (X : FiniteArtinGroup.Diagram) : Presentation := (X.2, relationList X)

@[simp] theorem code_genCount (X : FiniteArtinGroup.Diagram) : genCount (code X) = X.2 := rfl

theorem alternatingPair_eval (r : Nat) (i j : Fin r) (n : Nat) :
    freeEval r (alternatingPair i.val j.val n).1 =
      FiniteArtinGroup.alternating (FreeGroup.of i) (FreeGroup.of j) n ∧
    freeEval r (alternatingPair i.val j.val n).2 =
      FiniteArtinGroup.alternating (FreeGroup.of j) (FreeGroup.of i) n := by
  induction n with
  | zero => exact ⟨rfl, rfl⟩
  | succ n ih =>
    simp only [alternatingPair, freeEval_cons, freeLetter_even, FiniteArtinGroup.alternating,
      ih.1, ih.2, and_self]

theorem relatorWord_eval (X : FiniteArtinGroup.Diagram) (i j : Fin X.2) :
    freeEval X.2 (relatorWord X i.val j.val) =
      FiniteArtinGroup.alternating (FreeGroup.of i) (FreeGroup.of j) (FiniteArtinGroup.matrix X i j) *
        (FiniteArtinGroup.alternating (FreeGroup.of j) (FreeGroup.of i) (FiniteArtinGroup.matrix X i j))⁻¹ := by
  simp only [relatorWord, freeEval_append, freeEval_inverse, matrixEntry_eq]
  rw [(alternatingPair_eval X.2 i j _).1, (alternatingPair_eval X.2 i j _).2]

theorem mem_relationList (X : FiniteArtinGroup.Diagram) (w : Word) :
    w ∈ relationList X ↔ ∃ i < X.2, ∃ j < X.2, i ≠ j ∧ w = relatorWord X i j := by
  simp only [relationList, List.mem_flatMap, List.mem_range, List.mem_filterMap]
  constructor
  · rintro ⟨i, hi, j, hj, hw⟩
    by_cases he : i = j
    · simp [he] at hw
    · have hw' : relatorWord X i j = w := by simpa [he] using hw
      exact ⟨i, hi, j, hj, he, hw'.symm⟩
  · rintro ⟨i, hi, j, hj, he, rfl⟩
    exact ⟨i, hi, j, hj, by simp [he]⟩

theorem alternatingPair_valid (r i j n : Nat) (hi : i < r) (hj : j < r) :
    (∀ a ∈ (alternatingPair i j n).1, a < 2 * r) ∧
      (∀ a ∈ (alternatingPair i j n).2, a < 2 * r) := by
  induction n with
  | zero => simp [alternatingPair]
  | succ n ih =>
    simp only [alternatingPair, List.mem_cons, forall_eq_or_imp]
    exact ⟨⟨by omega, ih.2⟩, ⟨by omega, ih.1⟩⟩

theorem relatorWord_valid (X : FiniteArtinGroup.Diagram) (i j : Nat)
    (hi : i < X.2) (hj : j < X.2) : ValidWord (code X) (relatorWord X i j) := by
  have h := alternatingPair_valid X.2 i j (matrixEntry X i j) hi hj
  unfold relatorWord
  rw [validWord_append]
  exact ⟨h.1, validWord_inverse (code X) _ h.2⟩

theorem code_relators_valid (X : FiniteArtinGroup.Diagram) :
    ∀ w ∈ (code X).2, ValidWord (code X) w := by
  intro w hw
  obtain ⟨i, hi, j, hj, _, rfl⟩ := (mem_relationList X w).mp hw
  exact relatorWord_valid X i j hi hj

theorem relators_eq (X : FiniteArtinGroup.Diagram) :
    relators (code X) = FiniteArtinGroup.relators (FiniteArtinGroup.matrix X) := by
  ext r
  constructor
  · intro hr
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hr
    obtain ⟨i, hi, j, hj, hij, rfl⟩ := (mem_relationList X w).mp hw
    refine ⟨⟨i, hi⟩, ⟨j, hj⟩, ?_, ?_⟩
    · intro he
      exact hij (congrArg Fin.val he)
    · exact relatorWord_eval X ⟨i, hi⟩ ⟨j, hj⟩
  · rintro ⟨i, j, hij, rfl⟩
    apply List.mem_map.mpr
    refine ⟨relatorWord X i.val j.val, ?_, relatorWord_eval X i j⟩
    apply (mem_relationList X _).mpr
    exact ⟨i.val, i.isLt, j.val, j.isLt, fun he => hij (Fin.ext he), rfl⟩

def presentedEquivOfEq {α : Type} {R S : Set (FreeGroup α)} (h : R = S) :
    PresentedGroup R ≃* PresentedGroup S := by
  cases h
  exact MulEquiv.refl _

theorem presentedEquivOfEq_mk {α : Type} {R S : Set (FreeGroup α)} (h : R = S)
    (x : FreeGroup α) :
    presentedEquivOfEq h (PresentedGroup.mk R x) = PresentedGroup.mk S x := by
  cases h
  rfl

def equiv (X : FiniteArtinGroup.Diagram) : GroupOf (code X) ≃* FiniteArtinGroup.OfDiagram X :=
  presentedEquivOfEq (relators_eq X)

theorem equiv_mk (X : FiniteArtinGroup.Diagram) (x : FreeGroup (Fin X.2)) :
    equiv X (PresentedGroup.mk (relators (code X)) x) =
      PresentedGroup.mk (FiniteArtinGroup.relators (FiniteArtinGroup.matrix X)) x :=
  presentedEquivOfEq_mk (relators_eq X) x

theorem equiv_letter_encode (X : FiniteArtinGroup.Diagram) (l : Nat × Bool) (hl : l.1 < X.2) :
    equiv X (letter (code X) (encodeLetter l)) = FiniteArtinGroup.rawLetter X l := by
  calc
    _ = PresentedGroup.mk (FiniteArtinGroup.relators (FiniteArtinGroup.matrix X))
        (freeLetter X.2 (encodeLetter l)) := equiv_mk X _
    _ = FiniteArtinGroup.rawLetter X l := by
      rcases l with ⟨i, b⟩
      cases b with
      | false =>
        change PresentedGroup.mk _ (freeLetter X.2 (2 * i + 1)) = _
        rw [freeLetter_odd X.2 ⟨i, hl⟩]
        simp [FiniteArtinGroup.rawLetter, hl, map_inv, FiniteArtinGroup.generator, PresentedGroup.of]
      | true =>
        change PresentedGroup.mk _ (freeLetter X.2 (2 * i)) = _
        rw [freeLetter_even X.2 ⟨i, hl⟩]
        simp [FiniteArtinGroup.rawLetter, hl, FiniteArtinGroup.generator, PresentedGroup.of]

theorem equiv_value_encodeRaw (X : FiniteArtinGroup.Diagram) (w : BraidGroup.RawWord)
    (hw : BraidGroup.RawValid (X.2 + 1) w) :
    equiv X (value (code X) (encodeRaw w)) = FiniteArtinGroup.rawEval X w := by
  induction w with
  | nil => simp [encodeRaw]
  | cons l w ih =>
    have hl : l.1 < X.2 := by have h := hw l (by simp); simpa using h
    have ht : BraidGroup.RawValid (X.2 + 1) w := fun a ha => hw a (by simp [ha])
    simp only [encodeRaw, List.map_cons, value_cons, map_mul, FiniteArtinGroup.rawEval_cons]
    rw [equiv_letter_encode X l hl]
    exact congrArg (FiniteArtinGroup.rawLetter X l * ·) (ih ht)

theorem valid_encodeRaw (X : FiniteArtinGroup.Diagram) (w : BraidGroup.RawWord)
    (hw : BraidGroup.RawValid (X.2 + 1) w) : ValidWord (code X) (encodeRaw w) := by
  apply encodeRaw_valid X.2 w
  intro l hl
  have h := hw l hl
  simpa using h

theorem valid_decodeRaw (X : FiniteArtinGroup.Diagram) (w : Word) (hw : ValidWord (code X) w) :
    BraidGroup.RawValid (X.2 + 1) (decodeRaw w) := by
  intro l hl
  have h := decodeRaw_valid X.2 w hw l hl
  simpa using h

theorem equiv_value_decodeRaw (X : FiniteArtinGroup.Diagram) (w : Word) (hw : ValidWord (code X) w) :
    equiv X (value (code X) w) = FiniteArtinGroup.rawEval X (decodeRaw w) := by
  have he := equiv_value_encodeRaw X (decodeRaw w) (valid_decodeRaw X w hw)
  simpa only [encode_decode_raw] using he

theorem pairEdge_primrec (a b : Nat) : PrimrecRel (fun i j : Nat => pairEdge i j a b) :=
  ((Primrec.eq.comp Primrec.fst (Primrec.const a)).and
    (Primrec.eq.comp Primrec.snd (Primrec.const b))).or
  ((Primrec.eq.comp Primrec.fst (Primrec.const b)).and
    (Primrec.eq.comp Primrec.snd (Primrec.const a)))

theorem matrixEntry_primrec :
    Primrec (fun p : FiniteArtinGroup.Diagram × (Nat × Nat) => matrixEntry p.1 p.2.1 p.2.2) := by
  let A := FiniteArtinGroup.Diagram × (Nat × Nat)
  have hi : Primrec (fun p : A => p.2.1) := Primrec.fst.comp Primrec.snd
  have hj : Primrec (fun p : A => p.2.2) := Primrec.snd.comp Primrec.snd
  have htag : Primrec (fun p : A => p.1.1) := Primrec.fst.comp Primrec.fst
  have hdiag : PrimrecPred (fun p : A => p.2.1 = p.2.2) := Primrec.eq.comp hi hj
  have hB : PrimrecPred (fun p : A => p.1.1 = 0) := Primrec.eq.comp htag (Primrec.const 0)
  have hD : PrimrecPred (fun p : A => p.1.1 = 1) := Primrec.eq.comp htag (Primrec.const 1)
  have hE : PrimrecPred (fun p : A => p.1.1 = 2) := Primrec.eq.comp htag (Primrec.const 2)
  have hadj : PrimrecPred (fun p : A => p.2.1 + 1 = p.2.2 ∨ p.2.2 + 1 = p.2.1) :=
    (Primrec.eq.comp (Primrec.succ.comp hi) hj).or (Primrec.eq.comp (Primrec.succ.comp hj) hi)
  have h01 := (pairEdge_primrec 0 1).comp hi hj
  have h02 := (pairEdge_primrec 0 2).comp hi hj
  have h12 := (pairEdge_primrec 1 2).comp hi hj
  have h13 := (pairEdge_primrec 1 3).comp hi hj
  have hlarge : PrimrecPred (fun p : A =>
      2 ≤ p.2.1 ∧ 2 ≤ p.2.2 ∧ (p.2.1 + 1 = p.2.2 ∨ p.2.2 + 1 = p.2.1)) :=
    (Primrec.nat_le.comp (Primrec.const 2) hi).and
      ((Primrec.nat_le.comp (Primrec.const 2) hj).and hadj)
  exact Primrec.ite hdiag (Primrec.const 1)
    (Primrec.ite hB
      (Primrec.ite h01 (Primrec.const 4) (Primrec.ite hadj (Primrec.const 3) (Primrec.const 2)))
      (Primrec.ite hD
        (Primrec.ite (h02.or (h12.or hlarge)) (Primrec.const 3) (Primrec.const 2))
        (Primrec.ite hE
          (Primrec.ite (h02.or (h13.or hlarge)) (Primrec.const 3) (Primrec.const 2))
          (Primrec.ite h01 (Primrec.const 5) (Primrec.ite hadj (Primrec.const 3) (Primrec.const 2))))))

theorem alternatingPair_primrec : Primrec (fun p : (Nat × Nat) × Nat => alternatingPair p.1.1 p.1.2 p.2) := by
  have hi : Primrec (fun p : (Nat × Nat) × (Nat × (Word × Word)) => 2 * p.1.1) :=
    Primrec.nat_mul.comp (Primrec.const 2) (Primrec.fst.comp Primrec.fst)
  have hj : Primrec (fun p : (Nat × Nat) × (Nat × (Word × Word)) => 2 * p.1.2) :=
    Primrec.nat_mul.comp (Primrec.const 2) (Primrec.snd.comp Primrec.fst)
  have hs : Primrec₂ (fun ij : Nat × Nat => fun r : Nat × (Word × Word) =>
      (2 * ij.1 :: r.2.2, 2 * ij.2 :: r.2.1)) :=
    (Primrec.list_cons.comp hi (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))).pair
      (Primrec.list_cons.comp hj (Primrec.fst.comp (Primrec.snd.comp Primrec.snd)))
  have hrec : Primrec₂ (fun ij : Nat × Nat => fun n : Nat => alternatingPair ij.1 ij.2 n) :=
    (Primrec.nat_rec (Primrec.const ([], [])) hs).of_eq fun ij n => by
      induction n with
      | zero => rfl
      | succ n ih => simp only [alternatingPair, ih]
  exact hrec

theorem relatorWord_primrec : Primrec (fun p : FiniteArtinGroup.Diagram × (Nat × Nat) =>
    relatorWord p.1 p.2.1 p.2.2) := by
  have hp := alternatingPair_primrec.comp (Primrec.snd.pair matrixEntry_primrec)
  exact Primrec.list_append.comp (Primrec.fst.comp hp) (inverse_primrec.comp (Primrec.snd.comp hp))

theorem relationList_primrec : Primrec relationList := by
  have he : PrimrecPred (fun p : (FiniteArtinGroup.Diagram × Nat) × Nat => p.1.2 = p.2) :=
    Primrec.eq.comp (Primrec.snd.comp Primrec.fst) Primrec.snd
  have hw : Primrec (fun p : (FiniteArtinGroup.Diagram × Nat) × Nat => relatorWord p.1.1 p.1.2 p.2) :=
    relatorWord_primrec.comp ((Primrec.fst.comp Primrec.fst).pair
      ((Primrec.snd.comp Primrec.fst).pair Primrec.snd))
  have hentry : Primrec₂ (fun p : FiniteArtinGroup.Diagram × Nat => fun j : Nat =>
      if p.2 = j then none else some (relatorWord p.1 p.2 j)) :=
    Primrec.ite he (Primrec.const none) (Primrec.option_some.comp hw)
  have hrow : Primrec₂ (fun X : FiniteArtinGroup.Diagram => fun i : Nat =>
      (List.range X.2).filterMap fun j => if i = j then none else some (relatorWord X i j)) :=
    Primrec.listFilterMap (Primrec.list_range.comp (Primrec.snd.comp Primrec.fst)) hentry
  exact Primrec.list_flatMap (Primrec.list_range.comp Primrec.snd) hrow

theorem code_primrec : Primrec code := Primrec.snd.pair relationList_primrec

end DCPv7.SphericalPresentation
