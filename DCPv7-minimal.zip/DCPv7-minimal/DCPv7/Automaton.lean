import Std

/-! Deterministic word automata and the paths used in Lemma `lem:biautomatic`.

These definitions use arbitrary state types; the effective applications use
finite state types. In particular, trimming means retaining exactly the states
that lie on an accepting path, as in the paper.
-/
namespace DCPv7

structure WordAutomaton (α Q : Type) where
  step : Q → α → Q
  start : Q
  accept : Q → Prop

namespace WordAutomaton

variable {α Q : Type} (M : WordAutomaton α Q)

def evalFrom (q : Q) : List α → Q
  | [] => q
  | a :: w => evalFrom (M.step q a) w

def Accepts (w : List α) : Prop := M.accept (M.evalFrom M.start w)

theorem evalFrom_append (q : Q) (u v : List α) :
    M.evalFrom q (u ++ v) = M.evalFrom (M.evalFrom q u) v := by
  induction u generalizing q with
  | nil => rfl
  | cons a u ih => exact ih (M.step q a)

/-- A state survives trimming exactly when it is on an accepting path. -/
def Useful (q : Q) : Prop :=
  ∃ p t : List α, M.evalFrom M.start p = q ∧ M.accept (M.evalFrom q t)

theorem useful_start {w : List α} (hw : M.Accepts w) : M.Useful M.start :=
  ⟨[], w, rfl, hw⟩

theorem useful_of_prefix_suffix (p t : List α) (h : M.Accepts (p ++ t)) :
    M.Useful (M.evalFrom M.start p) :=
  ⟨p, t, rfl, by simpa only [Accepts, M.evalFrom_append] using h⟩

/-- Chosen paths to and from each retained state. The initial path is empty. -/
structure TrimPaths where
  prefixWord : Q → List α
  suffixWord : Q → List α
  prefix_start : prefixWord M.start = []
  prefix_spec : ∀ q, M.Useful q → M.evalFrom M.start (prefixWord q) = q
  suffix_spec : ∀ q, M.Useful q → M.accept (M.evalFrom q (suffixWord q))

variable (paths : M.TrimPaths)

theorem prefix_suffix_accepted (q : Q) (hq : M.Useful q) :
    M.Accepts (paths.prefixWord q ++ paths.suffixWord q) := by
  simp only [Accepts, M.evalFrom_append, paths.prefix_spec q hq]
  exact paths.suffix_spec q hq

theorem edge_suffix_accepted (q : Q) (a : α) (hq : M.Useful q)
    (hr : M.Useful (M.step q a)) :
    M.Accepts (paths.prefixWord q ++ a :: paths.suffixWord (M.step q a)) := by
  simp only [Accepts, M.evalFrom_append, paths.prefix_spec q hq, evalFrom]
  exact paths.suffix_spec (M.step q a) hr

theorem useful_next (q : Q) (a : α) (w : List α) (hq : M.Useful q)
    (hw : M.accept (M.evalFrom (M.step q a) w)) : M.Useful (M.step q a) := by
  obtain ⟨p, _, hp, _⟩ := hq
  refine ⟨p ++ [a], w, ?_, hw⟩
  simp only [M.evalFrom_append, hp, evalFrom]

end WordAutomaton
end DCPv7
