import DCPv7.BiautomaticInterfaces
import DCPv7.SphericalPresentation
import DCPv7.SphericalAlgorithms
import DCPv7.PromiseTotalization

/-! Transport the general promise-partial biautomatic algorithms to the concrete
spherical presentations. Unsupported or invalid inputs return fixed defaults.
On promised inputs termination is supplied by the proved general algorithms.
No direct spherical algorithm axiom is used.
-/
namespace DCPv7.DerivedSphericalAlgorithms
open BraidGroup FiniteArtinGroup
open FinitePresentation (encodeRaw decodeRaw)
set_option backward.isDefEq.respectTransparency false

abbrev WordInput := Diagram × (RawWord × RawWord)
abbrev CentralizerInput := Diagram × List RawWord
abbrev SimultaneousInput := Diagram × RawInstance

instance supported_decidable : DecidablePred Supported := fun X =>
  inferInstanceAs (Decidable
    ((X.1 = 0 ∧ 2 ≤ X.2) ∨ (X.1 = 1 ∧ 4 ≤ X.2) ∨
      (X.1 = 2 ∧ (X.2 = 6 ∨ X.2 = 7 ∨ X.2 = 8)) ∨
      (X.1 = 3 ∧ (X.2 = 2 ∨ X.2 = 3 ∨ X.2 = 4))))

def RawValidAt (X : Diagram) (w : RawWord) : Prop := RawValid (X.2 + 1) w

instance rawValidAt_decidable : DecidableRel RawValidAt := fun X w =>
  inferInstanceAs (Decidable (∀ a ∈ w, a.1 < (X.2 + 1) - 1))

theorem supported_primrec : PrimrecPred Supported := by
  let tag (t : Fin 4) : PrimrecPred (fun X : Diagram => X.1 = t) :=
    Primrec.eq.comp Primrec.fst (Primrec.const t)
  let rank (r : Nat) : PrimrecPred (fun X : Diagram => X.2 = r) :=
    Primrec.eq.comp Primrec.snd (Primrec.const r)
  exact ((tag 0).and (Primrec.nat_le.comp (Primrec.const 2) Primrec.snd)).or
    (((tag 1).and (Primrec.nat_le.comp (Primrec.const 4) Primrec.snd)).or
      (((tag 2).and ((rank 6).or ((rank 7).or (rank 8)))).or
        ((tag 3).and ((rank 2).or ((rank 3).or (rank 4))))))

theorem rawValidAt_primrec : PrimrecRel RawValidAt := by
  have hr : PrimrecRel (fun a : RawLetter => fun r : Nat => a.1 < r) :=
    Primrec.nat_lt.comp (Primrec.fst.comp Primrec.fst) Primrec.snd
  exact (hr.forall_mem_list.comp Primrec.snd (Primrec.snd.comp Primrec.fst)).of_eq
    (fun p => by simp only [RawValidAt, RawValid, Nat.add_sub_cancel])

def WordPromise (p : WordInput) : Prop :=
  Supported p.1 ∧ RawValidAt p.1 p.2.1 ∧ RawValidAt p.1 p.2.2

def CentralizerPromise (p : CentralizerInput) : Prop :=
  Supported p.1 ∧ ∀ w ∈ p.2, RawValidAt p.1 w

def SimultaneousPromise (p : SimultaneousInput) : Prop :=
  Supported p.1 ∧ InstanceValid p.1 p.2

instance wordPromise_decidable : DecidablePred WordPromise := fun p =>
  inferInstanceAs (Decidable (Supported p.1 ∧ RawValidAt p.1 p.2.1 ∧ RawValidAt p.1 p.2.2))
instance centralizerPromise_decidable : DecidablePred CentralizerPromise := fun p =>
  inferInstanceAs (Decidable (Supported p.1 ∧ ∀ w ∈ p.2, RawValidAt p.1 w))
instance simultaneousPromise_decidable : DecidablePred SimultaneousPromise := fun p =>
  inferInstanceAs (Decidable (Supported p.1 ∧
    ∀ uv ∈ p.2, RawValidAt p.1 uv.1 ∧ RawValidAt p.1 uv.2))

theorem wordPromise_primrec : PrimrecPred WordPromise :=
  (supported_primrec.comp Primrec.fst).and
    ((rawValidAt_primrec.comp Primrec.fst (Primrec.fst.comp Primrec.snd)).and
      (rawValidAt_primrec.comp Primrec.fst (Primrec.snd.comp Primrec.snd)))

theorem centralizerPromise_primrec : PrimrecPred CentralizerPromise :=
  (supported_primrec.comp Primrec.fst).and
    (rawValidAt_primrec.swap.forall_mem_list.comp Primrec.snd Primrec.fst)

theorem simultaneousPromise_primrec : PrimrecPred SimultaneousPromise := by
  have hr : PrimrecRel (fun uv : RawWord × RawWord => fun X : Diagram =>
      RawValidAt X uv.1 ∧ RawValidAt X uv.2) :=
    (rawValidAt_primrec.comp Primrec.snd (Primrec.fst.comp Primrec.fst)).and
      (rawValidAt_primrec.comp Primrec.snd (Primrec.snd.comp Primrec.fst))
  exact (supported_primrec.comp Primrec.fst).and
    (hr.forall_mem_list.comp Primrec.snd Primrec.fst)

def encodeWords (s : List RawWord) : List FinitePresentation.Word := s.map encodeRaw
def decodeWords (s : List FinitePresentation.Word) : List RawWord := s.map decodeRaw
def encodeInstance (e : RawInstance) : List (FinitePresentation.Word × FinitePresentation.Word) :=
  e.map fun uv => (encodeRaw uv.1, encodeRaw uv.2)

theorem encodeWords_primrec : Primrec encodeWords :=
  Primrec.list_map Primrec.id (Primrec.to₂ (FinitePresentation.encodeRaw_primrec.comp Primrec.snd))
theorem decodeWords_primrec : Primrec decodeWords :=
  Primrec.list_map Primrec.id (Primrec.to₂ (FinitePresentation.decodeRaw_primrec.comp Primrec.snd))
theorem encodeInstance_primrec : Primrec encodeInstance :=
  Primrec.list_map Primrec.id (Primrec.to₂
    ((FinitePresentation.encodeRaw_primrec.comp (Primrec.fst.comp Primrec.snd)).pair
      (FinitePresentation.encodeRaw_primrec.comp (Primrec.snd.comp Primrec.snd))))

def wordInput (p : WordInput) : FinitePresentation.Presentation ×
    (FinitePresentation.Word × FinitePresentation.Word) :=
  (SphericalPresentation.code p.1, (encodeRaw p.2.1, encodeRaw p.2.2))
def centralizerInput (p : CentralizerInput) : FinitePresentation.Presentation × List FinitePresentation.Word :=
  (SphericalPresentation.code p.1, encodeWords p.2)
def simultaneousInput (p : SimultaneousInput) : FinitePresentation.Presentation ×
    List (FinitePresentation.Word × FinitePresentation.Word) :=
  (SphericalPresentation.code p.1, encodeInstance p.2)

theorem wordInput_primrec : Primrec wordInput :=
  (SphericalPresentation.code_primrec.comp Primrec.fst).pair
    ((FinitePresentation.encodeRaw_primrec.comp (Primrec.fst.comp Primrec.snd)).pair
      (FinitePresentation.encodeRaw_primrec.comp (Primrec.snd.comp Primrec.snd)))
theorem centralizerInput_primrec : Primrec centralizerInput :=
  (SphericalPresentation.code_primrec.comp Primrec.fst).pair (encodeWords_primrec.comp Primrec.snd)
theorem simultaneousInput_primrec : Primrec simultaneousInput :=
  (SphericalPresentation.code_primrec.comp Primrec.fst).pair (encodeInstance_primrec.comp Primrec.snd)

def wordRun (A : Biautomatic.Algorithms) (p : WordInput) : Part Bool := A.word (wordInput p)
def centralizerRun (A : Biautomatic.Algorithms) (p : CentralizerInput) : Part (List RawWord) :=
  (A.centralizer (centralizerInput p)).map decodeWords
def simultaneousRun (A : Biautomatic.Algorithms) (p : SimultaneousInput) : Part Bool :=
  A.simultaneous (simultaneousInput p)

theorem wordRun_partrec (A : Biautomatic.Algorithms) : Partrec (wordRun A) :=
  A.word_partrec.comp wordInput_primrec.to_comp
theorem centralizerRun_partrec (A : Biautomatic.Algorithms) : Partrec (centralizerRun A) :=
  (A.centralizer_partrec.comp centralizerInput_primrec.to_comp).map
    (decodeWords_primrec.to_comp.comp Computable.snd).to₂
theorem simultaneousRun_partrec (A : Biautomatic.Algorithms) : Partrec (simultaneousRun A) :=
  A.simultaneous_partrec.comp simultaneousInput_primrec.to_comp

variable (A : Biautomatic.Algorithms)
variable (hbio : ∀ X, Supported X → Biautomatic.IsBiautomatic (SphericalPresentation.code X))

include hbio in
theorem wordRun_dom (p : WordInput) (hp : WordPromise p) : (wordRun A p).Dom :=
  (A.word_spec _ (hbio p.1 hp.1) _ _
    (SphericalPresentation.valid_encodeRaw p.1 p.2.1 hp.2.1)
    (SphericalPresentation.valid_encodeRaw p.1 p.2.2 hp.2.2)).1

include hbio in
theorem centralizerRun_dom (p : CentralizerInput) (hp : CentralizerPromise p) :
    (centralizerRun A p).Dom := by
  apply (A.centralizer_spec _ (hbio p.1 hp.1) _ ?_).1
  intro w hw
  obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hw
  exact SphericalPresentation.valid_encodeRaw p.1 v (hp.2 v hv)

include hbio in
theorem simultaneousRun_dom (p : SimultaneousInput) (hp : SimultaneousPromise p) :
    (simultaneousRun A p).Dom := by
  apply (A.simultaneous_spec _ (hbio p.1 hp.1) _ ?_).1
  intro uv huv
  obtain ⟨v, hv, rfl⟩ := List.mem_map.mp huv
  exact ⟨SphericalPresentation.valid_encodeRaw p.1 v.1 (hp.2 v hv).1,
    SphericalPresentation.valid_encodeRaw p.1 v.2 (hp.2 v hv).2⟩

noncomputable def word : WordInput → Bool :=
  PromiseTotalization.totalize WordPromise (wordRun A) false (wordRun_dom A hbio)
noncomputable def centralizer : CentralizerInput → List RawWord :=
  PromiseTotalization.totalize CentralizerPromise (centralizerRun A) [] (centralizerRun_dom A hbio)
noncomputable def simultaneous : SimultaneousInput → Bool :=
  PromiseTotalization.totalize SimultaneousPromise (simultaneousRun A) false (simultaneousRun_dom A hbio)

theorem word_computable : Computable (word A hbio) :=
  PromiseTotalization.totalize_computable _ _ _ _ wordPromise_primrec (wordRun_partrec A)
theorem centralizer_computable : Computable (centralizer A hbio) :=
  PromiseTotalization.totalize_computable _ _ _ _ centralizerPromise_primrec (centralizerRun_partrec A)
theorem simultaneous_computable : Computable (simultaneous A hbio) :=
  PromiseTotalization.totalize_computable _ _ _ _ simultaneousPromise_primrec (simultaneousRun_partrec A)

theorem value_encode_eq_iff (X : Diagram) (u v : RawWord)
    (hu : RawValid (X.2 + 1) u) (hv : RawValid (X.2 + 1) v) :
    FinitePresentation.value (SphericalPresentation.code X) (encodeRaw u) =
        FinitePresentation.value (SphericalPresentation.code X) (encodeRaw v) ↔
      FiniteArtinGroup.rawEval X u = FiniteArtinGroup.rawEval X v := by
  constructor
  · intro he
    have hm := congrArg (SphericalPresentation.equiv X) he
    simpa only [SphericalPresentation.equiv_value_encodeRaw X u hu,
      SphericalPresentation.equiv_value_encodeRaw X v hv] using hm
  · intro he
    apply (SphericalPresentation.equiv X).injective
    rw [SphericalPresentation.equiv_value_encodeRaw X u hu,
      SphericalPresentation.equiv_value_encodeRaw X v hv]
    exact he

theorem word_spec (X : Diagram) (hX : Supported X) (u v : RawWord)
    (hu : RawValid (X.2 + 1) u) (hv : RawValid (X.2 + 1) v) :
    word A hbio (X, (u, v)) = true ↔ FiniteArtinGroup.rawEval X u = FiniteArtinGroup.rawEval X v := by
  have hb := PromiseTotalization.totalize_mem WordPromise (wordRun A) false (wordRun_dom A hbio)
    (X, (u, v)) ⟨hX, hu, hv⟩
  have hs := (A.word_spec _ (hbio X hX) _ _
    (SphericalPresentation.valid_encodeRaw X u hu) (SphericalPresentation.valid_encodeRaw X v hv)).2 _ hb
  exact hs.trans (value_encode_eq_iff X u v hu hv)

theorem map_centralizer_equiv {G H : Type} [Group G] [Group H]
    (e : G ≃* H) (K : Subgroup G) :
    (Subgroup.centralizer (K : Set G)).map e.toMonoidHom =
      Subgroup.centralizer (K.map e.toMonoidHom : Set H) := by
  ext x
  constructor
  · rintro ⟨y, hy, rfl⟩ z ⟨k, hk, rfl⟩
    change e k * e y = e y * e k
    simpa only [map_mul] using congrArg e (hy k hk)
  · intro hx
    refine ⟨e.symm x, ?_, e.apply_symm_apply x⟩
    intro k hk
    apply e.injective
    simpa only [map_mul, e.apply_symm_apply] using hx (e k) ⟨k, hk, rfl⟩

theorem subgroup_encode_map (X : Diagram) (s : List RawWord)
    (hs : ∀ w ∈ s, RawValid (X.2 + 1) w) :
    (Biautomatic.subgroup (SphericalPresentation.code X) (encodeWords s)).map
        (SphericalPresentation.equiv X).toMonoidHom = FiniteArtinGroup.rawSubgroup X s := by
  unfold Biautomatic.subgroup FiniteArtinGroup.rawSubgroup
  rw [MonoidHom.map_closure]
  congr 1
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hx
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hw
    exact List.mem_map.mpr ⟨v, hv, (SphericalPresentation.equiv_value_encodeRaw X v (hs v hv)).symm⟩
  · intro hy
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hy
    refine ⟨FinitePresentation.value (SphericalPresentation.code X) (encodeRaw w),
      List.mem_map.mpr ⟨encodeRaw w, List.mem_map.mpr ⟨w, hw, rfl⟩, rfl⟩, ?_⟩
    exact SphericalPresentation.equiv_value_encodeRaw X w (hs w hw)

theorem closure_decode_map (X : Diagram) (s : List FinitePresentation.Word)
    (hs : ∀ w ∈ s, FinitePresentation.ValidWord (SphericalPresentation.code X) w) :
    (Subgroup.closure {g | g ∈ s.map (FinitePresentation.value (SphericalPresentation.code X))}).map
        (SphericalPresentation.equiv X).toMonoidHom =
      Subgroup.closure {g | g ∈ (decodeWords s).map (FiniteArtinGroup.rawEval X)} := by
  rw [MonoidHom.map_closure]
  congr 1
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hx
    exact List.mem_map.mpr ⟨decodeRaw w, List.mem_map.mpr ⟨w, hw, rfl⟩,
      (SphericalPresentation.equiv_value_decodeRaw X w (hs w hw)).symm⟩
  · intro hy
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hy
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hw
    exact ⟨FinitePresentation.value (SphericalPresentation.code X) v,
      List.mem_map.mpr ⟨v, hv, rfl⟩, SphericalPresentation.equiv_value_decodeRaw X v (hs v hv)⟩

theorem centralizer_spec (X : Diagram) (hX : Supported X) (s : List RawWord)
    (hs : ∀ w ∈ s, RawValid (X.2 + 1) w) :
    (∀ w ∈ centralizer A hbio (X, s), RawValid (X.2 + 1) w) ∧
      GroupDCP.Generates ((centralizer A hbio (X, s)).map (FiniteArtinGroup.rawEval X))
        (Subgroup.centralizer (FiniteArtinGroup.rawSubgroup X s : Set (OfDiagram X))) := by
  have hrun := PromiseTotalization.totalize_mem CentralizerPromise (centralizerRun A) []
    (centralizerRun_dom A hbio) (X, s) ⟨hX, hs⟩
  obtain ⟨t, ht, he⟩ := (Part.mem_map_iff decodeWords).mp hrun
  change decodeWords t = centralizer A hbio (X, s) at he
  have hv : ∀ w ∈ encodeWords s, FinitePresentation.ValidWord (SphericalPresentation.code X) w := by
    intro w hw
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hw
    exact SphericalPresentation.valid_encodeRaw X v (hs v hv)
  have hspec := (A.centralizer_spec _ (hbio X hX) _ hv).2 t ht
  constructor
  · intro w hw
    rw [← he] at hw
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hw
    exact SphericalPresentation.valid_decodeRaw X v (hspec.1 v hv)
  · change Subgroup.closure {g | g ∈ (centralizer A hbio (X, s)).map (FiniteArtinGroup.rawEval X)} = _
    rw [← he]
    have hm := congrArg (fun K : Subgroup (FinitePresentation.GroupOf (SphericalPresentation.code X)) =>
      K.map (SphericalPresentation.equiv X).toMonoidHom) hspec.2
    rw [closure_decode_map X t hspec.1, map_centralizer_equiv, subgroup_encode_map X s hs] at hm
    exact hm

theorem instanceSolvable_encode_iff (X : Diagram) (e : RawInstance) (he : InstanceValid X e) :
    Biautomatic.InstanceSolvable (SphericalPresentation.code X) (encodeInstance e) ↔ InstanceSolvable X e := by
  constructor
  · rintro ⟨x, hx⟩
    refine ⟨SphericalPresentation.equiv X x, ?_⟩
    intro uv huv
    have h := hx (encodeRaw uv.1, encodeRaw uv.2) (List.mem_map.mpr ⟨uv, huv, rfl⟩)
    have hm := congrArg (SphericalPresentation.equiv X) h
    simpa only [map_mul, map_inv, SphericalPresentation.equiv_value_encodeRaw X uv.1 (he uv huv).1,
      SphericalPresentation.equiv_value_encodeRaw X uv.2 (he uv huv).2] using hm
  · rintro ⟨x, hx⟩
    refine ⟨(SphericalPresentation.equiv X).symm x, ?_⟩
    intro uv huv
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp huv
    apply (SphericalPresentation.equiv X).injective
    simpa only [map_mul, map_inv, MulEquiv.apply_symm_apply,
      SphericalPresentation.equiv_value_encodeRaw X v.1 (he v hv).1,
      SphericalPresentation.equiv_value_encodeRaw X v.2 (he v hv).2] using hx v hv

theorem simultaneous_spec (X : Diagram) (hX : Supported X) (e : RawInstance) (he : InstanceValid X e) :
    simultaneous A hbio (X, e) = true ↔ InstanceSolvable X e := by
  have hb := PromiseTotalization.totalize_mem SimultaneousPromise (simultaneousRun A) false
    (simultaneousRun_dom A hbio) (X, e) ⟨hX, he⟩
  have hv : Biautomatic.InstanceValid (SphericalPresentation.code X) (encodeInstance e) := by
    intro uv huv
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp huv
    exact ⟨SphericalPresentation.valid_encodeRaw X v.1 (he v hv).1,
      SphericalPresentation.valid_encodeRaw X v.2 (he v hv).2⟩
  exact ((A.simultaneous_spec _ (hbio X hX) _ hv).2 _ hb).trans (instanceSolvable_encode_iff X e he)

noncomputable def ofBiautomatic : SphericalAlgorithms.Algorithms where
  word := word A hbio
  word_computable := word_computable A hbio
  word_spec := word_spec A hbio
  centralizer := centralizer A hbio
  centralizer_computable := centralizer_computable A hbio
  centralizer_spec := centralizer_spec A hbio
  simultaneous := simultaneous A hbio
  simultaneous_computable := simultaneous_computable A hbio
  simultaneous_spec := simultaneous_spec A hbio

end DCPv7.DerivedSphericalAlgorithms
