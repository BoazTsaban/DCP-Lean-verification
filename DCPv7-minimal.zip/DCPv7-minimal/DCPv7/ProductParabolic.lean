import DCPv7.ProductDecision

/-! Parabolics for the union of coordinate-supported standard generators.
The decomposition and projection proofs follow `cor:products` and discharge
the product and coordinate promises of the concrete decision/search package.
-/
namespace DCPv7.ProductEncoding
open GroupDCP BraidGroup
set_option backward.isDefEq.respectTransparency false

def factorGenerator (c : FactorCode) (i : Fin (generatorCount c)) : FactorGroup c :=
  factorValue c [(i.val, true)]

theorem factorGenerator_braid (r : Nat) (i : Fin (r - 1)) :
    factorGenerator (0, r) i = BraidGroup.σ i := by
  simp [factorGenerator, factorValue, BraidGroup.rawEval, BraidGroup.rawLetter,
    BraidGroup.letterValue, i.isLt]

theorem factorGenerator_artin (t r : Nat) (i : Fin r) :
    factorGenerator (t + 1, r) i =
      FiniteArtinGroup.generator (M := FiniteArtinGroup.matrix (sourceDiagram (t + 1, r))) i := by
  simp [factorGenerator, factorValue, FiniteArtinGroup.rawEval, FiniteArtinGroup.rawLetter,
    sourceDiagram, i.isLt]

def FactorParabolic : ∀ c, Subgroup (FactorGroup c) → Prop
  | (0, _), A => BraidGroup.IsParabolic A
  | (t + 1, r), A => FiniteArtinGroup.IsParabolic (M := FiniteArtinGroup.matrix (sourceDiagram (t + 1, r))) A

theorem factorParabolic_conjugate (c : FactorCode) (I : Set (Fin (generatorCount c)))
    (a : FactorGroup c) :
    FactorParabolic c (conjugateSubgroup a (Subgroup.closure (factorGenerator c '' I))) := by
  rcases c with ⟨t, r⟩
  cases t with
  | zero =>
    have he : factorGenerator (0, r) = BraidGroup.σ := funext (factorGenerator_braid r)
    rw [he]
    exact ⟨I, a, rfl⟩
  | succ t =>
    have he : factorGenerator (t + 1, r) =
        FiniteArtinGroup.generator (M := FiniteArtinGroup.matrix (sourceDiagram (t + 1, r))) :=
      funext (factorGenerator_artin t r)
    rw [he]
    exact ⟨I, a, rfl⟩

abbrev ProductGeneratorIndex (factors : List FactorCode) :=
  (i : Fin factors.length) × Fin (generatorCount factors[i])

def productGenerator (factors : List FactorCode) (ij : ProductGeneratorIndex factors) :
    Tuple FactorGroup factors := Pi.mulSingle ij.1 (factorGenerator factors[ij.1] ij.2)

def ProductParabolic (factors : List FactorCode) (A : Subgroup (Tuple FactorGroup factors)) : Prop :=
  ∃ I : Set (ProductGeneratorIndex factors), ∃ a : Tuple FactorGroup factors,
    A = conjugateSubgroup a (Subgroup.closure (productGenerator factors '' I))

def coordinateGeneratorIndices (factors : List FactorCode) (I : Set (ProductGeneratorIndex factors))
    (i : Fin factors.length) : Set (Fin (generatorCount factors[i])) := {j | ⟨i, j⟩ ∈ I}

theorem productGenerator_image (factors : List FactorCode) (I : Set (ProductGeneratorIndex factors)) :
    productGenerator factors '' I = axesGenerators (fun i =>
      factorGenerator factors[i] '' coordinateGeneratorIndices factors I i) := by
  ext x
  constructor
  · rintro ⟨⟨i, j⟩, hij, rfl⟩
    exact ⟨i, factorGenerator factors[i] j, ⟨j, hij, rfl⟩, rfl⟩
  · rintro ⟨i, y, ⟨j, hj, rfl⟩, rfl⟩
    exact ⟨⟨i, j⟩, hj, rfl⟩

theorem productParabolic_decomposition (factors : List FactorCode)
    (A : Subgroup (Tuple FactorGroup factors)) (hA : ProductParabolic factors A) :
    ∃ C : ∀ i : Fin factors.length, Subgroup (FactorGroup factors[i]),
      (∀ i, FactorParabolic factors[i] (C i)) ∧ A = productSubgroup C := by
  obtain ⟨I, a, rfl⟩ := hA
  rw [productGenerator_image, conjugate_closure_axes]
  refine ⟨_, ?_, rfl⟩
  intro i
  exact factorParabolic_conjugate _ _ _

theorem productParabolic_projection (factors : List FactorCode)
    (A : Subgroup (Tuple FactorGroup factors)) (hA : ProductParabolic factors A)
    (i : Fin factors.length) :
    FactorParabolic factors[i] (A.map (Pi.evalMonoidHom (fun j => FactorGroup factors[j]) i)) := by
  obtain ⟨C, hC, rfl⟩ := productParabolic_decomposition factors A hA
  rw [productSubgroup_projection]
  exact hC i

theorem parabolic_productForm (p : Input) (s : List ProductWord)
    (hs : ProductParabolic p.1 (wordSubgroup FactorGroup factorValue p.1 s)) : ProductForm p s := by
  obtain ⟨C, _, he⟩ := productParabolic_decomposition p.1 _ hs
  unfold ProductForm
  rw [he]
  congr 1
  funext i
  have hproj := projection_wordSubgroup FactorGroup factorValue p.1 s i
  rw [he, productSubgroup_projection] at hproj
  exact hproj

theorem factorInputValid_of_conditions (p : CoordinateInput) (hc : ValidFactor p.1)
    (hAwords : ∀ w ∈ p.2.1, FactorWordValid p.1 w)
    (hBwords : ∀ w ∈ p.2.2.1, FactorWordValid p.1 w)
    (hg : FactorWordValid p.1 p.2.2.2.1) (hh : FactorWordValid p.1 p.2.2.2.2)
    (hA : FactorParabolic p.1 (Subgroup.closure {x | x ∈ p.2.1.map (factorValue p.1)}))
    (hB : FactorParabolic p.1 (Subgroup.closure {x | x ∈ p.2.2.1.map (factorValue p.1)})) :
    FactorInputValid p := by
  rcases p with ⟨⟨t, r⟩, s⟩
  cases t with
  | zero =>
    have hr : 1 ≤ r := by
      dsimp only [ValidFactor, Prod.fst, Prod.snd] at hc
      rcases hc with h | h | h | h | h <;> omega
    exact ⟨hr, hAwords, hBwords, hg, hh, hA, hB⟩
  | succ t =>
    have hallowed := ambient_allowed (t + 1, r) hc (by omega)
    have hsupported := DCPVerification.Spherical.allowed_supported _ _ hallowed
    exact ⟨hallowed, hsupported.1, hsupported.2, hAwords, hBwords, hg, hh, hA, hB⟩

def PaperValidInput (p : Input) : Prop := WordInputValid p ∧
  ProductParabolic p.1 (wordSubgroup FactorGroup factorValue p.1 p.2.1) ∧
  ProductParabolic p.1 (wordSubgroup FactorGroup factorValue p.1 p.2.2.1)

theorem paperInput_valid (p : Input) (hp : PaperValidInput p) : ValidInput p := by
  refine ⟨hp.1, ?_, parabolic_productForm p _ hp.2.1, parabolic_productForm p _ hp.2.2⟩
  intro i hi
  let j : Fin p.1.length := ⟨i, hi⟩
  simp only [coordinateInput]
  rw [List.getD_eq_getElem p.1 (0, 1) hi]
  apply factorInputValid_of_conditions
  · exact hp.1.1 _ (List.getElem_mem hi)
  · intro w hw
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hw
    have hs := project_valid p.1 i v (hp.1.2.1 v hv)
    simpa only [FactorWordValid, List.getD_eq_getElem p.1 (0, 1) hi] using hs
  · intro w hw
    obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hw
    have hs := project_valid p.1 i v (hp.1.2.2.1 v hv)
    simpa only [FactorWordValid, List.getD_eq_getElem p.1 (0, 1) hi] using hs
  · have hs := project_valid p.1 i p.2.2.2.1 hp.1.2.2.2.1
    simpa only [FactorWordValid, List.getD_eq_getElem p.1 (0, 1) hi] using hs
  · have hs := project_valid p.1 i p.2.2.2.2 hp.1.2.2.2.2
    simpa only [FactorWordValid, List.getD_eq_getElem p.1 (0, 1) hi] using hs
  · have hs := productParabolic_projection p.1 _ hp.2.1 j
    rw [projection_wordSubgroup] at hs
    exact hs
  · have hs := productParabolic_projection p.1 _ hp.2.2 j
    rw [projection_wordSubgroup] at hs
    exact hs

noncomputable section

theorem product_main_theorem (alg : SphericalAlgorithms.Algorithms) :
    ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, PaperValidInput p →
      (d p = true ↔ Positive FactorGroup factorValue p) ∧
      (d p = true → (s p).Dom) ∧ ∀ w ∈ s p, Witness FactorGroup factorValue p w :=
  ⟨decision alg, suppliedSearch alg, decision_computable alg, suppliedSearch_partrec alg, fun p hp =>
    ⟨decision_correct alg p (paperInput_valid p hp), fun hd => (suppliedSearch_terminates_iff alg p hp.1).mpr
      ((decision_correct alg p (paperInput_valid p hp)).mp hd), suppliedSearch_sound alg p hp.1⟩⟩

end
end DCPv7.ProductEncoding
