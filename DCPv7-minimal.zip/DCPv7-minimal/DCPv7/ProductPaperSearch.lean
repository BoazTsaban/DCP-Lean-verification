import DCPv7.ProductFactorSearch
import DCPv7.ProductTargetSearch
import DCPv7.ProductParabolic

/-! The product proof's literal witness route: run the factor searches, assemble
their particular target tuples, and express those tuples in the original
supplied generating lists. The final search preserves the selected targets.
-/
namespace DCPv7.ProductEncoding
open GroupDCP
set_option backward.isDefEq.respectTransparency false

theorem targetWordsValid_of_spec (p : Input) (ts : List (Word × Word))
    (ht : TargetSpec p ts) : TargetWordsValid p ts := by
  intro i
  exact ⟨ht.left_valid i, ht.right_valid i⟩

theorem targetLeft_mem (p : Input) (hp : ValidInput p) (ts : List (Word × Word))
    (ht : TargetSpec p ts) : targetLeftTuple p ts ∈ wordSubgroup FactorGroup factorValue p.1 p.2.1 := by
  rw [hp.2.2.1]
  exact (mem_productSubgroup _ _).mpr ht.left_mem

theorem targetRight_mem (p : Input) (hp : ValidInput p) (ts : List (Word × Word))
    (ht : TargetSpec p ts) : targetRightTuple p ts ∈ wordSubgroup FactorGroup factorValue p.1 p.2.2.1 := by
  rw [hp.2.2.2]
  exact (mem_productSubgroup _ _).mpr ht.right_mem

theorem targets_realizable (p : Input) (hp : ValidInput p) (ts : List (Word × Word))
    (ht : TargetSpec p ts) : ∃ w, TargetRealizes p ts w := by
  exact targetRealizes_exists_of_mem p ts
    (targetLeft_mem p hp ts ht) (targetRight_mem p hp ts ht)

theorem witness_of_targetRealizes (p : Input) (ts : List (Word × Word))
    (ht : TargetSpec p ts) (w : Candidate) (hw : TargetRealizes p ts w) :
    Witness FactorGroup factorValue p w := by
  refine ⟨hw.1, ?_⟩
  funext i
  change factorValue p.1[i] (project i.val p.2.2.2.2) =
    factorValue p.1[i] (project i.val (productSubstitute p.2.1 w.1)) *
      factorValue p.1[i] (project i.val p.2.2.2.1) *
      factorValue p.1[i] (project i.val (productSubstitute p.2.2.1 w.2))
  rw [(hw.2 i).1, (hw.2 i).2]
  exact ht.equation i

noncomputable section

def paperSearch (alg : SphericalAlgorithms.Algorithms) (p : Input) : Part Candidate :=
  (gather alg p).bind fun ts => targetSearch alg (p, ts)

theorem paperSearch_partrec (alg : SphericalAlgorithms.Algorithms) :
    Partrec (paperSearch alg) :=
  Partrec.bind (gather_partrec alg) (targetSearch_partrec alg)

theorem paperSearch_preserves_targets (alg : SphericalAlgorithms.Algorithms)
    (p : Input) (hp : ValidInput p) (w : Candidate) (hw : w ∈ paperSearch alg p) :
    ∃ ts ∈ gather alg p, TargetSpec p ts ∧ TargetRealizes p ts w := by
  obtain ⟨ts, hts, hsearch⟩ := Part.mem_bind_iff.mp hw
  have ht := gather_sound alg p hp ts hts
  exact ⟨ts, hts, ht,
    targetSearch_sound alg p hp.1 ts (targetWordsValid_of_spec p ts ht) w hsearch⟩

theorem paperSearch_sound (alg : SphericalAlgorithms.Algorithms) (p : Input)
    (hp : ValidInput p) (w : Candidate) (hw : w ∈ paperSearch alg p) :
    Witness FactorGroup factorValue p w := by
  obtain ⟨ts, _, ht, hw⟩ := paperSearch_preserves_targets alg p hp w hw
  exact witness_of_targetRealizes p ts ht w hw

theorem paperSearch_dom (alg : SphericalAlgorithms.Algorithms) (p : Input)
    (hp : ValidInput p) (hpos : Positive FactorGroup factorValue p) : (paperSearch alg p).Dom := by
  obtain ⟨ts, hts⟩ := Part.dom_iff_mem.mp (gather_dom alg p hp hpos)
  have ht := gather_sound alg p hp ts hts
  have hd := (targetSearch_dom alg p hp.1 ts (targetWordsValid_of_spec p ts ht)).mpr
    (targets_realizable p hp ts ht)
  obtain ⟨w, hw⟩ := Part.dom_iff_mem.mp hd
  exact Part.dom_iff_mem.mpr ⟨w, Part.mem_bind hts hw⟩

theorem paper_product_main_theorem (alg : SphericalAlgorithms.Algorithms) :
    ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, PaperValidInput p →
      (d p = true ↔ Positive FactorGroup factorValue p) ∧
      (d p = true → (s p).Dom) ∧ ∀ w ∈ s p, Witness FactorGroup factorValue p w := by
  refine ⟨decision alg, paperSearch alg, decision_computable alg, paperSearch_partrec alg, ?_⟩
  intro p hp
  have hv := paperInput_valid p hp
  exact ⟨decision_correct alg p hv,
    fun hd => paperSearch_dom alg p hv ((decision_correct alg p hv).mp hd),
    paperSearch_sound alg p hv⟩

end
end DCPv7.ProductEncoding
