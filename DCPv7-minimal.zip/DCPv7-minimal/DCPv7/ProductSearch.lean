import DCPv7.ProductComputability
import DCPv7.ProductWords
import DCPv7.SignedSearch

/-! Length-ordered search in the original supplied product generators, using
the concrete coordinate encoder. Correctness is relative to the factor word
tests specified below; dispatch to the listed factor algorithms is separate.
-/
namespace DCPv7.ProductEncoding

abbrev Candidate := Word × Word
abbrev WordTestInput := FactorCode × (Word × Word)

def WordBound (k : Nat) (w : Word) : Prop := ∀ a ∈ w, a.1 < k

instance wordBound_decidable : DecidableRel WordBound := fun k w =>
  inferInstanceAs (Decidable (∀ a ∈ w, a.1 < k))

theorem wordBound_primrec : PrimrecRel WordBound := by
  have hr : PrimrecRel (fun a : Letter => fun k : Nat => a.1 < k) :=
    Primrec.nat_lt.comp (Primrec.fst.comp Primrec.fst) Primrec.snd
  exact hr.forall_mem_list.comp Primrec.snd Primrec.fst

def CandidateValid (p : Input) (w : Candidate) : Prop :=
  WordBound p.2.1.length w.1 ∧ WordBound p.2.2.1.length w.2

instance candidateValid_decidable : DecidableRel CandidateValid := fun p w =>
  inferInstanceAs (Decidable (WordBound p.2.1.length w.1 ∧ WordBound p.2.2.1.length w.2))

def expandedCandidate (p : Input) (w : Candidate) : ProductWord :=
  productSubstitute p.2.1 w.1 ++ p.2.2.2.1 ++ productSubstitute p.2.2.1 w.2

theorem productInverse_primrec : Primrec productInverse :=
  Primrec.list_map Primrec.list_reverse (Primrec.to₂
    ((Primrec.fst.comp Primrec.snd).pair
      ((Primrec.fst.comp (Primrec.snd.comp Primrec.snd)).pair
        ((Primrec.dom_finite Bool.not).comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))))))

theorem productSubstitute_primrec : Primrec₂ productSubstitute := by
  have hget : Primrec (fun q : List ProductWord × Letter => q.1.getD q.2.1 []) :=
    (Primrec.list_getD []).comp Primrec.fst (Primrec.fst.comp Primrec.snd)
  have hchunk : Primrec₂ productChunk :=
    (Primrec.cond (Primrec.snd.comp Primrec.snd) hget (productInverse_primrec.comp hget)).of_eq
      (fun q => by rcases q with ⟨s, i, b⟩; cases b <;> rfl)
  exact Primrec.list_flatMap Primrec.snd
    (Primrec.to₂ (hchunk.comp (Primrec.fst.comp Primrec.fst) Primrec.snd))

theorem candidateValid_primrec : PrimrecRel CandidateValid := by
  have hl : Primrec (fun q : Input × Candidate => q.1.2.1.length) :=
    Primrec.list_length.comp (Primrec.fst.comp (Primrec.snd.comp Primrec.fst))
  have hr : Primrec (fun q : Input × Candidate => q.1.2.2.1.length) :=
    Primrec.list_length.comp (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)))
  exact (wordBound_primrec.comp hl (Primrec.fst.comp Primrec.snd)).and
    (wordBound_primrec.comp hr (Primrec.snd.comp Primrec.snd))

theorem expandedCandidate_primrec : Primrec₂ expandedCandidate :=
  Primrec.list_append.comp
    (Primrec.list_append.comp
      (productSubstitute_primrec.comp (Primrec.fst.comp (Primrec.snd.comp Primrec.fst))
        (Primrec.fst.comp Primrec.snd))
      (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)))))
    (productSubstitute_primrec.comp
      (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)))
      (Primrec.snd.comp Primrec.snd))

def coordinateCheck (wordTest : WordTestInput → Bool) (q : Input × Candidate) (i : Nat) : Bool :=
  wordTest (q.1.1.getD i (0, 1),
    (project i q.1.2.2.2.2, project i (expandedCandidate q.1 q.2)))

theorem coordinateCheck_computable (wordTest : WordTestInput → Bool) (hd : Computable wordTest) :
    Computable₂ (coordinateCheck wordTest) := by
  have hc : Primrec (fun q : (Input × Candidate) × Nat => q.1.1.1.getD q.2 (0, 1)) :=
    (Primrec.list_getD (0, 1)).comp
      (Primrec.fst.comp (Primrec.fst.comp Primrec.fst)) Primrec.snd
  have hh : Primrec (fun q : (Input × Candidate) × Nat => project q.2 q.1.1.2.2.2.2) :=
    project_primrec.comp Primrec.snd
      (Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp
        (Primrec.snd.comp (Primrec.fst.comp Primrec.fst)))))
  have he : Primrec (fun q : (Input × Candidate) × Nat =>
      project q.2 (expandedCandidate q.1.1 q.1.2)) :=
    project_primrec.comp Primrec.snd
      (expandedCandidate_primrec.comp (Primrec.fst.comp Primrec.fst) (Primrec.snd.comp Primrec.fst))
  exact hd.comp (hc.pair (hh.pair he)).to_comp

def candidateTest (wordTest : WordTestInput → Bool) (p : Input) (w : Candidate) : Bool :=
  if CandidateValid p w then
    DCPVerification.allChecks (coordinateCheck wordTest) (p, w) (List.range p.1.length)
  else false

theorem candidateTest_computable (wordTest : WordTestInput → Bool) (hd : Computable wordTest) :
    Computable₂ (candidateTest wordTest) := by
  have ht := (DCPVerification.allChecks_computable _ (coordinateCheck_computable wordTest hd)).comp
    Computable.id
    (Primrec.list_range.comp (Primrec.list_length.comp (Primrec.fst.comp Primrec.fst))).to_comp
  exact (Computable.cond candidateValid_primrec.decide.to_comp ht (Computable.const false)).of_eq
    (fun q => by simp only [Bool.cond_decide]; rfl)

variable (G : FactorCode → Type) [∀ c, Group (G c)]
variable (value : ∀ c, Word → G c)

def Positive (p : Input) : Prop := GroupDCP.InDoubleCoset
  (wordSubgroup G value p.1 p.2.1) (wordSubgroup G value p.1 p.2.2.1)
  (tupleValue G value p.1 p.2.2.2.1) (tupleValue G value p.1 p.2.2.2.2)

def Witness (p : Input) (w : Candidate) : Prop := CandidateValid p w ∧
  tupleValue G value p.1 p.2.2.2.2 =
    tupleValue G value p.1 (productSubstitute p.2.1 w.1) * tupleValue G value p.1 p.2.2.2.1 *
      tupleValue G value p.1 (productSubstitute p.2.2.1 w.2)

variable {G value} (laws : EvaluationLaws G value)
include laws

theorem positive_iff_witness (p : Input) : Positive G value p ↔ ∃ w, Witness G value p w := by
  constructor
  · rintro ⟨a, ha, b, hb, he⟩
    obtain ⟨u, hu, heu⟩ := subgroupWord_exists laws p.1 p.2.1 ha
    obtain ⟨v, hv, hev⟩ := subgroupWord_exists laws p.1 p.2.2.1 hb
    exact ⟨(u, v), ⟨hu, hv⟩, by simpa only [heu, hev] using he⟩
  · rintro ⟨⟨u, v⟩, ⟨hu, hv⟩, he⟩
    exact ⟨_, substitute_mem laws p.1 p.2.1 u hu,
      _, substitute_mem laws p.1 p.2.2.1 v hv, he⟩

theorem candidateTest_correct (wordTest : WordTestInput → Bool) (p : Input)
    (hcheck : ∀ w, CandidateValid p w → ∀ i : Fin p.1.length,
      coordinateCheck wordTest (p, w) i.val = true ↔
        value p.1[i] (project i.val p.2.2.2.2) =
          value p.1[i] (project i.val (expandedCandidate p w)))
    (w : Candidate) : candidateTest wordTest p w = true ↔ Witness G value p w := by
  by_cases hw : CandidateValid p w
  · simp only [candidateTest, hw, if_true, Witness, true_and, DCPVerification.allChecks_spec,
      List.mem_range]
    have heq : (∀ i < p.1.length, coordinateCheck wordTest (p, w) i = true) ↔
        tupleValue G value p.1 p.2.2.2.2 = tupleValue G value p.1 (expandedCandidate p w) := by
      constructor
      · intro h
        funext i
        exact (hcheck w hw i).mp (h i.val i.isLt)
      · intro h i hi
        exact (hcheck w hw ⟨i, hi⟩).mpr (congrFun h ⟨i, hi⟩)
    rw [heq]
    simp only [expandedCandidate, tupleValue_append laws]
  · simp [candidateTest, Witness, hw]

def search (wordTest : WordTestInput → Bool) : Input → Part Candidate :=
  SignedSearch.run (fun p => p.2.1.length) (fun p => p.2.2.1.length) (candidateTest wordTest)

omit laws in
theorem search_partrec (wordTest : WordTestInput → Bool) (hd : Computable wordTest) :
    Partrec (search wordTest) :=
  SignedSearch.run_partrec _ _ _
    (Primrec.list_length.comp (Primrec.fst.comp Primrec.snd)).to_comp
    (Primrec.list_length.comp (Primrec.fst.comp (Primrec.snd.comp Primrec.snd))).to_comp
    (candidateTest_computable wordTest hd)

theorem search_sound (wordTest : WordTestInput → Bool) (p : Input)
    (hcheck : ∀ w, CandidateValid p w → ∀ i : Fin p.1.length,
      coordinateCheck wordTest (p, w) i.val = true ↔
        value p.1[i] (project i.val p.2.2.2.2) =
          value p.1[i] (project i.val (expandedCandidate p w)))
    (w : Candidate) (hw : w ∈ search wordTest p) : Witness G value p w :=
  (candidateTest_correct laws wordTest p hcheck w).mp
    (SignedSearch.run_sound _ _ _ p w hw).2.2

theorem search_terminates_iff (wordTest : WordTestInput → Bool) (p : Input)
    (hcheck : ∀ w, CandidateValid p w → ∀ i : Fin p.1.length,
      coordinateCheck wordTest (p, w) i.val = true ↔
        value p.1[i] (project i.val p.2.2.2.2) =
          value p.1[i] (project i.val (expandedCandidate p w))) :
    (search wordTest p).Dom ↔ Positive G value p := by
  rw [search, SignedSearch.run_dom]
  constructor
  · rintro ⟨w, _, _, ht⟩
    exact (positive_iff_witness laws p).mpr
      ⟨w, (candidateTest_correct laws wordTest p hcheck w).mp ht⟩
  · intro h
    obtain ⟨w, hw⟩ := (positive_iff_witness laws p).mp h
    exact ⟨w, hw.1.1, hw.1.2, (candidateTest_correct laws wordTest p hcheck w).mpr hw⟩

end DCPv7.ProductEncoding
