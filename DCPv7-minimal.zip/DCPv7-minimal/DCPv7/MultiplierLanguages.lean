import DCPv7.AutomatonGenerators
import Mathlib.GroupTheory.Subgroup.Centralizer

/-! The intersection/projection step in Lemma `lem:biautomatic`, including the
empty family. This file proves its group semantics; effective construction of
the padded regular relations is a separate obligation.
-/
namespace DCPv7.MultiplierLanguages

variable {α G : Type} [Group G]
variable (L : List α → Prop) (value : List α → G)

def leftRelation (u : G) (p q : List α) : Prop :=
  L p ∧ L q ∧ u * value p = value q

def rightRelation (v : G) (p q : List α) : Prop :=
  L p ∧ L q ∧ value p * v = value q

def conjugatorLanguage (u v : G) (p : List α) : Prop :=
  ∃ q, leftRelation L value u p q ∧ rightRelation L value v p q

theorem conjugatorLanguage_iff (representatives : ∀ g : G, ∃ q, L q ∧ value q = g)
    (u v : G) (p : List α) :
    conjugatorLanguage L value u v p ↔ L p ∧ (value p)⁻¹ * u * value p = v := by
  constructor
  · rintro ⟨q, ⟨hp, _, hleft⟩, ⟨_, _, hright⟩⟩
    refine ⟨hp, ?_⟩
    calc
      (value p)⁻¹ * u * value p = (value p)⁻¹ * (u * value p) := mul_assoc _ _ _
      _ = (value p)⁻¹ * (value p * v) := by rw [hleft, ← hright]
      _ = v := inv_mul_cancel_left _ _
  · rintro ⟨hp, he⟩
    obtain ⟨q, hq, hvalue⟩ := representatives (u * value p)
    refine ⟨q, ⟨hp, hq, hvalue.symm⟩, ⟨hp, hq, ?_⟩⟩
    rw [hvalue, ← he]
    simp [mul_assoc]

/-- Include L itself so that the empty system accepts exactly L. -/
def simultaneousLanguage (e : List (G × G)) (p : List α) : Prop :=
  L p ∧ ∀ uv ∈ e, conjugatorLanguage L value uv.1 uv.2 p

theorem simultaneousLanguage_iff
    (representatives : ∀ g : G, ∃ q, L q ∧ value q = g)
    (e : List (G × G)) (p : List α) :
    simultaneousLanguage L value e p ↔
      L p ∧ ∀ uv ∈ e, (value p)⁻¹ * uv.1 * value p = uv.2 := by
  simp only [simultaneousLanguage, conjugatorLanguage_iff L value representatives]
  constructor
  · rintro ⟨hp, he⟩
    exact ⟨hp, fun uv huv => (he uv huv).2⟩
  · rintro ⟨hp, he⟩
    exact ⟨hp, fun uv huv => ⟨hp, he uv huv⟩⟩

theorem simultaneousLanguage_nonempty
    (representatives : ∀ g : G, ∃ q, L q ∧ value q = g) (e : List (G × G)) :
    (∃ p, simultaneousLanguage L value e p) ↔
      ∃ x : G, ∀ uv ∈ e, x⁻¹ * uv.1 * x = uv.2 := by
  constructor
  · rintro ⟨p, hp⟩
    exact ⟨value p, ((simultaneousLanguage_iff L value representatives e p).mp hp).2⟩
  · rintro ⟨x, hx⟩
    obtain ⟨p, hp, hvalue⟩ := representatives x
    refine ⟨p, (simultaneousLanguage_iff L value representatives e p).mpr ⟨hp, ?_⟩⟩
    simpa only [hvalue] using hx

def centralizerLanguage (s : List G) : List α → Prop :=
  simultaneousLanguage L value (s.map fun u => (u, u))

theorem centralizerLanguage_iff
    (representatives : ∀ g : G, ∃ q, L q ∧ value q = g) (s : List G) (p : List α) :
    centralizerLanguage L value s p ↔
      L p ∧ value p ∈ Subgroup.centralizer {g | g ∈ s} := by
  rw [centralizerLanguage, simultaneousLanguage_iff L value representatives]
  constructor
  · rintro ⟨hp, he⟩
    refine ⟨hp, ?_⟩
    intro u hu
    have hconj := he (u, u) (List.mem_map.mpr ⟨u, hu, rfl⟩)
    calc
      u * value p = value p * ((value p)⁻¹ * u * value p) := by simp [mul_assoc]
      _ = value p * u := by rw [hconj]
  · rintro ⟨hp, hc⟩
    refine ⟨hp, ?_⟩
    intro uv huv
    obtain ⟨u, hu, rfl⟩ := List.mem_map.mp huv
    calc
      (value p)⁻¹ * u * value p = (value p)⁻¹ * (u * value p) := mul_assoc _ _ _
      _ = (value p)⁻¹ * (value p * u) := by rw [hc u hu]
      _ = u := inv_mul_cancel_left _ _

theorem centralizerLanguage_represents
    (representatives : ∀ g : G, ∃ q, L q ∧ value q = g) (s : List G)
    (g : G) (hg : g ∈ Subgroup.centralizer {x | x ∈ s}) :
    ∃ p, centralizerLanguage L value s p ∧ value p = g := by
  obtain ⟨p, hp, he⟩ := representatives g
  refine ⟨p, (centralizerLanguage_iff L value representatives s p).mpr ⟨hp, ?_⟩, he⟩
  simpa only [he] using hg

end DCPv7.MultiplierLanguages
