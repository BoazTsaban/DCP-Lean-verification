import DCPv7.LengthComputability
import DCPv7.AutomatonFinitePaths

/-! Primitive-recursive finite scans and bounded-word lists. -/
namespace DCPv7

theorem context_pair_primrec {A B C D : Type}
    [Primcodable A] [Primcodable B] [Primcodable C] [Primcodable D] :
    Primrec₂ (fun p : (A × B) × C => fun d : D => (p.1.1, d)) :=
  Primrec.to₂ ((Primrec.fst.comp (Primrec.fst.comp Primrec.fst)).pair Primrec.snd)

theorem context_apply_primrec {A B C D E : Type}
    [Primcodable A] [Primcodable B] [Primcodable C] [Primcodable D] [Primcodable E]
    (f : A → D → E) (hf : Primrec₂ f) :
    Primrec₂ (fun p : (A × B) × C => fun d : D => f p.1.1 d) :=
  Primrec.comp hf context_pair_primrec

theorem foldl_primrec {A : Type} [Primcodable A]
    (f : A → A → A) (hf : Primrec₂ f) :
    Primrec₂ (fun a s => List.foldl f a s) :=
  Primrec.list_foldl Primrec.snd Primrec.fst (Primrec.to₂ (Primrec.comp hf Primrec.snd))

end DCPv7

namespace DCPv7.LengthEnumeration
set_option backward.isDefEq.respectTransparency false

variable {α P : Type} [Primcodable α] [Primcodable P]

omit [Primcodable α] [Primcodable P] in
theorem first_eq_foldr (test : α → Bool) (s : List α) :
    first test s = s.foldr (fun a o => if test a then some a else o) none := by
  induction s with
  | nil => rfl
  | cons a s ih => simp only [first, List.foldr_cons, ih]

theorem first_primrec (test : P → α → Bool) (ht : Primrec₂ test) :
    Primrec₂ (fun p s => first (test p) s) := by
  have hc : Primrec (fun q : (P × List α) × (α × Option α) => test q.1.1 q.2.1) :=
    ht.comp (Primrec.fst.comp Primrec.fst) (Primrec.fst.comp Primrec.snd)
  have hs : Primrec₂ (fun p : P × List α => fun ao : α × Option α =>
      if test p.1 ao.1 then some ao.1 else ao.2) :=
    (Primrec.cond hc (Primrec.option_some.comp (Primrec.fst.comp Primrec.snd))
      (Primrec.snd.comp Primrec.snd)).of_eq
        (fun q => by dsimp only; cases test q.1.1 q.2.1 <;> rfl)
  exact (Primrec.list_foldr Primrec.snd (Primrec.const none) hs).of_eq
    (fun q => (first_eq_foldr (test q.1) q.2).symm)

end DCPv7.LengthEnumeration

namespace DCPv7.WordAutomaton

variable {α : Type} [Primcodable α]

theorem boundedWords_primrec : Primrec₂ (@boundedWords α) :=
  Primrec.list_flatMap (Primrec.list_range.comp Primrec.snd)
    (Primrec.to₂ (LengthEnumeration.words_primrec.comp (Primrec.fst.comp Primrec.fst) Primrec.snd))

end DCPv7.WordAutomaton
