import DCPv7.Literature
import DCPv7.EncodedProjection
import DCPv7.BiautomaticConjugators
import DCPv7.BiautomaticFiniteAlgorithms
import DCPv7.BiautomaticAlgorithms

/-! The manuscript biautomatic lemma, relative only to the specifically cited
BR/GS structure, word and fixed-multiplier constructions. Projection and all
local conjugator/centralizer/simultaneous deductions are proved, not axioms.
-/
namespace DCPv7.VerifiedBiautomatic
open FinitePresentation
noncomputable section

def structureConstruction : Biautomatic.StructureConstruction :=
  Classical.choice Literature.BR11_structure

def wordConstruction : Biautomatic.WordProblemConstruction :=
  Classical.choice Literature.BR11_word_procedure

def multipliers : Biautomatic.FixedMultipliers :=
  Classical.choice Literature.GS91_fixed_multipliers

def conjugators : Biautomatic.ConjugatorCompiler :=
  Biautomatic.ofMultipliers multipliers EncodedProjection.projectionCompiler

def structuredAlgorithms : Biautomatic.StructuredAlgorithms :=
  Biautomatic.ofConjugatorCompiler conjugators

def algorithms : Biautomatic.Algorithms :=
  Biautomatic.ofStructure structureConstruction wordConstruction structuredAlgorithms

theorem biautomatic_lemma : Nonempty Biautomatic.Algorithms := ⟨algorithms⟩

theorem word_problem_partrec : Partrec algorithms.word := algorithms.word_partrec
theorem centralizer_partrec : Partrec algorithms.centralizer := algorithms.centralizer_partrec
theorem simultaneous_partrec : Partrec algorithms.simultaneous := algorithms.simultaneous_partrec

theorem word_problem_correct (P : Presentation) (hP : Biautomatic.IsBiautomatic P)
    (u v : Word) (hu : ValidWord P u) (hv : ValidWord P v) :
    (algorithms.word (P, (u, v))).Dom ∧ ∀ b ∈ algorithms.word (P, (u, v)),
      (b = true ↔ value P u = value P v) := algorithms.word_spec P hP u v hu hv

theorem centralizer_correct (P : Presentation) (hP : Biautomatic.IsBiautomatic P)
    (s : List Word) (hs : ∀ w ∈ s, ValidWord P w) :
    (algorithms.centralizer (P, s)).Dom ∧ ∀ t ∈ algorithms.centralizer (P, s),
      (∀ w ∈ t, ValidWord P w) ∧ Subgroup.closure {g | g ∈ t.map (value P)} =
        Subgroup.centralizer (Biautomatic.subgroup P s : Set (GroupOf P)) :=
  algorithms.centralizer_spec P hP s hs

theorem simultaneous_correct (P : Presentation) (hP : Biautomatic.IsBiautomatic P)
    (e : List (Word × Word)) (he : Biautomatic.InstanceValid P e) :
    (algorithms.simultaneous (P, e)).Dom ∧ ∀ b ∈ algorithms.simultaneous (P, e),
      (b = true ↔ Biautomatic.InstanceSolvable P e) := algorithms.simultaneous_spec P hP e he

end
end DCPv7.VerifiedBiautomatic
