import DCPv7.SignedSearch
import DCPVerification.Constraints

/-! The main and constrained searches follow Remark `rem:witnesses` literally.
The group algebra and word tests are reused from the existing implementation;
the schedule is the newly proved increasing-total-length schedule.
-/
namespace DCPv7.MainSearch
open DCPVerification BraidGroup
noncomputable section

def search : Input → Part Candidate := SignedSearch.run
  (fun p => (leftWords p).length) (fun p => (rightWords p).length) candidateTest

theorem search_partrec : Partrec search :=
  SignedSearch.run_partrec _ _ _
    (Primrec.list_length.comp leftWords_primrec).to_comp
    (Primrec.list_length.comp rightWords_primrec).to_comp candidateTest_computable

theorem search_sound (p : Input) (hp : ValidInput p) (w : Candidate)
    (hw : w ∈ search p) : Witness p w :=
  (candidateTest_correct p hp w).mp (SignedSearch.run_sound _ _ _ p w hw).2.2

theorem search_terminates_iff (p : Input) (hp : ValidInput p) :
    (search p).Dom ↔ Positive p := by
  rw [search, SignedSearch.run_dom]
  constructor
  · rintro ⟨w, _, _, ht⟩
    exact (positive_iff_witness p).mpr ⟨w, (candidateTest_correct p hp w).mp ht⟩
  · intro h
    obtain ⟨w, hw⟩ := (positive_iff_witness p).mp h
    exact ⟨w, hw.1.1, hw.1.2, (candidateTest_correct p hp w).mpr hw⟩

theorem main_theorem : ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, ValidInput p →
      (d p = true ↔ Positive p) ∧ (d p = true → (s p).Dom) ∧
        ∀ w ∈ s p, Witness p w :=
  ⟨decision, search, decision_computable, search_partrec, fun p hp =>
    ⟨decision_correct p hp, fun h => (search_terminates_iff p hp).mpr
      ((decision_correct p hp).mp h), search_sound p hp⟩⟩

end
end DCPv7.MainSearch

namespace DCPv7.ConstrainedSearch
open DCPVerification DCPVerification.Constraints BraidGroup
noncomputable section

def search : Constraints.Input → Part Candidate := SignedSearch.run
  (fun p => (leftWords p.1).length) (fun p => (rightWords p.1).length)
    Constraints.candidateTest

theorem search_partrec : Partrec search :=
  SignedSearch.run_partrec _ _ _
    (Primrec.list_length.comp (leftWords_primrec.comp Primrec.fst)).to_comp
    (Primrec.list_length.comp (rightWords_primrec.comp Primrec.fst)).to_comp
    Constraints.candidateTest_computable

theorem search_sound (p : Constraints.Input) (hp : Constraints.ValidInput p) (w : Candidate)
    (hw : w ∈ search p) : Constraints.Witness p w :=
  (Constraints.candidateTest_correct p hp w).mp (SignedSearch.run_sound _ _ _ p w hw).2.2

theorem search_terminates_iff (p : Constraints.Input) (hp : Constraints.ValidInput p) :
    (search p).Dom ↔ Constraints.Positive p := by
  rw [search, SignedSearch.run_dom]
  constructor
  · rintro ⟨w, _, _, ht⟩
    exact (Constraints.positive_iff_witness p).mpr
      ⟨w, (Constraints.candidateTest_correct p hp w).mp ht⟩
  · intro h
    obtain ⟨w, hw⟩ := (Constraints.positive_iff_witness p).mp h
    exact ⟨w, hw.1.1.1, hw.1.1.2, (Constraints.candidateTest_correct p hp w).mpr hw⟩

theorem main_theorem : ∃ d : Constraints.Input → Bool,
    ∃ s : Constraints.Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, Constraints.ValidInput p →
      (d p = true ↔ Constraints.Positive p) ∧ (d p = true → (s p).Dom) ∧
        ∀ w ∈ s p, Constraints.Witness p w :=
  ⟨Constraints.decision, search, Constraints.decision_computable, search_partrec, fun p hp =>
    ⟨Constraints.decision_correct p hp, fun h => (search_terminates_iff p hp).mpr
      ((Constraints.decision_correct p hp).mp h), search_sound p hp⟩⟩

end
end DCPv7.ConstrainedSearch
