import DCPv7.AutomatonFinitePaths

/-! Trimming paths when the ambient alphabet is Nat but only a declared finite
alphabet is permitted. This is used by explicitly encoded finite automata.
-/
namespace DCPv7.WordAutomaton

variable {α Q : Type} (M : WordAutomaton α Q)

def AlphabetUseful (A : List α) (q : Q) : Prop :=
  ∃ p t : List α, M.evalFrom M.start p = q ∧ M.accept (M.evalFrom q t) ∧
    (∀ a ∈ p, a ∈ A) ∧ (∀ a ∈ t, a ∈ A)

variable [Fintype Q] [DecidableEq Q] [DecidablePred M.accept]

omit [DecidablePred M.accept] in
theorem prefixPath_exists_restricted (A : List α) (q : Q) (hq : M.AlphabetUseful A q) :
    ∃ w, M.prefixPath A q = some w := by
  obtain ⟨p, _, hp, _, hletters, _⟩ := hq
  obtain ⟨v, hv, he, hA⟩ := M.short_path A M.start p hletters
  apply (LengthEnumeration.first_terminates _ _).mpr
  exact ⟨v, (mem_boundedWords A _ v).mpr ⟨hv, hA⟩, by simp [he, hp]⟩

omit [DecidableEq Q] in
theorem suffixPath_exists_restricted (A : List α) (q : Q) (hq : M.AlphabetUseful A q) :
    ∃ w, M.suffixPath A q = some w := by
  obtain ⟨_, t, _, ht, _, hletters⟩ := hq
  obtain ⟨v, hv, he, hA⟩ := M.short_path A q t hletters
  apply (LengthEnumeration.first_terminates _ _).mpr
  exact ⟨v, (mem_boundedWords A _ v).mpr ⟨hv, hA⟩, by simpa [he] using ht⟩

theorem trimmed_iff_restricted (A : List α)
    (hvalid : ∀ q, M.Useful q → M.AlphabetUseful A q) (q : Q) :
    M.trimmed A q = true ↔ M.Useful q := by
  simp only [trimmed, Bool.and_eq_true, Option.isSome_iff_exists]
  constructor
  · rintro ⟨⟨p, hp⟩, ⟨t, ht⟩⟩
    exact ⟨p, t, M.prefixPath_sound A q p hp, M.suffixPath_sound A q t ht⟩
  · intro hq
    exact ⟨M.prefixPath_exists_restricted A q (hvalid q hq),
      M.suffixPath_exists_restricted A q (hvalid q hq)⟩

def restrictedTrimPaths (A : List α)
    (hvalid : ∀ q, M.Useful q → M.AlphabetUseful A q) : M.TrimPaths where
  prefixWord q := if q = M.start then [] else (M.prefixPath A q).getD []
  suffixWord q := (M.suffixPath A q).getD []
  prefix_start := by simp
  prefix_spec q hq := by
    by_cases he : q = M.start
    · simp [he, evalFrom]
    · obtain ⟨w, hw⟩ := M.prefixPath_exists_restricted A q (hvalid q hq)
      simpa only [if_neg he, hw, Option.getD_some] using M.prefixPath_sound A q w hw
  suffix_spec q hq := by
    obtain ⟨w, hw⟩ := M.suffixPath_exists_restricted A q (hvalid q hq)
    simpa only [hw, Option.getD_some] using M.suffixPath_sound A q w hw

end DCPv7.WordAutomaton
