import DCPv7.EncodedAutomatonPaths
import DCPv7.AutomatonGeneratorWords

/-! The explicit generator-word list computed from a natural-number DFA code. -/
namespace DCPv7.EncodedAutomaton
set_option backward.isDefEq.respectTransparency false

def prefixWord (D : Code) (q : Nat) : List Nat :=
  if q = startState D then [] else (prefixPath D q).getD []

def edgeWord (D : Code) (flip : Nat → Nat) (q a : Nat) : List Nat :=
  prefixWord D q ++ [a] ++ (prefixWord D (step D q a)).reverse.map flip

def edgeKeep (D : Code) (qa : Nat × Nat) : Bool :=
  trimmed D qa.1 && trimmed D (step D qa.1 qa.2)

def edgeStates (D : Code) : List (Nat × Nat) :=
  ((List.range (totalStates D)).product (List.range (alphabetSize D))).filter
    (fun qa => decide (edgeKeep D qa = true))

def finalKeep (D : Code) (q : Nat) : Bool := trimmed D q && acceptState D q

def finalStates (D : Code) : List Nat :=
  (List.range (totalStates D)).filter (fun q => decide (finalKeep D q = true))

def generatorWords (D : Code) (flip : Nat → Nat) : List (List Nat) :=
  (edgeStates D).map (fun qa => edgeWord D flip qa.1 qa.2) ++
    (finalStates D).map (prefixWord D)

theorem prefixWord_alphabet (D : Code) (q : Nat) :
    ∀ a ∈ prefixWord D q, a < alphabetSize D := by
  by_cases hq : q = startState D
  · simp [prefixWord, hq]
  · cases hp : prefixPath D q with
    | none => simp [prefixWord, hq, hp]
    | some w =>
      have hs := LengthEnumeration.first_sound (prefixTest (D, q)) (candidates D) w hp
      have hv := (WordAutomaton.mem_boundedWords _ _ w).mp hs.1
      simpa only [prefixWord, if_neg hq, hp, Option.getD_some, List.mem_range] using hv.2

theorem edgeWord_alphabet (D : Code) (flip : Nat → Nat)
    (hflip : ∀ a < alphabetSize D, flip a < alphabetSize D) (q a : Nat)
    (ha : a < alphabetSize D) : ∀ b ∈ edgeWord D flip q a, b < alphabetSize D := by
  intro b hb
  rcases List.mem_append.mp hb with hb | hb
  · rcases List.mem_append.mp hb with hb | hb
    · exact prefixWord_alphabet D q b hb
    · have he : b = a := List.mem_singleton.mp hb
      simpa only [he] using ha
  · obtain ⟨c, hc, rfl⟩ := List.mem_map.mp hb
    exact hflip c (prefixWord_alphabet D (step D q a) c (List.mem_reverse.mp hc))

theorem generatorWords_alphabet (D : Code) (flip : Nat → Nat)
    (hflip : ∀ a < alphabetSize D, flip a < alphabetSize D)
    (w : List Nat) (hw : w ∈ generatorWords D flip) : ∀ a ∈ w, a < alphabetSize D := by
  rcases List.mem_append.mp hw with hw | hw
  · obtain ⟨qa, hqa, rfl⟩ := List.mem_map.mp hw
    have ha := List.mem_range.mp (List.mem_product.mp (List.mem_filter.mp hqa).1).2
    exact edgeWord_alphabet D flip hflip qa.1 qa.2 ha
  · obtain ⟨q, _, rfl⟩ := List.mem_map.mp hw
    exact prefixWord_alphabet D q

theorem prefixWord_spec (D : Code) (q : Fin (totalStates D)) :
    prefixWord D q.val = (trimPaths D).prefixWord q := by
  change (if q.val = startState D then [] else (prefixPath D q.val).getD []) =
    if q = (machine D).start then [] else
      ((machine D).prefixPath (List.range (alphabetSize D)) q).getD []
  rw [prefixPath_spec]
  simp only [Fin.ext_iff]
  rfl

theorem edgeWord_spec (D : Code) (flip : Nat → Nat) (q : Fin (totalStates D)) (a : Nat) :
    edgeWord D flip q.val a = (machine D).edgeWord (trimPaths D) flip q a := by
  unfold edgeWord WordAutomaton.edgeWord
  rw [prefixWord_spec D q]
  have hs := prefixWord_spec D ((machine D).step q a)
  change prefixWord D (step D q.val a) = (trimPaths D).prefixWord ((machine D).step q a) at hs
  rw [hs]

theorem useful_edge_alphabet (D : Code) (q : Fin (totalStates D)) (a : Nat)
    (hr : (machine D).Useful ((machine D).step q a)) : a < alphabetSize D := by
  obtain ⟨_, t, _, ht⟩ := hr
  change acceptState D ((machine D).evalFrom ((machine D).step q a) t).val = true at ht
  rw [machine_evalFrom] at ht
  by_contra hn
  have hz : step D q.val a = 0 := by simp [step, hn]
  simp only [show ((machine D).step q a).val = step D q.val a from rfl,
    hz, evalFrom_zero, acceptState_zero, Bool.false_eq_true] at ht

theorem generatorWords_values {G : Type} [Group G] (D : Code) (flip : Nat → Nat)
    (letter : Nat → G) (hflip : ∀ a, letter (flip a) = (letter a)⁻¹) :
    {g | g ∈ (generatorWords D flip).map (wordValue letter)} =
      (machine D).generatorSet (trimPaths D) letter := by
  ext g
  constructor
  · intro hg
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hg
    rcases List.mem_append.mp hw with hw | hw
    · obtain ⟨qa, hqa, rfl⟩ := List.mem_map.mp hw
      have hmem := List.mem_filter.mp hqa
      have hb := List.mem_product.mp hmem.1
      have hkeep : trimmed D qa.1 = true ∧ trimmed D (step D qa.1 qa.2) = true :=
        by simpa only [edgeKeep, Bool.and_eq_true] using (of_decide_eq_true hmem.2)
      let q : Fin (totalStates D) := ⟨qa.1, List.mem_range.mp hb.1⟩
      refine Or.inl ⟨q, qa.2, (trimmed_correct D q).mp hkeep.1,
        (trimmed_correct D ((machine D).step q qa.2)).mp hkeep.2, ?_⟩
      rw [edgeWord_spec D flip q, WordAutomaton.edgeWord_value _ _ _ _ hflip]
    · obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hw
      have hmem := List.mem_filter.mp hq
      have hkeep : trimmed D q = true ∧ acceptState D q = true :=
        by simpa only [finalKeep, Bool.and_eq_true] using (of_decide_eq_true hmem.2)
      let f : Fin (totalStates D) := ⟨q, List.mem_range.mp hmem.1⟩
      refine Or.inr ⟨f, (trimmed_correct D f).mp hkeep.1, hkeep.2, ?_⟩
      rw [prefixWord_spec D f]
  · intro hg
    rcases hg with ⟨q, a, hq, hr, rfl⟩ | ⟨q, hq, hf, rfl⟩
    · apply List.mem_map.mpr
      refine ⟨edgeWord D flip q.val a, List.mem_append.mpr (Or.inl ?_), ?_⟩
      · apply List.mem_map.mpr
        refine ⟨(q.val, a), List.mem_filter.mpr ⟨List.mem_product.mpr
          ⟨List.mem_range.mpr q.isLt, List.mem_range.mpr (useful_edge_alphabet D q a hr)⟩, ?_⟩, rfl⟩
        have hq' := (trimmed_correct D q).mpr hq
        have hr' := (trimmed_correct D ((machine D).step q a)).mpr hr
        change trimmed D (step D q.val a) = true at hr'
        simp only [edgeKeep, hq', hr', Bool.and_self, decide_true]
      · rw [edgeWord_spec, WordAutomaton.edgeWord_value _ _ _ _ hflip]
    · apply List.mem_map.mpr
      refine ⟨prefixWord D q.val, List.mem_append.mpr (Or.inr ?_), ?_⟩
      · apply List.mem_map.mpr
        refine ⟨q.val, List.mem_filter.mpr ⟨List.mem_range.mpr q.isLt, ?_⟩, rfl⟩
        have hq' := (trimmed_correct D q).mpr hq
        simp only [finalKeep, hq', show acceptState D q.val = true from hf,
          Bool.and_self, decide_true]
      · rw [prefixWord_spec]

theorem generatorWords_generate {G : Type} [Group G] (D : Code) (flip : Nat → Nat)
    (letter : Nat → G) (hflip : ∀ a, letter (flip a) = (letter a)⁻¹)
    (H : Subgroup G)
    (accepted_mem : ∀ w, (machine D).Accepts w → wordValue letter w ∈ H)
    (represented : ∀ h ∈ H, ∃ w, (machine D).Accepts w ∧ wordValue letter w = h) :
    Subgroup.closure {g | g ∈ (generatorWords D flip).map (wordValue letter)} = H := by
  rw [generatorWords_values D flip letter hflip]
  exact (machine D).generates_subgroup (trimPaths D) letter H accepted_mem represented

end DCPv7.EncodedAutomaton
