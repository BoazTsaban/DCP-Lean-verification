import DCPv7.ProductDecision

/-! Re-expression of selected coordinate factors in the original supplied
product generators. The search checks both selected tuples separately, using
the increasing-total-length enumeration of signed supplied-generator words.
-/
namespace DCPv7.ProductEncoding
open SphericalAlgorithms
set_option backward.isDefEq.respectTransparency false

abbrev TargetInput := Input × List (Word × Word)

def TargetWordsValid (p : Input) (ts : List (Word × Word)) : Prop :=
  ∀ i : Fin p.1.length,
    FactorWordValid p.1[i] (ts.getD i.val ([], [])).1 ∧
      FactorWordValid p.1[i] (ts.getD i.val ([], [])).2

def TargetRealizes (p : Input) (ts : List (Word × Word)) (w : Candidate) : Prop :=
  CandidateValid p w ∧ ∀ i : Fin p.1.length,
    factorValue p.1[i] (project i.val (productSubstitute p.2.1 w.1)) =
      factorValue p.1[i] (ts.getD i.val ([], [])).1 ∧
    factorValue p.1[i] (project i.val (productSubstitute p.2.2.1 w.2)) =
      factorValue p.1[i] (ts.getD i.val ([], [])).2

def targetCoordinateCheck (wordTest : WordTestInput → Bool)
    (q : TargetInput × Candidate) (i : Nat) : Bool :=
  wordTest (q.1.1.1.getD i (0, 1),
    (project i (productSubstitute q.1.1.2.1 q.2.1), (q.1.2.getD i ([], [])).1)) &&
  wordTest (q.1.1.1.getD i (0, 1),
    (project i (productSubstitute q.1.1.2.2.1 q.2.2), (q.1.2.getD i ([], [])).2))

theorem targetCoordinateCheck_computable (wordTest : WordTestInput → Bool)
    (hd : Computable wordTest) : Computable₂ (targetCoordinateCheck wordTest) := by
  have hp : Primrec (fun q : (TargetInput × Candidate) × Nat => q.1.1.1) :=
    Primrec.fst.comp (Primrec.fst.comp Primrec.fst)
  have ht : Primrec (fun q : (TargetInput × Candidate) × Nat =>
      q.1.1.2.getD q.2 ([], [])) :=
    (Primrec.list_getD ([], [])).comp
      (Primrec.snd.comp (Primrec.fst.comp Primrec.fst)) Primrec.snd
  have hc : Primrec (fun q : (TargetInput × Candidate) × Nat =>
      q.1.1.1.1.getD q.2 (0, 1)) :=
    (Primrec.list_getD (0, 1)).comp (Primrec.fst.comp hp) Primrec.snd
  have hL : Primrec (fun q : (TargetInput × Candidate) × Nat =>
      project q.2 (productSubstitute q.1.1.1.2.1 q.1.2.1)) :=
    project_primrec.comp Primrec.snd
      (productSubstitute_primrec.comp (Primrec.fst.comp (Primrec.snd.comp hp))
        (Primrec.fst.comp (Primrec.snd.comp Primrec.fst)))
  have hR : Primrec (fun q : (TargetInput × Candidate) × Nat =>
      project q.2 (productSubstitute q.1.1.1.2.2.1 q.1.2.2)) :=
    project_primrec.comp Primrec.snd
      (productSubstitute_primrec.comp
        (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp hp)))
        (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)))
  exact Primrec.and.to_comp.comp
    (hd.comp (hc.pair (hL.pair (Primrec.fst.comp ht))).to_comp)
    (hd.comp (hc.pair (hR.pair (Primrec.snd.comp ht))).to_comp)

def targetCandidateTest (wordTest : WordTestInput → Bool)
    (p : TargetInput) (w : Candidate) : Bool :=
  if CandidateValid p.1 w then
    DCPVerification.allChecks (targetCoordinateCheck wordTest) (p, w) (List.range p.1.1.length)
  else false

theorem targetCandidateTest_computable (wordTest : WordTestInput → Bool)
    (hd : Computable wordTest) : Computable₂ (targetCandidateTest wordTest) := by
  have hv : PrimrecPred (fun q : TargetInput × Candidate => CandidateValid q.1.1 q.2) :=
    candidateValid_primrec.comp (Primrec.fst.comp Primrec.fst) Primrec.snd
  have ht := (DCPVerification.allChecks_computable _
    (targetCoordinateCheck_computable wordTest hd)).comp Computable.id
      (Primrec.list_range.comp
        (Primrec.list_length.comp (Primrec.fst.comp (Primrec.fst.comp Primrec.fst)))).to_comp
  exact (Computable.cond hv.decide.to_comp ht (Computable.const false)).of_eq
    (fun q => by simp only [Bool.cond_decide]; rfl)

noncomputable section

theorem factor_targetCoordinateCheck (alg : Algorithms) (p : Input) (hp : WordInputValid p)
    (ts : List (Word × Word)) (hts : TargetWordsValid p ts) (w : Candidate)
    (hw : CandidateValid p w) (i : Fin p.1.length) :
    targetCoordinateCheck (factorWordTest alg) ((p, ts), w) i.val = true ↔
      factorValue p.1[i] (project i.val (productSubstitute p.2.1 w.1)) =
        factorValue p.1[i] (ts.getD i.val ([], [])).1 ∧
      factorValue p.1[i] (project i.val (productSubstitute p.2.2.1 w.2)) =
        factorValue p.1[i] (ts.getD i.val ([], [])).2 := by
  have hc : ValidFactor p.1[i] := hp.1 _ (List.getElem_mem i.isLt)
  have hL := project_valid p.1 i.val (productSubstitute p.2.1 w.1)
    (productSubstitute_valid _ _ hp.2.1 _ hw.1)
  have hR := project_valid p.1 i.val (productSubstitute p.2.2.1 w.2)
    (productSubstitute_valid _ _ hp.2.2.1 _ hw.2)
  rw [List.getD_eq_getElem p.1 (0, 1) i.isLt] at hL hR
  simp only [targetCoordinateCheck, List.getD_eq_getElem p.1 (0, 1) i.isLt,
    Bool.and_eq_true, Fin.getElem_fin]
  exact and_congr
    (factorWordTest_correct alg _ hc _ _ hL (hts i).1)
    (factorWordTest_correct alg _ hc _ _ hR (hts i).2)

theorem targetCandidateTest_correct (alg : Algorithms) (p : Input) (hp : WordInputValid p)
    (ts : List (Word × Word)) (hts : TargetWordsValid p ts) (w : Candidate) :
    targetCandidateTest (factorWordTest alg) (p, ts) w = true ↔ TargetRealizes p ts w := by
  by_cases hw : CandidateValid p w
  · simp only [targetCandidateTest, hw, if_true, TargetRealizes, true_and,
      DCPVerification.allChecks_spec, List.mem_range]
    constructor
    · intro h i
      exact (factor_targetCoordinateCheck alg p hp ts hts w hw i).mp (h i.val i.isLt)
    · intro h i hi
      exact (factor_targetCoordinateCheck alg p hp ts hts w hw ⟨i, hi⟩).mpr (h ⟨i, hi⟩)
  · simp [targetCandidateTest, TargetRealizes, hw]

def targetSearch (alg : Algorithms) : TargetInput → Part Candidate :=
  SignedSearch.run (fun p => p.1.2.1.length) (fun p => p.1.2.2.1.length)
    (targetCandidateTest (factorWordTest alg))

theorem targetSearch_partrec (alg : Algorithms) : Partrec (targetSearch alg) :=
  SignedSearch.run_partrec _ _ _
    (Primrec.list_length.comp (Primrec.fst.comp (Primrec.snd.comp Primrec.fst))).to_comp
    (Primrec.list_length.comp
      (Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)))).to_comp
    (targetCandidateTest_computable (factorWordTest alg) (factorWordTest_computable alg))

theorem targetSearch_sound (alg : Algorithms) (p : Input) (hp : WordInputValid p)
    (ts : List (Word × Word)) (hts : TargetWordsValid p ts) (w : Candidate)
    (hw : w ∈ targetSearch alg (p, ts)) : TargetRealizes p ts w :=
  (targetCandidateTest_correct alg p hp ts hts w).mp
    (SignedSearch.run_sound _ _ _ (p, ts) w hw).2.2

theorem targetSearch_dom (alg : Algorithms) (p : Input) (hp : WordInputValid p)
    (ts : List (Word × Word)) (hts : TargetWordsValid p ts) :
    (targetSearch alg (p, ts)).Dom ↔ ∃ w, TargetRealizes p ts w := by
  rw [targetSearch, SignedSearch.run_dom]
  constructor
  · rintro ⟨w, _, _, ht⟩
    exact ⟨w, (targetCandidateTest_correct alg p hp ts hts w).mp ht⟩
  · rintro ⟨w, hw⟩
    exact ⟨w, hw.1.1, hw.1.2, (targetCandidateTest_correct alg p hp ts hts w).mpr hw⟩

def targetLeftTuple (p : Input) (ts : List (Word × Word)) : Tuple FactorGroup p.1 :=
  fun i => factorValue p.1[i] (ts.getD i.val ([], [])).1

def targetRightTuple (p : Input) (ts : List (Word × Word)) : Tuple FactorGroup p.1 :=
  fun i => factorValue p.1[i] (ts.getD i.val ([], [])).2

theorem targetRealizes_exists_of_mem (p : Input) (ts : List (Word × Word))
    (hL : targetLeftTuple p ts ∈
      wordSubgroup FactorGroup factorValue p.1 p.2.1)
    (hR : targetRightTuple p ts ∈
      wordSubgroup FactorGroup factorValue p.1 p.2.2.1) :
    ∃ w, TargetRealizes p ts w := by
  obtain ⟨u, hu, heu⟩ := subgroupWord_exists factorEvaluationLaws p.1 p.2.1 hL
  obtain ⟨v, hv, hev⟩ := subgroupWord_exists factorEvaluationLaws p.1 p.2.2.1 hR
  exact ⟨(u, v), ⟨hu, hv⟩, fun i => ⟨congrFun heu i, congrFun hev i⟩⟩

theorem targetSearch_dom_of_mem (alg : Algorithms) (p : Input) (hp : WordInputValid p)
    (ts : List (Word × Word)) (hts : TargetWordsValid p ts)
    (hL : targetLeftTuple p ts ∈
      wordSubgroup FactorGroup factorValue p.1 p.2.1)
    (hR : targetRightTuple p ts ∈
      wordSubgroup FactorGroup factorValue p.1 p.2.2.1) :
    (targetSearch alg (p, ts)).Dom :=
  (targetSearch_dom alg p hp ts hts).mpr (targetRealizes_exists_of_mem p ts hL hR)

end
end DCPv7.ProductEncoding
