import Mathlib.Computability.Partrec
import Mathlib.Computability.Primrec.List

/-! # A computable fair search for finite certificates -/
namespace DCPVerification.FairSearch
variable {P W : Type*} [Primcodable P] [Primcodable W]
variable (test : P → W → Bool)

def result (p : P) (w : W) : Option W := if test p w then some w else none
def step (p : P) (k : ℕ) : Option W :=
  (Encodable.decode (α := W) k).bind (result test p)
def run (p : P) : Part W := Nat.rfindOpt (step test p)

omit [Primcodable P] in
theorem step_spec (p : P) (k : ℕ) (w : W) :
    w ∈ step test p k ↔ Encodable.decode k = some w ∧ test p w = true := by
  cases h : Encodable.decode (α := W) k with
  | none => simp [step, h]
  | some v =>
    by_cases ht : test p v = true
    · have hstep : step test p k = some v := by
        simp only [step, h, Option.bind_some, result, ht, if_true]
      constructor
      · intro hw
        have he : v = w := by simpa only [hstep, Option.mem_some_iff] using hw
        subst w
        exact ⟨rfl, ht⟩
      · rintro ⟨he, _⟩
        have hvw := Option.some.inj he
        subst w
        simp only [hstep, Option.mem_some_iff]
    · have hstep : step test p k = none := by
        simp only [step, h, Option.bind_some, result, if_neg ht]
      constructor
      · intro hw
        simp only [hstep, Option.not_mem_none] at hw
      · rintro ⟨he, ht'⟩
        have hvw := Option.some.inj he
        subst w
        exact False.elim (ht ht')

theorem result_computable (hc : Computable₂ test) : Computable₂ (result test) := by
  exact (Computable.cond hc (Computable.option_some.comp Computable.snd)
    (Computable.const none)).of_eq (fun q => by unfold result; cases test q.1 q.2 <;> rfl)

theorem step_computable (hc : Computable₂ test) : Computable₂ (step test) :=
  Computable.option_bind (Computable.decode.comp Computable.snd)
    ((result_computable test hc).comp (Computable.fst.comp Computable.fst) Computable.snd).to₂

theorem run_partrec (hc : Computable₂ test) : Partrec (run test) :=
  Partrec.rfindOpt (step_computable test hc)

omit [Primcodable P] in
theorem run_sound (p : P) (w : W) (hw : w ∈ run test p) : test p w = true := by
  obtain ⟨k, hk⟩ := Nat.rfindOpt_spec hw
  exact ((step_spec test p k w).mp hk).2

omit [Primcodable P] in
theorem run_dom (p : P) : (run test p).Dom ↔ ∃ w, test p w = true := by
  constructor
  · intro h
    obtain ⟨w, hw⟩ := Part.dom_iff_mem.mp h
    exact ⟨w, run_sound test p w hw⟩
  · rintro ⟨w, hw⟩
    apply Nat.rfindOpt_dom.mpr
    exact ⟨Encodable.encode w, w, (step_spec test p _ w).mpr ⟨Encodable.encodek w, hw⟩⟩

end DCPVerification.FairSearch
