import DCPVerification.Search

/-! # Finite computable conjunctions, used by constrained witness searches -/
namespace DCPVerification
open BraidGroup

/-- Check the first `k` entries of a list. -/
def checksPrefix {α β : Type*} [Inhabited β] (check : α → β → Bool)
    (a : α) (l : List β) (k : ℕ) : Bool :=
  Nat.rec true (fun i acc => acc && check a (l.getD i default)) k

theorem checksPrefix_spec {α β : Type*} [Inhabited β] (check : α → β → Bool)
    (a : α) (l : List β) (k : ℕ) :
    checksPrefix check a l k = true ↔ ∀ i < k, check a (l.getD i default) = true := by
  induction k with
  | zero => simp [checksPrefix]
  | succ k ih =>
    simp only [checksPrefix, Bool.and_eq_true]
    rw [show Nat.rec true (fun i acc => acc && check a (l.getD i default)) k =
      checksPrefix check a l k from rfl, ih]
    exact ⟨fun h i hi => by
      obtain hi | rfl := Nat.lt_succ_iff_lt_or_eq.mp hi
      · exact h.1 i hi
      · exact h.2,
      fun h => ⟨fun i hi => h i (Nat.lt_succ_of_lt hi), h k (Nat.lt_succ_self k)⟩⟩

/-- Finite conjunction of computable tests. -/
def allChecks {α β : Type*} [Inhabited β] (check : α → β → Bool)
    (a : α) (l : List β) : Bool := checksPrefix check a l l.length

theorem allChecks_spec {α β : Type*} [Inhabited β] (check : α → β → Bool)
    (a : α) (l : List β) : allChecks check a l = true ↔ ∀ b ∈ l, check a b = true := by
  rw [allChecks, checksPrefix_spec]
  constructor
  · intro h b hb
    obtain ⟨i, hi, he⟩ := List.mem_iff_getElem.mp hb
    simpa only [List.getD_eq_getElem l default hi, he] using h i hi
  · intro h i hi
    rw [List.getD_eq_getElem l default hi]
    exact h _ (List.getElem_mem hi)

theorem allChecks_computable {α β : Type*} [Primcodable α] [Primcodable β] [Inhabited β]
    (check : α → β → Bool) (hc : Computable₂ check) : Computable₂ (allChecks check) := by
  have hstep : Computable₂ (fun q : α × List β => fun r : ℕ × Bool =>
      r.2 && check q.1 (q.2.getD r.1 default)) :=
    ((Primrec.dom_finite (fun b : Bool × Bool => b.1 && b.2)).to_comp.comp
      ((Computable.snd.comp Computable.snd).pair
        (hc.comp (Computable.fst.comp Computable.fst)
          ((Primrec.list_getD default).to_comp.comp (Computable.snd.comp Computable.fst)
            (Computable.fst.comp Computable.snd))))).to₂
  exact Computable.nat_rec (Computable.list_length.comp Computable.snd)
    (Computable.const true) hstep

end DCPVerification
