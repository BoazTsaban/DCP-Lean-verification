import DCPVerification.Spherical
import DCPVerification.FairSearch
import DCPVerification.Computability
import BraidGroup.ArtinWords

/-! # Uniform effective decision for the listed spherical enlargements -/
namespace DCPVerification.SphericalDecision
open BraidGroup GroupDCP FiniteArtinGroup
noncomputable section

abbrev Input := (Diagram × Diagram) × (List RawWord × (List RawWord × (RawWord × RawWord)))
def source (p : Input) : Diagram := p.1.1
def ambient (p : Input) : Diagram := p.1.2
def leftWords (p : Input) : List RawWord := p.2.1
def rightWords (p : Input) : List RawWord := p.2.2.1
def sourceWord (p : Input) : RawWord := p.2.2.2.1
def targetWord (p : Input) : RawWord := p.2.2.2.2

def ValidInput (p : Input) : Prop := AllowedEmbedding (source p) (ambient p) ∧
  Supported (source p) ∧ Supported (ambient p) ∧
  (∀ w ∈ leftWords p, RawValid ((source p).2 + 1) w) ∧
  (∀ w ∈ rightWords p, RawValid ((source p).2 + 1) w) ∧
  RawValid ((source p).2 + 1) (sourceWord p) ∧ RawValid ((source p).2 + 1) (targetWord p) ∧
  IsParabolic (FiniteArtinGroup.rawSubgroup (source p) (leftWords p)) ∧
  IsParabolic (FiniteArtinGroup.rawSubgroup (source p) (rightWords p))

def Positive (p : Input) : Prop := InDoubleCoset
  (FiniteArtinGroup.rawSubgroup (source p) (leftWords p))
  (FiniteArtinGroup.rawSubgroup (source p) (rightWords p))
  (FiniteArtinGroup.rawEval (source p) (sourceWord p))
  (FiniteArtinGroup.rawEval (source p) (targetWord p))

def centralizerWords : Diagram × List RawWord → List RawWord :=
  Classical.choose FiniteArtinGroup.Literature.centralizerAlgorithm_exists

theorem centralizerWords_computable : Computable centralizerWords :=
  (Classical.choose_spec FiniteArtinGroup.Literature.centralizerAlgorithm_exists).1

theorem centralizerWords_spec (X : Diagram) (hX : Supported X) (s : List RawWord)
    (hs : ∀ w ∈ s, RawValid (X.2 + 1) w) :
    (∀ w ∈ centralizerWords (X, s), RawValid (X.2 + 1) w) ∧
    Generates ((centralizerWords (X, s)).map (FiniteArtinGroup.rawEval X))
      (Subgroup.centralizer (FiniteArtinGroup.rawSubgroup X s : Set (OfDiagram X))) :=
  (Classical.choose_spec FiniteArtinGroup.Literature.centralizerAlgorithm_exists).2 X hX s hs

def simultaneousDecision : Diagram × RawInstance → Bool :=
  Classical.choose FiniteArtinGroup.Literature.simultaneousConjugacy_exists

theorem simultaneousDecision_computable : Computable simultaneousDecision :=
  (Classical.choose_spec FiniteArtinGroup.Literature.simultaneousConjugacy_exists).1

theorem simultaneousDecision_spec (X : Diagram) (hX : Supported X) (e : RawInstance)
    (he : InstanceValid X e) : simultaneousDecision (X, e) = true ↔ InstanceSolvable X e :=
  (Classical.choose_spec FiniteArtinGroup.Literature.simultaneousConjugacy_exists).2 X hX e he

def reductionInstance (p : Input) : RawInstance := rawAssembly
  ((centralizerWords (ambient p, leftWords p), centralizerWords (ambient p, rightWords p)),
    (sourceWord p, targetWord p))

def decision (p : Input) : Bool := simultaneousDecision (ambient p, reductionInstance p)

theorem rawSubgroup_map (X Y : Diagram) (h : AllowedEmbedding X Y) (s : List RawWord)
    (hs : ∀ w ∈ s, RawValid (X.2 + 1) w) :
    (FiniteArtinGroup.rawSubgroup X s).map (FiniteArtinGroup.Literature.embedding X Y h) = FiniteArtinGroup.rawSubgroup Y s := by
  unfold FiniteArtinGroup.rawSubgroup
  rw [MonoidHom.map_closure]
  congr 1
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    rcases List.mem_map.mp hx with ⟨w, hw, rfl⟩
    exact List.mem_map.mpr ⟨w, hw, (FiniteArtinGroup.Literature.embedding_word X Y h w (hs w hw)).symm⟩
  · intro hy
    rcases List.mem_map.mp hy with ⟨w, hw, rfl⟩
    exact ⟨FiniteArtinGroup.rawEval X w, List.mem_map.mpr ⟨w, hw, rfl⟩, FiniteArtinGroup.Literature.embedding_word X Y h w (hs w hw)⟩

theorem rawAssembly_solvable_iff (X : Diagram) (c d : List RawWord) (g h : RawWord) :
    InstanceSolvable X (rawAssembly ((c, d), (g, h))) ↔
      ∃ x, Solves (c.map (FiniteArtinGroup.rawEval X)) (d.map (FiniteArtinGroup.rawEval X)) (FiniteArtinGroup.rawEval X g) (FiniteArtinGroup.rawEval X h) x := by
  constructor
  · rintro ⟨x, hx⟩
    refine ⟨x, ?_, ?_⟩
    · intro u hu
      rcases List.mem_map.mp hu with ⟨w, hw, rfl⟩
      exact hx (w, w) (List.mem_append.mpr (Or.inl (List.mem_map.mpr ⟨w, hw, rfl⟩)))
    · intro v hv
      rcases List.mem_map.mp hv with ⟨w, hw, rfl⟩
      have he := hx (rawConjugate h w, rawConjugate g w)
        (List.mem_append.mpr (Or.inr (List.mem_map.mpr ⟨w, hw, rfl⟩)))
      simpa only [FiniteArtinGroup.rawEval_conjugate] using he
  · rintro ⟨x, hc, hd⟩
    refine ⟨x, ?_⟩
    intro p hp
    simp only [rawAssembly, List.mem_append, List.mem_map] at hp
    rcases hp with ⟨w, hw, rfl⟩ | ⟨w, hw, rfl⟩
    · exact hc _ (List.mem_map.mpr ⟨w, hw, rfl⟩)
    · simpa only [FiniteArtinGroup.rawEval_conjugate] using hd _ (List.mem_map.mpr ⟨w, hw, rfl⟩)

theorem rawAssembly_valid (n : ℕ) (c d : List RawWord) (g h : RawWord)
    (hc : ∀ w ∈ c, RawValid n w) (hd : ∀ w ∈ d, RawValid n w)
    (hg : RawValid n g) (hh : RawValid n h) :
    RawInstanceValid n (rawAssembly ((c, d), (g, h))) := by
  intro p hp
  simp only [rawAssembly, List.mem_append, List.mem_map] at hp
  rcases hp with ⟨u, hu, rfl⟩ | ⟨v, hv, rfl⟩
  · exact ⟨hc u hu, hc u hu⟩
  · simp only [rawConjugate, rawValid_append, rawValid_inverse]
    exact ⟨⟨⟨hh, hd v hv⟩, hh⟩, ⟨⟨hg, hd v hv⟩, hg⟩⟩

theorem ranks_le (X Y : Diagram) (h : AllowedEmbedding X Y) : X.2 ≤ Y.2 := by
  rcases h with h | h | h | h | h | h
  · omega
  · omega
  · rcases h with ⟨rfl, rfl⟩; decide
  · rcases h with ⟨rfl, rfl⟩; decide
  · rcases h with ⟨rfl, rfl⟩; decide
  · rcases h with ⟨rfl, rfl⟩; decide

theorem reduction_correct (p : Input) (hp : ValidInput p) :
    InstanceSolvable (ambient p) (reductionInstance p) ↔ Positive p := by
  rcases hp with ⟨hXY, _, hY, hAs, hBs, hg, hh, hA, hB⟩
  let X := source p
  let Y := ambient p
  let f := FiniteArtinGroup.Literature.embedding X Y hXY
  let A := FiniteArtinGroup.rawSubgroup X (leftWords p)
  let B := FiniteArtinGroup.rawSubgroup X (rightWords p)
  have hle : X.2 + 1 ≤ Y.2 + 1 := Nat.add_le_add_right (ranks_le X Y hXY) 1
  have hAm := rawSubgroup_map X Y hXY (leftWords p) hAs
  have hBm := rawSubgroup_map X Y hXY (rightWords p) hBs
  have hcs := centralizerWords_spec Y hY (leftWords p)
    (fun w hw => rawValid_mono hle (hAs w hw))
  have hds := centralizerWords_spec Y hY (rightWords p)
    (fun w hw => rawValid_mono hle (hBs w hw))
  have he := Spherical.reduction X Y hXY A B hA hB
    ((centralizerWords (Y, leftWords p)).map (FiniteArtinGroup.rawEval Y))
    ((centralizerWords (Y, rightWords p)).map (FiniteArtinGroup.rawEval Y))
    (by simpa only [A, hAm] using hcs.2)
    (by simpa only [B, hBm] using hds.2)
    (FiniteArtinGroup.rawEval X (sourceWord p)) (FiniteArtinGroup.rawEval X (targetWord p))
  rw [FiniteArtinGroup.Literature.embedding_word X Y hXY _ hg,
    FiniteArtinGroup.Literature.embedding_word X Y hXY _ hh] at he
  rw [reductionInstance, rawAssembly_solvable_iff]
  exact he

theorem reduction_valid (p : Input) (hp : ValidInput p) :
    InstanceValid (ambient p) (reductionInstance p) := by
  rcases hp with ⟨hXY, _, hY, hAs, hBs, hg, hh, _, _⟩
  have hle := Nat.add_le_add_right (ranks_le _ _ hXY) 1
  exact rawAssembly_valid ((ambient p).2 + 1) _ _ _ _
    (centralizerWords_spec _ hY _ (fun w hw => rawValid_mono hle (hAs w hw))).1
    (centralizerWords_spec _ hY _ (fun w hw => rawValid_mono hle (hBs w hw))).1
    (rawValid_mono hle hg) (rawValid_mono hle hh)

theorem decision_correct (p : Input) (hp : ValidInput p) : decision p = true ↔ Positive p :=
  (simultaneousDecision_spec _ hp.2.2.1 _ (reduction_valid p hp)).trans (reduction_correct p hp)
theorem source_primrec : Primrec source := Primrec.fst.comp Primrec.fst
theorem ambient_primrec : Primrec ambient := Primrec.snd.comp Primrec.fst
theorem leftWords_primrec : Primrec leftWords := Primrec.fst.comp Primrec.snd
theorem rightWords_primrec : Primrec rightWords := Primrec.fst.comp (Primrec.snd.comp Primrec.snd)
theorem sourceWord_primrec : Primrec sourceWord :=
  Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))
theorem targetWord_primrec : Primrec targetWord :=
  Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))

theorem reductionInstance_computable : Computable reductionInstance := by
  have hleft : Computable (fun p : Input => centralizerWords (ambient p, leftWords p)) :=
    centralizerWords_computable.comp (ambient_primrec.to_comp.pair leftWords_primrec.to_comp)
  have hright : Computable (fun p : Input => centralizerWords (ambient p, rightWords p)) :=
    centralizerWords_computable.comp (ambient_primrec.to_comp.pair rightWords_primrec.to_comp)
  exact rawAssembly_primrec.to_comp.comp
    ((hleft.pair hright).pair (sourceWord_primrec.to_comp.pair targetWord_primrec.to_comp))

theorem decision_computable : Computable decision :=
  simultaneousDecision_computable.comp (ambient_primrec.to_comp.pair reductionInstance_computable)

theorem main_decision : ∃ d : Input → Bool, Computable d ∧
    ∀ p, ValidInput p → (d p = true ↔ Positive p) :=
  ⟨decision, decision_computable, decision_correct⟩

end
end DCPVerification.SphericalDecision
