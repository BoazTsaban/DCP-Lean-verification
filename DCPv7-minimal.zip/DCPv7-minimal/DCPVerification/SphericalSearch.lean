import DCPVerification.SphericalDecision

/-! # Uniform spherical Artin witness search in the supplied generators -/
namespace DCPVerification.SphericalDecision
open BraidGroup GroupDCP FiniteArtinGroup
noncomputable section

abbrev Candidate := RawWord × RawWord

def wordDecision : Diagram × (RawWord × RawWord) → Bool :=
  Classical.choose FiniteArtinGroup.Literature.wordProblem_exists

theorem wordDecision_computable : Computable wordDecision :=
  (Classical.choose_spec FiniteArtinGroup.Literature.wordProblem_exists).1

theorem wordDecision_spec (X : Diagram) (hX : Supported X) (u v : RawWord)
    (hu : RawValid (X.2 + 1) u) (hv : RawValid (X.2 + 1) v) :
    wordDecision (X, (u, v)) = true ↔ FiniteArtinGroup.rawEval X u = FiniteArtinGroup.rawEval X v :=
  (Classical.choose_spec FiniteArtinGroup.Literature.wordProblem_exists).2 X hX u v hu hv

def CandidateValid (p : Input) (w : Candidate) : Prop :=
  SubgroupWordValid (leftWords p) w.1 ∧ SubgroupWordValid (rightWords p) w.2

def expandedCandidate (p : Input) (w : Candidate) : RawWord :=
  substitute (leftWords p) w.1 ++ sourceWord p ++ substitute (rightWords p) w.2

def Witness (p : Input) (w : Candidate) : Prop := CandidateValid p w ∧
  FiniteArtinGroup.rawEval (source p) (targetWord p) =
    FiniteArtinGroup.rawEval (source p) (substitute (leftWords p) w.1) * FiniteArtinGroup.rawEval (source p) (sourceWord p) *
      FiniteArtinGroup.rawEval (source p) (substitute (rightWords p) w.2)

instance candidateValid_decidable : DecidableRel CandidateValid := fun p w =>
  inferInstanceAs (Decidable ((∀ l ∈ w.1, l.1 < (leftWords p).length) ∧
    ∀ l ∈ w.2, l.1 < (rightWords p).length))

/-- Test a candidate using the ambient word problem, after checking its output alphabet. -/
def candidateTest (p : Input) (w : Candidate) : Bool :=
  if CandidateValid p w then wordDecision (source p, (targetWord p, expandedCandidate p w)) else false

theorem candidateTest_correct (p : Input) (hp : ValidInput p) (w : Candidate) :
    candidateTest p w = true ↔ Witness p w := by
  by_cases hv : CandidateValid p w
  · have hsA := hp.2.2.2.1
    have hsB := hp.2.2.2.2.1
    have hg := hp.2.2.2.2.2.1
    have hh := hp.2.2.2.2.2.2.1
    have hex : RawValid ((source p).2 + 1) (expandedCandidate p w) := by
      exact (rawValid_append _ _ _).mpr ⟨(rawValid_append _ _ _).mpr
        ⟨substitute_valid _ _ hsA _ hv.1, hg⟩, substitute_valid _ _ hsB _ hv.2⟩
    simp only [candidateTest, Witness, hv, if_true, true_and]
    rw [wordDecision_spec _ hp.2.1 _ _ hh hex]
    simp only [expandedCandidate, FiniteArtinGroup.rawEval_append, mul_assoc]
  · simp [candidateTest, Witness, hv]

theorem positive_iff_witness (p : Input) : Positive p ↔ ∃ w : Candidate, Witness p w := by
  constructor
  · rintro ⟨a, ha, b, hb, he⟩
    obtain ⟨u, hu, heu⟩ := FiniteArtinGroup.subgroupWord_exists _ _ ha
    obtain ⟨v, hv, hev⟩ := FiniteArtinGroup.subgroupWord_exists _ _ hb
    exact ⟨(u, v), ⟨hu, hv⟩, by simpa only [heu, hev] using he⟩
  · rintro ⟨⟨u, v⟩, ⟨hu, hv⟩, he⟩
    exact ⟨_, FiniteArtinGroup.substitute_mem _ _ u hu, _, FiniteArtinGroup.substitute_mem _ _ v hv, he⟩

/-- Checking the supplied-generator alphabet is primitive recursive. -/
theorem candidateValid_primrec : PrimrecRel CandidateValid :=
  (subgroupWordValid_primrec.comp (leftWords_primrec.comp Primrec.fst) (Primrec.fst.comp Primrec.snd)).and
    (subgroupWordValid_primrec.comp (rightWords_primrec.comp Primrec.fst) (Primrec.snd.comp Primrec.snd))

theorem expandedCandidate_primrec : Primrec₂ expandedCandidate :=
  Primrec.list_append.comp
    (Primrec.list_append.comp
      (substitute_primrec.comp (leftWords_primrec.comp Primrec.fst) (Primrec.fst.comp Primrec.snd))
      (sourceWord_primrec.comp Primrec.fst))
    (substitute_primrec.comp (rightWords_primrec.comp Primrec.fst) (Primrec.snd.comp Primrec.snd))

theorem candidateTest_computable : Computable₂ candidateTest := by
  have htest : Computable (fun q : Input × Candidate =>
      wordDecision (source q.1, (targetWord q.1, expandedCandidate q.1 q.2))) :=
    wordDecision_computable.comp ((source_primrec.comp Primrec.fst).to_comp.pair
      ((targetWord_primrec.comp Primrec.fst).to_comp.pair expandedCandidate_primrec.to_comp))
  exact (Computable.cond candidateValid_primrec.decide.to_comp htest (Computable.const false)).of_eq
    (fun q => by simp only [Bool.cond_decide]; rfl)

def search : Input → Part Candidate := FairSearch.run candidateTest

theorem search_partrec : Partrec search := FairSearch.run_partrec _ candidateTest_computable

theorem search_correct (p : Input) (hp : ValidInput p) : (search p).Dom ↔ Positive p := by
  rw [search, FairSearch.run_dom]
  exact (exists_congr fun w => candidateTest_correct p hp w).trans (positive_iff_witness p).symm

theorem search_sound (p : Input) (hp : ValidInput p) (w : Candidate) (hw : w ∈ search p) :
    Witness p w := (candidateTest_correct p hp w).mp (FairSearch.run_sound _ p w hw)

theorem main_theorem : ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, ValidInput p →
      (d p = true ↔ Positive p) ∧ (d p = true → (s p).Dom) ∧
      ∀ w ∈ s p, Witness p w := by
  exact ⟨decision, search, decision_computable, search_partrec, fun p hp =>
    ⟨decision_correct p hp, fun hd => (search_correct p hp).mpr ((decision_correct p hp).mp hd),
      search_sound p hp⟩⟩

end
end DCPVerification.SphericalDecision
