import BraidGroup.AddedStrand
import BraidGroup.SmallCases

/-! # DCPv3: uniform parabolic double-coset decision reduction -/
namespace DCPVerification
open BraidGroup GroupDCP

noncomputable section

/-- One encoding for all ranks and supplied subgroup generating lists. -/
abbrev Input := ℕ × (List RawWord × (List RawWord × (RawWord × RawWord)))

def rank (p : Input) : ℕ := p.1
def leftWords (p : Input) : List RawWord := p.2.1
def rightWords (p : Input) : List RawWord := p.2.2.1
def sourceWord (p : Input) : RawWord := p.2.2.2.1
def targetWord (p : Input) : RawWord := p.2.2.2.2

/-- The manuscript promises parabolic input subgroups; recognition is not required. -/
def ValidInput (p : Input) : Prop :=
  1 ≤ rank p ∧
  (∀ w ∈ leftWords p, RawValid (rank p) w) ∧
  (∀ w ∈ rightWords p, RawValid (rank p) w) ∧
  RawValid (rank p) (sourceWord p) ∧ RawValid (rank p) (targetWord p) ∧
  IsParabolic (rawSubgroup (rank p) (leftWords p)) ∧
  IsParabolic (rawSubgroup (rank p) (rightWords p))

def Positive (p : Input) : Prop := InDoubleCoset
  (rawSubgroup (rank p) (leftWords p)) (rawSubgroup (rank p) (rightWords p))
  (rawEval (rank p) (sourceWord p)) (rawEval (rank p) (targetWord p))

/-- A literature centralizer algorithm selected once for all ranks. -/
def centralizerWords : ℕ × List RawWord → List RawWord :=
  Classical.choose Literature.centralizerAlgorithm_exists

theorem centralizerWords_computable : Computable centralizerWords :=
  (Classical.choose_spec Literature.centralizerAlgorithm_exists).1

theorem centralizerWords_spec (n : ℕ) (hn : 1 ≤ n) (s : List RawWord)
    (hs : ∀ w ∈ s, RawValid n w) :
    (∀ w ∈ centralizerWords (n, s), RawValid n w) ∧
    Generates ((centralizerWords (n, s)).map (rawEval n))
      (Subgroup.centralizer (rawSubgroup n s : Set (BraidGroup n))) :=
  (Classical.choose_spec Literature.centralizerAlgorithm_exists).2 n hn s hs

/-- A literature simultaneous-conjugacy decision algorithm selected uniformly. -/
def simultaneousDecision : ℕ × RawInstance → Bool :=
  Classical.choose Literature.simultaneousConjugacy_exists

theorem simultaneousDecision_computable : Computable simultaneousDecision :=
  (Classical.choose_spec Literature.simultaneousConjugacy_exists).1

theorem simultaneousDecision_spec (n : ℕ) (hn : 1 ≤ n) (e : RawInstance)
    (he : RawInstanceValid n e) :
    simultaneousDecision (n, e) = true ↔ RawInstanceSolvable n e :=
  (Classical.choose_spec Literature.simultaneousConjugacy_exists).2 n hn e he

/-- The two centralizers are computed in `B_(n+1)`, not in `B_n`. -/
def reductionInstance (p : Input) : RawInstance :=
  rawAssembly ((centralizerWords (rank p + 1, leftWords p),
    centralizerWords (rank p + 1, rightWords p)), (sourceWord p, targetWord p))

/-- Membership of an element represented by a supplied generator word. -/
theorem rawSubgroup_map {n m : ℕ} (h : n ≤ m) (s : List RawWord)
    (hs : ∀ w ∈ s, RawValid n w) :
    (rawSubgroup n s).map (inclusion h) = rawSubgroup m s := by
  unfold rawSubgroup
  rw [MonoidHom.map_closure]
  congr 1
  ext y
  constructor
  · rintro ⟨x, hx, rfl⟩
    rcases List.mem_map.mp hx with ⟨w, hw, rfl⟩
    exact List.mem_map.mpr ⟨w, hw, (inclusion_rawEval h w (hs w hw)).symm⟩
  · intro hy
    rcases List.mem_map.mp hy with ⟨w, hw, rfl⟩
    exact ⟨rawEval n w, List.mem_map.mpr ⟨w, hw, rfl⟩, inclusion_rawEval h w (hs w hw)⟩

/-- Word assembly expresses exactly the two conjugacy families in the manuscript. -/
theorem rawAssembly_solvable_iff (n : ℕ) (c d : List RawWord) (g h : RawWord) :
    RawInstanceSolvable n (rawAssembly ((c, d), (g, h))) ↔
      ∃ x, Solves (c.map (rawEval n)) (d.map (rawEval n)) (rawEval n g) (rawEval n h) x := by
  constructor
  · rintro ⟨x, hx⟩
    refine ⟨x, ?_, ?_⟩
    · intro u hu
      rcases List.mem_map.mp hu with ⟨w, hw, rfl⟩
      exact hx (w, w) (List.mem_append.mpr (Or.inl (List.mem_map.mpr ⟨w, hw, rfl⟩)))
    · intro v hv
      rcases List.mem_map.mp hv with ⟨w, hw, rfl⟩
      have he := hx (rawConjugate h w, rawConjugate g w)
        (List.mem_append.mpr (Or.inr (List.mem_map.mpr ⟨w, hw, rfl⟩)))
      simpa only [rawEval_conjugate] using he
  · rintro ⟨x, hc, hd⟩
    refine ⟨x, ?_⟩
    intro p hp
    simp only [rawAssembly, List.mem_append, List.mem_map] at hp
    rcases hp with ⟨w, hw, rfl⟩ | ⟨w, hw, rfl⟩
    · exact hc _ (List.mem_map.mpr ⟨w, hw, rfl⟩)
    · simpa only [rawEval_conjugate] using hd _ (List.mem_map.mpr ⟨w, hw, rfl⟩)

theorem rawAssembly_valid (n : ℕ) (c d : List RawWord) (g h : RawWord)
    (hc : ∀ w ∈ c, RawValid n w) (hd : ∀ w ∈ d, RawValid n w)
    (hg : RawValid n g) (hh : RawValid n h) :
    RawInstanceValid n (rawAssembly ((c, d), (g, h))) := by
  intro p hp
  simp only [rawAssembly, List.mem_append, List.mem_map] at hp
  rcases hp with ⟨u, hu, rfl⟩ | ⟨v, hv, rfl⟩
  · exact ⟨hc u hu, hc u hu⟩
  · simp only [rawConjugate, rawValid_append, rawValid_inverse]
    exact ⟨⟨⟨hh, hd v hv⟩, hh⟩, ⟨⟨hg, hd v hv⟩, hg⟩⟩

/-- Main Theorem's single-instance reduction at every rank at least two. -/
theorem reduction_correct (p : Input) (hp : ValidInput p) (hn : 2 ≤ rank p) :
    RawInstanceSolvable (rank p + 1) (reductionInstance p) ↔ Positive p := by
  rcases hp with ⟨_, hAs, hBs, hg, hh, hA, hB⟩
  let n := rank p
  let f := inclusion (Nat.le_succ n)
  let A := rawSubgroup n (leftWords p)
  let B := rawSubgroup n (rightWords p)
  have hAm := rawSubgroup_map (Nat.le_succ n) (leftWords p) hAs
  have hBm := rawSubgroup_map (Nat.le_succ n) (rightWords p) hBs
  have hAmP := inclusion_isParabolic (Nat.le_succ n) A hA
  have hBmP := inclusion_isParabolic (Nat.le_succ n) B hB
  have hcs := centralizerWords_spec (n + 1) (by omega) (leftWords p)
    (fun w hw => rawValid_mono (Nat.le_succ n) (hAs w hw))
  have hds := centralizerWords_spec (n + 1) (by omega) (rightWords p)
    (fun w hw => rawValid_mono (Nat.le_succ n) (hBs w hw))
  have hcentral := addedStrand_center_intersection n hn
  have hAR : A.map f ≤ f.range := Subgroup.map_le_range f A
  have hBR : B.map f ≤ f.range := Subgroup.map_le_range f B
  have he := ambient_reduction (A.map f) (B.map f) f.range hAR hBR
    ((centralizerWords (n + 1, leftWords p)).map (rawEval (n + 1)))
    ((centralizerWords (n + 1, rightWords p)).map (rawEval (n + 1)))
    (by simpa only [A, f, hAm] using hcs.2)
    (by simpa only [B, f, hBm] using hds.2)
    (parabolic_hasDoubleCentralizer _ (by omega) _ hAmP)
    (parabolic_hasDoubleCentralizer _ (by omega) _ hBmP)
    hcentral (f (rawEval n (sourceWord p))) (f (rawEval n (targetWord p)))
    ⟨_, rfl⟩ ⟨_, rfl⟩
  rw [inclusion_rawEval (Nat.le_succ n) _ hg, inclusion_rawEval (Nat.le_succ n) _ hh] at he
  rw [reductionInstance, rawAssembly_solvable_iff]
  exact he.trans (by
    rw [← inclusion_rawEval (Nat.le_succ n) _ hg, ← inclusion_rawEval (Nat.le_succ n) _ hh]
    exact map_doubleCoset_iff f (Literature.standardEmbedding_injective _) A B _ _)

/-- Validity of the constructed simultaneous conjugacy instance. -/
theorem reduction_valid (p : Input) (hp : ValidInput p) :
    RawInstanceValid (rank p + 1) (reductionInstance p) := by
  rcases hp with ⟨_, hAs, hBs, hg, hh, _, _⟩
  exact rawAssembly_valid _ _ _ _ _
    (centralizerWords_spec _ (by omega) _ (fun w hw => rawValid_mono (Nat.le_succ _) (hAs w hw))).1
    (centralizerWords_spec _ (by omega) _ (fun w hw => rawValid_mono (Nat.le_succ _) (hBs w hw))).1
    (rawValid_mono (Nat.le_succ _) hg) (rawValid_mono (Nat.le_succ _) hh)

/-- The decision algorithm; rank one is handled directly by triviality. -/
def decision (p : Input) : Bool :=
  if rank p ≤ 1 then true else simultaneousDecision (rank p + 1, reductionInstance p)

theorem decision_correct (p : Input) (hp : ValidInput p) : decision p = true ↔ Positive p := by
  by_cases hn : rank p ≤ 1
  · simp only [decision, if_pos hn, true_iff]
    exact ⟨1, (rawSubgroup _ _).one_mem, 1, (rawSubgroup _ _).one_mem, by
      have hg1 := BraidGroup.eq_one_of_le_one hn (rawEval (rank p) (sourceWord p))
      have hh1 := BraidGroup.eq_one_of_le_one hn (rawEval (rank p) (targetWord p))
      simp only [hg1, hh1, mul_one]⟩
  · simp only [decision, if_neg hn]
    exact (simultaneousDecision_spec _ (by omega) _ (reduction_valid p hp)).trans
      (reduction_correct p hp (by omega))

end
end DCPVerification
