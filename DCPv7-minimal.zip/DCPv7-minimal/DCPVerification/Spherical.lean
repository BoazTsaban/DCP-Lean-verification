import BraidGroup.SphericalLiterature
import BraidGroup.DoubleCosetConstraints

/-! # Algebraic verification of the listed spherical Artin extensions -/
namespace DCPVerification.Spherical
open FiniteArtinGroup GroupDCP

/-- Convert the literature's equality into the precise factor form of the criterion. -/
theorem hasDoubleCentralizer (X Y : Diagram) (h : AllowedEmbedding X Y)
    (A : Subgroup (OfDiagram Y)) (hA : IsParabolic A) : HasDoubleCentralizer A := by
  intro x
  rw [Literature.doubleCentralizer X Y h A hA, Subgroup.mem_sup_of_normal_left]
  exact exists_congr fun z => and_congr_right fun _ =>
    exists_congr fun a => and_congr_right fun _ => eq_comm

/-- The manuscript derives this intersection from the internal direct product. -/
theorem center_intersection (X Y : Diagram) (h : AllowedEmbedding X Y) :
    Subgroup.center (OfDiagram Y) ⊓ (Literature.embedding X Y h).range = ⊥ := by
  obtain ⟨I, hI, he⟩ := (Literature.embedding_parabolic X Y h).1
  rw [he]
  exact Literature.directProduct_intersection X Y h I hI

/-- Each listed enlargement satisfies the full ambient reduction criterion. -/
theorem reduction (X Y : Diagram) (hXY : AllowedEmbedding X Y)
    (A B : Subgroup (OfDiagram X)) (hA : IsParabolic A) (hB : IsParabolic B)
    (c d : List (OfDiagram Y))
    (hc : Generates c (Subgroup.centralizer (A.map (Literature.embedding X Y hXY) : Set _)))
    (hd : Generates d (Subgroup.centralizer (B.map (Literature.embedding X Y hXY) : Set _)))
    (g h : OfDiagram X) :
    (∃ x, Solves c d (Literature.embedding X Y hXY g) (Literature.embedding X Y hXY h) x) ↔
      InDoubleCoset A B g h := by
  let f := Literature.embedding X Y hXY
  exact (ambient_reduction (A.map f) (B.map f) f.range
    (Subgroup.map_le_range f A) (Subgroup.map_le_range f B) c d hc hd
    (hasDoubleCentralizer X Y hXY _ ((Literature.embedding_parabolic X Y hXY).2 A hA))
    (hasDoubleCentralizer X Y hXY _ ((Literature.embedding_parabolic X Y hXY).2 B hB))
    (center_intersection X Y hXY) (f g) (f h) ⟨g, rfl⟩ ⟨h, rfl⟩).trans
      (map_doubleCoset_iff f (Literature.embedding_injective X Y hXY) A B g h)

/-- The rank choices in the type D paragraph give a larger even ambient rank. -/
def evenAmbient (r : ℕ) : ℕ := if Even r then r + 2 else r + 1

theorem typeB_allowed (r : ℕ) (hr : 2 ≤ r) : AllowedEmbedding (0, r) (0, r + 1) :=
  Or.inl ⟨rfl, rfl, hr, rfl⟩

theorem typeD_allowed (r N : ℕ) (hr : 4 ≤ r) (hN : r < N) (he : Even N) :
    AllowedEmbedding (1, r) (1, N) := Or.inr (Or.inl ⟨rfl, rfl, hr, hN, he⟩)

theorem typeE6_allowed : AllowedEmbedding (2, 6) (2, 7) := by
  exact Or.inr (Or.inr (Or.inl ⟨rfl, rfl⟩))
theorem typeE7_allowed : AllowedEmbedding (2, 7) (2, 8) := by
  exact Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl, rfl⟩)))
theorem typeH3_allowed : AllowedEmbedding (3, 3) (3, 4) := by
  exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨rfl, rfl⟩))))
theorem typeI25_allowed : AllowedEmbedding (3, 2) (3, 3) := by
  exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨rfl, rfl⟩))))

end DCPVerification.Spherical

namespace DCPVerification.Spherical
open FiniteArtinGroup

theorem allowed_supported (X Y : Diagram) (h : AllowedEmbedding X Y) : Supported X ∧ Supported Y := by
  rcases h with h | h | h | h | h | h
  · exact ⟨Or.inl ⟨h.1, h.2.2.1⟩, Or.inl ⟨h.2.1, by omega⟩⟩
  · exact ⟨Or.inr (Or.inl ⟨h.1, h.2.2.1⟩), Or.inr (Or.inl ⟨h.2.1, by omega⟩)⟩
  · rcases h with ⟨rfl, rfl⟩; unfold Supported; decide
  · rcases h with ⟨rfl, rfl⟩; unfold Supported; decide
  · rcases h with ⟨rfl, rfl⟩; unfold Supported; decide
  · rcases h with ⟨rfl, rfl⟩; unfold Supported; decide

end DCPVerification.Spherical
