import DCPVerification.Computability
import BraidGroup.SubgroupWords

/-! # Witness search in the supplied subgroup generators -/
namespace DCPVerification
open BraidGroup GroupDCP
noncomputable section

abbrev Candidate := RawWord × RawWord

def wordDecision : ℕ × (RawWord × RawWord) → Bool :=
  Classical.choose Literature.wordProblem_exists

theorem wordDecision_computable : Computable wordDecision :=
  (Classical.choose_spec Literature.wordProblem_exists).1

theorem wordDecision_spec (n : ℕ) (hn : 1 ≤ n) (u v : RawWord)
    (hu : RawValid n u) (hv : RawValid n v) :
    wordDecision (n, (u, v)) = true ↔ rawEval n u = rawEval n v :=
  (Classical.choose_spec Literature.wordProblem_exists).2 n hn u v hu hv

def CandidateValid (p : Input) (w : Candidate) : Prop :=
  SubgroupWordValid (leftWords p) w.1 ∧ SubgroupWordValid (rightWords p) w.2

def expandedCandidate (p : Input) (w : Candidate) : RawWord :=
  substitute (leftWords p) w.1 ++ sourceWord p ++ substitute (rightWords p) w.2

def Witness (p : Input) (w : Candidate) : Prop := CandidateValid p w ∧
  rawEval (rank p) (targetWord p) =
    rawEval (rank p) (substitute (leftWords p) w.1) * rawEval (rank p) (sourceWord p) *
      rawEval (rank p) (substitute (rightWords p) w.2)

instance candidateValid_decidable : DecidableRel CandidateValid := fun p w =>
  inferInstanceAs (Decidable ((∀ l ∈ w.1, l.1 < (leftWords p).length) ∧
    ∀ l ∈ w.2, l.1 < (rightWords p).length))

/-- Test a candidate using the ambient word problem, after checking its output alphabet. -/
def candidateTest (p : Input) (w : Candidate) : Bool :=
  if CandidateValid p w then wordDecision (rank p, (targetWord p, expandedCandidate p w)) else false

theorem candidateTest_correct (p : Input) (hp : ValidInput p) (w : Candidate) :
    candidateTest p w = true ↔ Witness p w := by
  by_cases hv : CandidateValid p w
  · have hsA := hp.2.1
    have hsB := hp.2.2.1
    have hg := hp.2.2.2.1
    have hh := hp.2.2.2.2.1
    have hex : RawValid (rank p) (expandedCandidate p w) := by
      exact (rawValid_append _ _ _).mpr ⟨(rawValid_append _ _ _).mpr
        ⟨substitute_valid _ _ hsA _ hv.1, hg⟩, substitute_valid _ _ hsB _ hv.2⟩
    simp only [candidateTest, Witness, hv, if_true, true_and]
    rw [wordDecision_spec _ hp.1 _ _ hh hex]
    simp only [expandedCandidate, rawEval_append, mul_assoc]
  · simp [candidateTest, Witness, hv]

theorem positive_iff_witness (p : Input) : Positive p ↔ ∃ w : Candidate, Witness p w := by
  constructor
  · rintro ⟨a, ha, b, hb, he⟩
    obtain ⟨u, hu, heu⟩ := subgroupWord_exists _ _ ha
    obtain ⟨v, hv, hev⟩ := subgroupWord_exists _ _ hb
    exact ⟨(u, v), ⟨hu, hv⟩, by simpa only [heu, hev] using he⟩
  · rintro ⟨⟨u, v⟩, ⟨hu, hv⟩, he⟩
    exact ⟨_, substitute_mem _ _ u hu, _, substitute_mem _ _ v hv, he⟩

/-- Checking the supplied-generator alphabet is primitive recursive. -/
theorem candidateValid_primrec : PrimrecRel CandidateValid :=
  (subgroupWordValid_primrec.comp (leftWords_primrec.comp Primrec.fst) (Primrec.fst.comp Primrec.snd)).and
    (subgroupWordValid_primrec.comp (rightWords_primrec.comp Primrec.fst) (Primrec.snd.comp Primrec.snd))

theorem expandedCandidate_primrec : Primrec₂ expandedCandidate :=
  Primrec.list_append.comp
    (Primrec.list_append.comp
      (substitute_primrec.comp (leftWords_primrec.comp Primrec.fst) (Primrec.fst.comp Primrec.snd))
      (sourceWord_primrec.comp Primrec.fst))
    (substitute_primrec.comp (rightWords_primrec.comp Primrec.fst) (Primrec.snd.comp Primrec.snd))

theorem candidateTest_computable : Computable₂ candidateTest := by
  have htest : Computable (fun q : Input × Candidate =>
      wordDecision (rank q.1, (targetWord q.1, expandedCandidate q.1 q.2))) :=
    wordDecision_computable.comp ((rank_primrec.comp Primrec.fst).to_comp.pair
      ((targetWord_primrec.comp Primrec.fst).to_comp.pair expandedCandidate_primrec.to_comp))
  exact (Computable.cond candidateValid_primrec.decide.to_comp htest (Computable.const false)).of_eq
    (fun q => by simp only [Bool.cond_decide]; rfl)

def candidateResult (p : Input) (w : Candidate) : Option Candidate :=
  if candidateTest p w then some w else none

theorem candidateResult_computable : Computable₂ candidateResult := by
  exact (Computable.cond candidateTest_computable (Computable.option_some.comp Computable.snd)
    (Computable.const none)).of_eq (fun q => by unfold candidateResult; cases candidateTest q.1 q.2 <;> rfl)

/-- Fair enumeration through the standard primitive-recursive decoding of pairs of finite words. -/
def searchStep (p : Input) (k : ℕ) : Option Candidate :=
  (Encodable.decode (α := Candidate) k).bind (candidateResult p)

theorem searchStep_computable : Computable₂ searchStep :=
  Computable.option_bind (Computable.decode.comp Computable.snd)
    (candidateResult_computable.comp (Computable.fst.comp Computable.fst) Computable.snd).to₂

/-- Search for the first encoded pair passing the word-problem test. -/
def search (p : Input) : Part Candidate := Nat.rfindOpt (searchStep p)

theorem search_partrec : Partrec search := Partrec.rfindOpt searchStep_computable

theorem searchStep_spec (p : Input) (k : ℕ) (w : Candidate) :
    w ∈ searchStep p k ↔ Encodable.decode k = some w ∧ candidateTest p w = true := by
  cases h : Encodable.decode (α := Candidate) k with
  | none => simp [searchStep, h]
  | some v =>
    by_cases ht : candidateTest p v = true
    · have hstep : searchStep p k = some v := by
        simp only [searchStep, h, Option.bind_some, candidateResult, ht, if_true]
      constructor
      · intro hw
        have he : v = w := by simpa only [hstep, Option.mem_some_iff] using hw
        subst w
        exact ⟨rfl, ht⟩
      · rintro ⟨he, _⟩
        have hvw := Option.some.inj he
        subst w
        simp only [hstep, Option.mem_some_iff]
    · have hstep : searchStep p k = none := by
        simp only [searchStep, h, Option.bind_some, candidateResult, if_neg ht]
      constructor
      · intro hw
        simp only [hstep, Option.not_mem_none] at hw
      · rintro ⟨he, ht'⟩
        have hvw := Option.some.inj he
        subst w
        exact False.elim (ht ht')

theorem search_sound (p : Input) (hp : ValidInput p) (w : Candidate) (hw : w ∈ search p) :
    Witness p w := by
  obtain ⟨k, hk⟩ := Nat.rfindOpt_spec hw
  exact (candidateTest_correct p hp w).mp ((searchStep_spec p k w).mp hk).2

/-- The positive decision guarantees termination, with no subgroup membership oracle. -/
theorem search_terminates_iff (p : Input) (hp : ValidInput p) : (search p).Dom ↔ Positive p := by
  constructor
  · intro h
    obtain ⟨w, hw⟩ := Part.dom_iff_mem.mp h
    exact (positive_iff_witness p).mpr ⟨w, search_sound p hp w hw⟩
  · intro h
    obtain ⟨w, hw⟩ := (positive_iff_witness p).mp h
    apply Nat.rfindOpt_dom.mpr
    refine ⟨Encodable.encode w, w, (searchStep_spec p _ w).mpr ?_⟩
    exact ⟨Encodable.encodek w, (candidateTest_correct p hp w).mpr hw⟩

/-- The positive-instance search part of the main theorem, in the supplied alphabet. -/
theorem main_search : ∃ f : Input → Part Candidate, Partrec f ∧
    ∀ p, ValidInput p → ((f p).Dom ↔ Positive p) ∧
      ∀ w ∈ f p, Witness p w :=
  ⟨search, search_partrec, fun p hp => ⟨search_terminates_iff p hp, search_sound p hp⟩⟩

/-- DCPv3 Main Theorem: a uniform decision and a terminating, sound positive-instance search. -/
theorem main_theorem : ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, ValidInput p →
      (d p = true ↔ Positive p) ∧ (d p = true → (s p).Dom) ∧
        ∀ w ∈ s p, Witness p w := by
  refine ⟨decision, search, decision_computable, search_partrec, ?_⟩
  intro p hp
  exact ⟨decision_correct p hp, fun h => (search_terminates_iff p hp).mpr
    ((decision_correct p hp).mp h), search_sound p hp⟩

end
end DCPVerification
