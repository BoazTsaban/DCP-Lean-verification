import DCPVerification.Main

/-! # Computability of the uniform double-coset reduction -/
namespace DCPVerification
open BraidGroup
noncomputable section

theorem rank_primrec : Primrec rank := Primrec.fst
theorem leftWords_primrec : Primrec leftWords := Primrec.fst.comp Primrec.snd
theorem rightWords_primrec : Primrec rightWords := Primrec.fst.comp (Primrec.snd.comp Primrec.snd)
theorem sourceWord_primrec : Primrec sourceWord :=
  Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))
theorem targetWord_primrec : Primrec targetWord :=
  Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))

theorem ambientRank_primrec : Primrec (fun p : Input => rank p + 1) :=
  Primrec.nat_add.comp rank_primrec (Primrec.const 1)

/-- The two centralizer computations and word assembly form a uniform computable map. -/
theorem reductionInstance_computable : Computable reductionInstance := by
  have hleft : Computable (fun p : Input => centralizerWords (rank p + 1, leftWords p)) :=
    centralizerWords_computable.comp (ambientRank_primrec.to_comp.pair leftWords_primrec.to_comp)
  have hright : Computable (fun p : Input => centralizerWords (rank p + 1, rightWords p)) :=
    centralizerWords_computable.comp (ambientRank_primrec.to_comp.pair rightWords_primrec.to_comp)
  exact rawAssembly_primrec.to_comp.comp
    ((hleft.pair hright).pair (sourceWord_primrec.to_comp.pair targetWord_primrec.to_comp))

/-- A single partial-recursive code decides every promised parabolic input across all ranks. -/
theorem decision_computable : Computable decision := by
  have hsmall : PrimrecPred (fun p : Input => rank p ≤ 1) :=
    Primrec.nat_le.comp rank_primrec (Primrec.const 1)
  have hlarge : Computable (fun p : Input => simultaneousDecision (rank p + 1, reductionInstance p)) :=
    simultaneousDecision_computable.comp (ambientRank_primrec.to_comp.pair reductionInstance_computable)
  exact (Computable.cond hsmall.decide.to_comp (Computable.const true) hlarge).of_eq
    (fun p => by simp only [Bool.cond_decide]; rfl)

/-- The decision part of DCPv3 Main Theorem, with explicit uniform computability. -/
theorem main_decision : ∃ f : Input → Bool, Computable f ∧
    ∀ p, ValidInput p → (f p = true ↔ Positive p) :=
  ⟨decision, decision_computable, decision_correct⟩

end
end DCPVerification
