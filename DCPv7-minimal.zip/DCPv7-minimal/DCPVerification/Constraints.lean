import DCPVerification.FiniteChecks
import DCPVerification.FairSearch
import BraidGroup.DoubleCosetConstraints

/-! # Computable augmentation and constrained witness search -/
namespace DCPVerification.Constraints
open BraidGroup GroupDCP
noncomputable section

abbrev Input := DCPVerification.Input × (List RawWord × List RawWord)
def base (p : Input) : DCPVerification.Input := p.1
def leftConstraints (p : Input) : List RawWord := p.2.1
def rightConstraints (p : Input) : List RawWord := p.2.2

def ValidInput (p : Input) : Prop := DCPVerification.ValidInput p.1 ∧
  (∀ w ∈ p.2.1, RawValid (rank p.1) w) ∧ ∀ w ∈ p.2.2, RawValid (rank p.1) w

def Positive (p : Input) : Prop := ConstrainedDoubleCoset
  (rawSubgroup (rank p.1) (leftWords p.1)) (rawSubgroup (rank p.1) (rightWords p.1))
  {z | z ∈ p.2.1.map (rawEval (rank p.1))} {z | z ∈ p.2.2.map (rawEval (rank p.1))}
  (rawEval (rank p.1) (sourceWord p.1)) (rawEval (rank p.1) (targetWord p.1))

/-- Append the prescribed commuting words to the original centralizer lists. -/
def reductionInstance (p : Input) : RawInstance := rawAssembly
  ((centralizerWords (rank p.1 + 1, leftWords p.1) ++ p.2.1,
    centralizerWords (rank p.1 + 1, rightWords p.1) ++ p.2.2),
    (sourceWord p.1, targetWord p.1))

theorem reductionInstance_computable : Computable reductionInstance := by
  have hl : Computable (fun p : Input => centralizerWords (rank p.1 + 1, leftWords p.1)) := centralizerWords_computable.comp
    ((ambientRank_primrec.comp Primrec.fst).to_comp.pair (leftWords_primrec.comp Primrec.fst).to_comp)
  have hr : Computable (fun p : Input => centralizerWords (rank p.1 + 1, rightWords p.1)) := centralizerWords_computable.comp
    ((ambientRank_primrec.comp Primrec.fst).to_comp.pair (rightWords_primrec.comp Primrec.fst).to_comp)
  exact rawAssembly_primrec.to_comp.comp
    (((Primrec.list_append.to_comp.comp hl (Primrec.fst.comp Primrec.snd).to_comp).pair
      (Primrec.list_append.to_comp.comp hr (Primrec.snd.comp Primrec.snd).to_comp)).pair
      ((sourceWord_primrec.comp Primrec.fst).to_comp.pair (targetWord_primrec.comp Primrec.fst).to_comp))

def Witness (p : Input) (w : Candidate) : Prop := DCPVerification.Witness p.1 w ∧
  rawEval (rank p.1) (substitute (leftWords p.1) w.1) ∈
    Subgroup.centralizer {z | z ∈ p.2.1.map (rawEval (rank p.1))} ∧
  rawEval (rank p.1) (substitute (rightWords p.1) w.2) ∈
    Subgroup.centralizer {z | z ∈ p.2.2.map (rawEval (rank p.1))}

/-- The extra candidate test uses only finitely many word-problem calls. -/
def commutationTest (q : ℕ × RawWord) (v : RawWord) : Bool :=
  wordDecision (q.1, (q.2 ++ v, v ++ q.2))

theorem commutationTest_computable : Computable₂ commutationTest :=
  wordDecision_computable.comp ((Primrec.fst.comp Primrec.fst).to_comp.pair
    ((Primrec.list_append.comp (Primrec.snd.comp Primrec.fst) Primrec.snd).to_comp.pair
      (Primrec.list_append.comp Primrec.snd (Primrec.snd.comp Primrec.fst)).to_comp))

theorem commutationTest_spec (n : ℕ) (hn : 1 ≤ n) (u v : RawWord)
    (hu : RawValid n u) (hv : RawValid n v) :
    commutationTest (n, u) v = true ↔ rawEval n v * rawEval n u = rawEval n u * rawEval n v := by
  rw [commutationTest, wordDecision_spec n hn _ _
    ((rawValid_append n u v).mpr ⟨hu, hv⟩) ((rawValid_append n v u).mpr ⟨hv, hu⟩)]
  simp only [rawEval_append, eq_comm]

def candidateTest (p : Input) (w : Candidate) : Bool :=
  DCPVerification.candidateTest p.1 w &&
    allChecks commutationTest (rank p.1, substitute (leftWords p.1) w.1) p.2.1 &&
    allChecks commutationTest (rank p.1, substitute (rightWords p.1) w.2) p.2.2

theorem candidateTest_correct (p : Input) (hp : ValidInput p) (w : Candidate) :
    candidateTest p w = true ↔ Witness p w := by
  have hbase := DCPVerification.candidateTest_correct p.1 hp.1 w
  simp only [candidateTest, Bool.and_eq_true, hbase, Witness]
  constructor
  · rintro ⟨⟨hw, hU⟩, hV⟩
    refine ⟨hw, ?_, ?_⟩
    · intro z hz
      obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hz
      exact (commutationTest_spec _ hp.1.1 _ v
        (substitute_valid _ _ hp.1.2.1 _ hw.1.1) (hp.2.1 v hv)).mp
          ((allChecks_spec _ _ _).mp hU v hv)
    · intro z hz
      obtain ⟨v, hv, rfl⟩ := List.mem_map.mp hz
      exact (commutationTest_spec _ hp.1.1 _ v
        (substitute_valid _ _ hp.1.2.2.1 _ hw.1.2) (hp.2.2 v hv)).mp
          ((allChecks_spec _ _ _).mp hV v hv)
  · rintro ⟨hw, hU, hV⟩
    refine ⟨⟨hw, (allChecks_spec _ _ _).mpr ?_⟩, (allChecks_spec _ _ _).mpr ?_⟩
    · intro v hv
      exact (commutationTest_spec _ hp.1.1 _ v
        (substitute_valid _ _ hp.1.2.1 _ hw.1.1) (hp.2.1 v hv)).mpr
          (hU _ (List.mem_map.mpr ⟨v, hv, rfl⟩))
    · intro v hv
      exact (commutationTest_spec _ hp.1.1 _ v
        (substitute_valid _ _ hp.1.2.2.1 _ hw.1.2) (hp.2.2 v hv)).mpr
          (hV _ (List.mem_map.mpr ⟨v, hv, rfl⟩))

theorem positive_iff_witness (p : Input) : Positive p ↔ ∃ w, Witness p w := by
  constructor
  · rintro ⟨a, ha, b, hb, he, hU, hV⟩
    obtain ⟨u, hu, heu⟩ := subgroupWord_exists _ _ ha
    obtain ⟨v, hv, hev⟩ := subgroupWord_exists _ _ hb
    exact ⟨(u, v), ⟨⟨hu, hv⟩, by simpa only [heu, hev] using he⟩,
      by simpa only [heu] using hU, by simpa only [hev] using hV⟩
  · rintro ⟨w, ⟨hv, he⟩, hU, hV⟩
    exact ⟨_, substitute_mem _ _ w.1 hv.1, _, substitute_mem _ _ w.2 hv.2, he, hU, hV⟩

theorem candidateTest_computable : Computable₂ candidateTest := by
  have hb : Computable (fun q : Input × Candidate => DCPVerification.candidateTest q.1.1 q.2) := DCPVerification.candidateTest_computable.comp
    (Computable.fst.comp Computable.fst) Computable.snd
  have hL : Computable (fun q : Input × Candidate =>
      allChecks commutationTest (rank q.1.1, substitute (leftWords q.1.1) q.2.1) q.1.2.1) :=
    (allChecks_computable _ commutationTest_computable).comp
      (((rank_primrec.comp (Primrec.fst.comp Primrec.fst)).to_comp).pair
        (substitute_primrec.comp (leftWords_primrec.comp (Primrec.fst.comp Primrec.fst))
          (Primrec.fst.comp Primrec.snd)).to_comp)
      (Primrec.fst.comp (Primrec.snd.comp Primrec.fst)).to_comp
  have hR : Computable (fun q : Input × Candidate =>
      allChecks commutationTest (rank q.1.1, substitute (rightWords q.1.1) q.2.2) q.1.2.2) :=
    (allChecks_computable _ commutationTest_computable).comp
      (((rank_primrec.comp (Primrec.fst.comp Primrec.fst)).to_comp).pair
        (substitute_primrec.comp (rightWords_primrec.comp (Primrec.fst.comp Primrec.fst))
          (Primrec.snd.comp Primrec.snd)).to_comp)
      (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)).to_comp
  exact (Primrec.and.to_comp.comp (Primrec.and.to_comp.comp hb hL) hR).of_eq
    (fun q => by change candidateTest q.1 q.2 = candidateTest q.1 q.2; rfl)

def search : Input → Part Candidate := FairSearch.run candidateTest

theorem search_partrec : Partrec search := FairSearch.run_partrec _ candidateTest_computable

theorem search_correct (p : Input) (hp : ValidInput p) :
    (search p).Dom ↔ Positive p := by
  rw [search, FairSearch.run_dom]
  exact (exists_congr fun w => candidateTest_correct p hp w).trans (positive_iff_witness p).symm

theorem search_sound (p : Input) (hp : ValidInput p) (w : Candidate) (hw : w ∈ search p) :
    Witness p w := (candidateTest_correct p hp w).mp (FairSearch.run_sound _ p w hw)

theorem inclusion_evalSet {n m : ℕ} (h : n ≤ m) (s : List RawWord)
    (hs : ∀ w ∈ s, RawValid n w) :
    inclusion h '' {z | z ∈ s.map (rawEval n)} = {z | z ∈ s.map (rawEval m)} := by
  ext z
  constructor
  · rintro ⟨y, hy, rfl⟩
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hy
    exact List.mem_map.mpr ⟨w, hw, (inclusion_rawEval h w (hs w hw)).symm⟩
  · intro hz
    obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hz
    exact ⟨rawEval n w, List.mem_map.mpr ⟨w, hw, rfl⟩, inclusion_rawEval h w (hs w hw)⟩

theorem reduction_correct (p : Input) (hp : ValidInput p) (hn : 2 ≤ rank p.1) :
    RawInstanceSolvable (rank p.1 + 1) (reductionInstance p) ↔ Positive p := by
  rcases hp.1 with ⟨_, hAs, hBs, hg, hh, hA, hB⟩
  let n := rank p.1
  let f := inclusion (Nat.le_succ n)
  let A := rawSubgroup n (leftWords p.1)
  let B := rawSubgroup n (rightWords p.1)
  have hAm := rawSubgroup_map (Nat.le_succ n) (leftWords p.1) hAs
  have hBm := rawSubgroup_map (Nat.le_succ n) (rightWords p.1) hBs
  have hAmP := inclusion_isParabolic (Nat.le_succ n) A hA
  have hBmP := inclusion_isParabolic (Nat.le_succ n) B hB
  have hcs := centralizerWords_spec (n + 1) (by omega) (leftWords p.1)
    (fun w hw => rawValid_mono (Nat.le_succ n) (hAs w hw))
  have hds := centralizerWords_spec (n + 1) (by omega) (rightWords p.1)
    (fun w hw => rawValid_mono (Nat.le_succ n) (hBs w hw))
  have hcentral := addedStrand_center_intersection n hn
  have hAR : A.map f ≤ f.range := Subgroup.map_le_range f A
  have hBR : B.map f ≤ f.range := Subgroup.map_le_range f B
  have he := constrained_ambient_reduction (A.map f) (B.map f) f.range hAR hBR
    ((centralizerWords (n + 1, leftWords p.1)).map (rawEval (n + 1)))
    ((centralizerWords (n + 1, rightWords p.1)).map (rawEval (n + 1)))
    (by simpa only [A, f, hAm] using hcs.2)
    (by simpa only [B, f, hBm] using hds.2)
    (parabolic_hasDoubleCentralizer _ (by omega) _ hAmP)
    (parabolic_hasDoubleCentralizer _ (by omega) _ hBmP)
    hcentral {z | z ∈ p.2.1.map (rawEval (n + 1))}
    {z | z ∈ p.2.2.map (rawEval (n + 1))} (f (rawEval n (sourceWord p.1))) (f (rawEval n (targetWord p.1)))
    ⟨_, rfl⟩ ⟨_, rfl⟩
  rw [inclusion_rawEval (Nat.le_succ n) _ hg, inclusion_rawEval (Nat.le_succ n) _ hh] at he
  rw [reductionInstance, rawAssembly_solvable_iff]
  simp only [List.map_append]
  simp_rw [solves_append_iff]
  have hreflect : ConstrainedDoubleCoset (A.map f) (B.map f)
      {z | z ∈ p.2.1.map (rawEval (n + 1))} {z | z ∈ p.2.2.map (rawEval (n + 1))}
      (rawEval (n + 1) (sourceWord p.1)) (rawEval (n + 1) (targetWord p.1)) ↔ Positive p := by
    rw [← inclusion_evalSet (Nat.le_succ n) p.2.1 hp.2.1,
      ← inclusion_evalSet (Nat.le_succ n) p.2.2 hp.2.2,
      ← inclusion_rawEval (Nat.le_succ n) _ hg, ← inclusion_rawEval (Nat.le_succ n) _ hh]
    exact map_constrainedDoubleCoset_iff f (Literature.standardEmbedding_injective _) A B
      {z | z ∈ p.2.1.map (rawEval n)} {z | z ∈ p.2.2.map (rawEval n)} _ _
  exact he.trans hreflect


theorem reduction_valid (p : Input) (hp : ValidInput p) :
    RawInstanceValid (rank p.1 + 1) (reductionInstance p) := by
  have hcs := (centralizerWords_spec (rank p.1 + 1) (by omega) (leftWords p.1)
    (fun w hw => rawValid_mono (Nat.le_succ _) (hp.1.2.1 w hw))).1
  have hds := (centralizerWords_spec (rank p.1 + 1) (by omega) (rightWords p.1)
    (fun w hw => rawValid_mono (Nat.le_succ _) (hp.1.2.2.1 w hw))).1
  exact rawAssembly_valid _ _ _ _ _
    (fun w hw => (List.mem_append.mp hw).elim (hcs w)
      (fun hw => rawValid_mono (Nat.le_succ _) (hp.2.1 w hw)))
    (fun w hw => (List.mem_append.mp hw).elim (hds w)
      (fun hw => rawValid_mono (Nat.le_succ _) (hp.2.2 w hw)))
    (rawValid_mono (Nat.le_succ _) hp.1.2.2.2.1)
    (rawValid_mono (Nat.le_succ _) hp.1.2.2.2.2.1)

def decision (p : Input) : Bool := if rank p.1 ≤ 1 then true else
  simultaneousDecision (rank p.1 + 1, reductionInstance p)

theorem decision_correct (p : Input) (hp : ValidInput p) : decision p = true ↔ Positive p := by
  by_cases hn : rank p.1 ≤ 1
  · simp only [decision, if_pos hn, true_iff]
    refine ⟨1, (rawSubgroup _ _).one_mem, 1, (rawSubgroup _ _).one_mem, ?_, ?_, ?_⟩
    · simp only [BraidGroup.eq_one_of_le_one hn (rawEval _ (sourceWord p.1)),
        BraidGroup.eq_one_of_le_one hn (rawEval _ (targetWord p.1)), mul_one]
    · exact (Subgroup.centralizer _).one_mem
    · exact (Subgroup.centralizer _).one_mem
  · simp only [decision, if_neg hn]
    exact (simultaneousDecision_spec _ (by omega) _ (reduction_valid p hp)).trans
      (reduction_correct p hp (by omega))

theorem decision_computable : Computable decision := by
  have hsmall : PrimrecPred (fun p : Input => rank p.1 ≤ 1) :=
    Primrec.nat_le.comp (rank_primrec.comp Primrec.fst) (Primrec.const 1)
  have hlarge : Computable (fun p : Input => simultaneousDecision (rank p.1 + 1, reductionInstance p)) :=
    simultaneousDecision_computable.comp ((ambientRank_primrec.comp Primrec.fst).to_comp.pair
      reductionInstance_computable)
  exact (Computable.cond hsmall.decide.to_comp (Computable.const true) hlarge).of_eq
    (fun p => by simp only [Bool.cond_decide]; rfl)

/-- Uniform decision and search with the prescribed additional commutation tests. -/
theorem main_theorem : ∃ d : Input → Bool, ∃ s : Input → Part Candidate,
    Computable d ∧ Partrec s ∧ ∀ p, ValidInput p →
      (d p = true ↔ Positive p) ∧ (d p = true → (s p).Dom) ∧
      ∀ w ∈ s p, Witness p w := by
  exact ⟨decision, search, decision_computable, search_partrec, fun p hp =>
    ⟨decision_correct p hp, fun hd => (search_correct p hp).mpr ((decision_correct p hp).mp hd),
      search_sound p hp⟩⟩

end
end DCPVerification.Constraints
