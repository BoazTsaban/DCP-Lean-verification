import DCPVerification.Main
import Mathlib.Tactic.Ring

/-! # Exact size of the simultaneous-conjugacy word instance

This counts unreduced words; free cancellation can only make the result shorter.
No polynomial-time claim about the centralizer or conjugacy algorithms is made.
-/
namespace DCPVerification
open BraidGroup

def wordsLength (s : List RawWord) : ℕ := (s.map List.length).sum

def instanceLength (e : RawInstance) : ℕ := (e.map (fun p => p.1.length + p.2.length)).sum

@[simp] theorem rawInverse_length (w : RawWord) : (rawInverse w).length = w.length := by
  simp [rawInverse]

@[simp] theorem rawConjugate_length (w v : RawWord) :
    (rawConjugate w v).length = 2 * w.length + v.length := by
  simp [rawConjugate]
  omega

/-- The word-length bound in DCPv3's complexity paragraph is exact before reduction. -/
theorem rawAssembly_length (c d : List RawWord) (g h : RawWord) :
    instanceLength (rawAssembly ((c, d), (g, h))) =
      2 * wordsLength c + 2 * wordsLength d + 2 * d.length * (g.length + h.length) := by
  have hc : (c.map (fun w => w.length + w.length)).sum = 2 * wordsLength c := by
    induction c with
    | nil => simp [wordsLength]
    | cons w c ih => simp [wordsLength] at *; omega
  have hd : (d.map (fun w => (2 * h.length + w.length) + (2 * g.length + w.length))).sum =
      2 * wordsLength d + 2 * d.length * (g.length + h.length) := by
    induction d with
    | nil => simp [wordsLength]
    | cons w d ih =>
      simp only [List.map_cons, List.sum_cons, List.length_cons]
      rw [ih]
      simp only [wordsLength, List.map_cons, List.sum_cons]
      ring
  simp only [instanceLength, rawAssembly, List.map_append, List.sum_append, List.map_map,
    Function.comp_def, rawConjugate_length]
  rw [hc, hd]
  omega

/-- The number of simultaneous-conjugacy equations is exactly `r + s`. -/
theorem rawAssembly_equations (c d : List RawWord) (g h : RawWord) :
    (rawAssembly ((c, d), (g, h))).length = c.length + d.length := by simp [rawAssembly]

end DCPVerification
