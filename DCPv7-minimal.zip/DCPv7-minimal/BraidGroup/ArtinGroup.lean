import BraidGroup.Parabolic

/-! # Finite Artin presentations for the spherical-type extensions

The generator matrix gives alternating-word relations and does not impose
involutions. Sphericality and the cited structural theorems are literature inputs.
-/
namespace FiniteArtinGroup

def alternating {G : Type*} [Monoid G] (a b : G) : ℕ → G
  | 0 => 1
  | k + 1 => a * alternating b a k

def relators {r : ℕ} (M : Fin r → Fin r → ℕ) : Set (FreeGroup (Fin r)) :=
  {w | ∃ i j : Fin r, i ≠ j ∧ w =
    alternating (FreeGroup.of i) (FreeGroup.of j) (M i j) *
      (alternating (FreeGroup.of j) (FreeGroup.of i) (M i j))⁻¹}

end FiniteArtinGroup

/-- The group of a finite Artin presentation. -/
abbrev FiniteArtinGroup {r : ℕ} (M : Fin r → Fin r → ℕ) := PresentedGroup (FiniteArtinGroup.relators M)

namespace FiniteArtinGroup
variable {r : ℕ} {M : Fin r → Fin r → ℕ}

def generator (i : Fin r) : FiniteArtinGroup M := PresentedGroup.of i

def standardParabolic (I : Set (Fin r)) : Subgroup (FiniteArtinGroup M) :=
  Subgroup.closure (generator '' I)

def IsParabolic (A : Subgroup (FiniteArtinGroup M)) : Prop :=
  ∃ I : Set (Fin r), ∃ a : FiniteArtinGroup M,
    A = BraidGroup.conjugateSubgroup a (standardParabolic I)

/-- Diagram tags: `0=B`, `1=D`, `2=E`, `3=H`; the second component is the rank. -/
abbrev Diagram := Fin 4 × ℕ

def pairEdge (i j a b : ℕ) : Prop := (i = a ∧ j = b) ∨ (i = b ∧ j = a)

instance (i j a b : ℕ) : Decidable (pairEdge i j a b) :=
  inferInstanceAs (Decidable ((i = a ∧ j = b) ∨ (i = b ∧ j = a)))

def matrix (X : Diagram) (i j : Fin X.2) : ℕ :=
  if i = j then 1 else
  if X.1 = 0 then
    if pairEdge i.val j.val 0 1 then 4 else if i.val + 1 = j.val ∨ j.val + 1 = i.val then 3 else 2
  else if X.1 = 1 then
    if pairEdge i.val j.val 0 2 ∨ pairEdge i.val j.val 1 2 ∨
      (2 ≤ i.val ∧ 2 ≤ j.val ∧ (i.val + 1 = j.val ∨ j.val + 1 = i.val)) then 3 else 2
  else if X.1 = 2 then
    if pairEdge i.val j.val 0 2 ∨ pairEdge i.val j.val 1 3 ∨
      (2 ≤ i.val ∧ 2 ≤ j.val ∧ (i.val + 1 = j.val ∨ j.val + 1 = i.val)) then 3 else 2
  else
    if pairEdge i.val j.val 0 1 then 5 else if i.val + 1 = j.val ∨ j.val + 1 = i.val then 3 else 2

abbrev OfDiagram (X : Diagram) := FiniteArtinGroup (matrix X)

/-- Exactly the enlargements listed in DCPv3. `H₂` is `I₂(5)`. -/
def AllowedEmbedding (X Y : Diagram) : Prop :=
  (X.1 = 0 ∧ Y.1 = 0 ∧ 2 ≤ X.2 ∧ Y.2 = X.2 + 1) ∨
  (X.1 = 1 ∧ Y.1 = 1 ∧ 4 ≤ X.2 ∧ X.2 < Y.2 ∧ Even Y.2) ∨
  (X = (2, 6) ∧ Y = (2, 7)) ∨ (X = (2, 7) ∧ Y = (2, 8)) ∨
  (X = (3, 3) ∧ Y = (3, 4)) ∨ (X = (3, 2) ∧ Y = (3, 3))

end FiniteArtinGroup
