import BraidGroup.RawWords
import Mathlib.Data.List.GetD

/-! # Words in a supplied subgroup generating list

The output alphabet indexes the supplied list, not the ambient Artin generators.
Thus witness words meet the search requirement of DCPv3.
-/
namespace BraidGroup

/-- Every letter indexes an actual supplied subgroup generator. -/
def SubgroupWordValid (s : List RawWord) (w : RawWord) : Prop := ∀ l ∈ w, l.1 < s.length

def substituteChunk (s : List RawWord) (l : RawLetter) : RawWord :=
  if l.2 then s.getD l.1 [] else rawInverse (s.getD l.1 [])

/-- Expand a signed word in a supplied subgroup generating list to an ambient braid word. -/
def substitute (s : List RawWord) (w : RawWord) : RawWord := w.flatMap (substituteChunk s)

@[simp] theorem substitute_nil (s : List RawWord) : substitute s [] = [] := rfl
@[simp] theorem substitute_cons (s : List RawWord) (l : RawLetter) (w : RawWord) :
    substitute s (l :: w) = substituteChunk s l ++ substitute s w := rfl
@[simp] theorem substitute_append (s : List RawWord) (u v : RawWord) :
    substitute s (u ++ v) = substitute s u ++ substitute s v := by simp [substitute]

@[simp] theorem rawEval_substitute_flip (n : ℕ) (s : List RawWord) (l : RawLetter) :
    rawEval n (substituteChunk s (l.1, !l.2)) = (rawEval n (substituteChunk s l))⁻¹ := by
  rcases l with ⟨i, b⟩
  cases b <;> simp [substituteChunk]

@[simp] theorem rawEval_substitute_inverse (n : ℕ) (s : List RawWord) (w : RawWord) :
    rawEval n (substitute s (rawInverse w)) = (rawEval n (substitute s w))⁻¹ := by
  induction w with
  | nil => simp [rawInverse]
  | cons l w ih =>
    have he : rawInverse (l :: w) = rawInverse w ++ [(l.1, !l.2)] := by simp [rawInverse]
    rw [he]
    simp [ih, mul_inv_rev]

@[simp] theorem subgroupWordValid_nil (s : List RawWord) : SubgroupWordValid s [] := by
  simp [SubgroupWordValid]
@[simp] theorem subgroupWordValid_append (s : List RawWord) (u v : RawWord) :
    SubgroupWordValid s (u ++ v) ↔ SubgroupWordValid s u ∧ SubgroupWordValid s v := by
  simp [SubgroupWordValid, or_imp, forall_and]
@[simp] theorem subgroupWordValid_inverse (s : List RawWord) (w : RawWord) :
    SubgroupWordValid s (rawInverse w) ↔ SubgroupWordValid s w := by
  simpa [RawValid, SubgroupWordValid] using rawValid_inverse (s.length + 1) w

/-- Every subgroup element is represented by a word in the supplied generators. -/
theorem subgroupWord_exists (n : ℕ) (s : List RawWord) {a : BraidGroup n}
    (ha : a ∈ rawSubgroup n s) :
    ∃ w, SubgroupWordValid s w ∧ rawEval n (substitute s w) = a := by
  induction ha using Subgroup.closure_induction with
  | mem x hx =>
    rcases List.mem_map.mp hx with ⟨u, hu, rfl⟩
    rcases List.mem_iff_getElem.mp hu with ⟨i, hi, he⟩
    refine ⟨[(i, true)], ?_, ?_⟩
    · simpa [SubgroupWordValid] using hi
    · simp only [substitute_cons, substitute_nil, substituteChunk, if_true, List.append_nil]
      rw [List.getD_eq_getElem s [] hi, he]
  | one => exact ⟨[], by simp, by simp⟩
  | mul x y hx hy ihx ihy =>
    rcases ihx with ⟨u, hu, heu⟩
    rcases ihy with ⟨v, hv, hev⟩
    exact ⟨u ++ v, (subgroupWordValid_append s u v).mpr ⟨hu, hv⟩, by simp [heu, hev]⟩
  | inv x hx ih =>
    rcases ih with ⟨u, hu, heu⟩
    exact ⟨rawInverse u, (subgroupWordValid_inverse s u).mpr hu, by simp [heu]⟩

/-- Expansion of a valid subgroup word is a valid ambient braid word. -/
theorem substitute_valid (n : ℕ) (s : List RawWord) (hs : ∀ u ∈ s, RawValid n u)
    (w : RawWord) (hw : SubgroupWordValid s w) : RawValid n (substitute s w) := by
  induction w with
  | nil => simp
  | cons l w ih =>
    have hl := hw l (by simp)
    have ht : SubgroupWordValid s w := fun k hk => hw k (by simp [hk])
    rw [substitute_cons, rawValid_append]
    constructor
    · have hget : RawValid n (s.getD l.1 []) := by
        rw [List.getD_eq_getElem s [] hl]
        exact hs _ (List.getElem_mem hl)
      rcases l with ⟨i, b⟩
      cases b <;> simpa [substituteChunk] using hget
    · exact ih ht

/-- A valid word in the supplied subgroup generators evaluates into that subgroup. -/
theorem substitute_mem (n : ℕ) (s : List RawWord) (w : RawWord)
    (hw : SubgroupWordValid s w) : rawEval n (substitute s w) ∈ rawSubgroup n s := by
  induction w with
  | nil => simp only [substitute_nil, rawEval_nil]; exact (rawSubgroup n s).one_mem
  | cons l w ih =>
    have hl := hw l (by simp)
    have ht : SubgroupWordValid s w := fun k hk => hw k (by simp [hk])
    have hm : rawEval n (s.getD l.1 []) ∈ rawSubgroup n s := by
      rw [List.getD_eq_getElem s [] hl]
      exact Subgroup.subset_closure (List.mem_map.mpr ⟨_, List.getElem_mem hl, rfl⟩)
    rw [substitute_cons, rawEval_append]
    apply (rawSubgroup n s).mul_mem _ (ih ht)
    rcases l with ⟨i, b⟩
    cases b
    · simpa only [substituteChunk, Bool.false_eq_true, if_false, rawEval_inverse] using
        (rawSubgroup n s).inv_mem hm
    · simpa only [substituteChunk, if_true] using hm

/-- Boolean validity tests for subgroup words are primitive recursive. -/
theorem subgroupWordValid_primrec : PrimrecRel SubgroupWordValid := by
  have hr : PrimrecRel (fun l : RawLetter => fun k : ℕ => l.1 < k) :=
    Primrec.nat_lt.comp (Primrec.fst.comp Primrec.fst) Primrec.snd
  exact hr.forall_mem_list.comp Primrec.snd (Primrec.list_length.comp Primrec.fst)

/-- Substitution into a supplied generating list is primitive recursive. -/
theorem substitute_primrec : Primrec₂ substitute := by
  have hget : Primrec (fun p : List RawWord × RawLetter => p.1.getD p.2.1 []) :=
    (Primrec.list_getD []).comp Primrec.fst (Primrec.fst.comp Primrec.snd)
  have hchunk : Primrec₂ substituteChunk :=
    (Primrec.cond (Primrec.snd.comp Primrec.snd) hget (rawInverse_primrec.comp hget)).of_eq
      (fun p => by rcases p with ⟨s, i, b⟩; cases b <;> rfl)
  exact Primrec.list_flatMap Primrec.snd
    (Primrec.to₂ (hchunk.comp (Primrec.fst.comp Primrec.fst) Primrec.snd))

end BraidGroup
