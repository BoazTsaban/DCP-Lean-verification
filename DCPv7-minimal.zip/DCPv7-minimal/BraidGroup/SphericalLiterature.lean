import BraidGroup.ArtinWords
import BraidGroup.DoubleCoset
import BraidGroup.RawWords
import Mathlib.Computability.Partrec

/-! # Named literature inputs for the spherical Artin enlargements

Only the embeddings explicitly listed in DCPv3 are admitted. The algebraic
criterion and the double-coset conclusions are proved in separate modules.
The direct-product assertion includes trivial center intersection; it is not
an axiom asserting solvability of the double-coset problem.
-/
namespace FiniteArtinGroup.Literature
open FiniteArtinGroup

/-- Standard parabolic embedding (van der Lek). -/
axiom embedding (X Y : Diagram) (h : AllowedEmbedding X Y) : OfDiagram X →* OfDiagram Y

axiom embedding_injective (X Y : Diagram) (h : AllowedEmbedding X Y) :
  Function.Injective (embedding X Y h)

/-- A proper standard parabolic range and preservation of its parabolic subgroups. -/
axiom embedding_parabolic (X Y : Diagram) (h : AllowedEmbedding X Y) :
  (∃ I : Set (Fin Y.2), I ≠ Set.univ ∧
    (embedding X Y h).range = standardParabolic I) ∧
  ∀ A : Subgroup (OfDiagram X), IsParabolic A →
    IsParabolic (A.map (embedding X Y h))

/-- Ajbal--Godelle, Theorem 0.1, in the indicated nonexceptional ambient types. -/
axiom doubleCentralizer (X Y : Diagram) (h : AllowedEmbedding X Y)
    (A : Subgroup (OfDiagram Y)) (hA : IsParabolic A) :
  Subgroup.centralizer (Subgroup.centralizer (A : Set (OfDiagram Y)) : Set (OfDiagram Y)) =
    Subgroup.center (OfDiagram Y) ⊔ A

/-- The trivial intersection in the internal direct product of Theorem 0.1. -/
axiom directProduct_intersection (X Y : Diagram) (h : AllowedEmbedding X Y)
    (I : Set (Fin Y.2)) (hI : I ≠ Set.univ) :
  Subgroup.center (OfDiagram Y) ⊓ standardParabolic I = ⊥

/-- Standard embedding acts on words by retaining their generator indices. -/
axiom embedding_word (X Y : Diagram) (h : AllowedEmbedding X Y)
    (w : BraidGroup.RawWord) (hw : BraidGroup.RawValid (X.2 + 1) w) :
  embedding X Y h (rawEval X w) = rawEval Y w

/-- Effective biautomatic structures (Charney; Gersten--Short) give a uniform word problem. -/
axiom wordProblem_exists :
  ∃ f : Diagram × (BraidGroup.RawWord × BraidGroup.RawWord) → Bool,
    Computable f ∧ ∀ X, Supported X → ∀ u v,
      BraidGroup.RawValid (X.2 + 1) u → BraidGroup.RawValid (X.2 + 1) v →
      (f (X, (u, v)) = true ↔ rawEval X u = rawEval X v)

/-- Centralizers of finite sets in the effective biautomatic structure. -/
axiom centralizerAlgorithm_exists :
  ∃ f : Diagram × List BraidGroup.RawWord → List BraidGroup.RawWord,
    Computable f ∧ ∀ X, Supported X → ∀ s,
      (∀ w ∈ s, BraidGroup.RawValid (X.2 + 1) w) →
      (∀ w ∈ f (X, s), BraidGroup.RawValid (X.2 + 1) w) ∧
      GroupDCP.Generates ((f (X, s)).map (rawEval X))
        (Subgroup.centralizer (rawSubgroup X s : Set (OfDiagram X)))

/-- Finite intersection of regular conjugator languages decides simultaneous conjugacy. -/
axiom simultaneousConjugacy_exists :
  ∃ f : Diagram × BraidGroup.RawInstance → Bool,
    Computable f ∧ ∀ X, Supported X → ∀ e, InstanceValid X e →
      (f (X, e) = true ↔ InstanceSolvable X e)

end FiniteArtinGroup.Literature
