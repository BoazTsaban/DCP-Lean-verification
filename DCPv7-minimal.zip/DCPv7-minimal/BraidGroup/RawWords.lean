import BraidGroup.Words
import BraidGroup.Operations
import Mathlib.Computability.Partrec

/-! # Uniform word encodings for braid algorithms

Natural-number crossing indices allow one fixed encoding across all strand counts.
`RawValid n w` requires all letters to lie in the n-strand generator range.
Invalid letters evaluate to the identity; all algorithm specifications explicitly
require valid inputs, so this totalization never changes a valid braid word.
-/
namespace BraidGroup

abbrev RawLetter := ℕ × Bool
abbrev RawWord := List RawLetter

def RawValid (n : ℕ) (w : RawWord) : Prop := ∀ l ∈ w, l.1 < n - 1

def rawLetter (n : ℕ) (l : RawLetter) : BraidGroup n :=
  if h : l.1 < n - 1 then letterValue (⟨l.1, h⟩, l.2) else 1

def rawEval (n : ℕ) (w : RawWord) : BraidGroup n := (w.map (rawLetter n)).prod

def rawInverse (w : RawWord) : RawWord := w.reverse.map (fun l => (l.1, !l.2))

def rawConjugate (w v : RawWord) : RawWord := w ++ v ++ rawInverse w

def encodeWord {n : ℕ} (w : Word n) : RawWord := w.map (fun l => (l.1.val, l.2))

def rawSubgroup (n : ℕ) (s : List RawWord) : Subgroup (BraidGroup n) :=
  Subgroup.closure {x | x ∈ s.map (rawEval n)}

@[simp] theorem rawEval_nil (n : ℕ) : rawEval n [] = 1 := rfl
@[simp] theorem rawEval_cons (n : ℕ) (l : RawLetter) (w : RawWord) :
    rawEval n (l :: w) = rawLetter n l * rawEval n w := rfl
@[simp] theorem rawEval_append (n : ℕ) (u v : RawWord) :
    rawEval n (u ++ v) = rawEval n u * rawEval n v := by simp [rawEval]

@[simp] theorem rawLetter_flip (n : ℕ) (l : RawLetter) :
    rawLetter n (l.1, !l.2) = (rawLetter n l)⁻¹ := by
  rcases l with ⟨i, s⟩
  by_cases h : i < n - 1 <;> cases s <;> simp [rawLetter, letterValue, h]

@[simp] theorem rawEval_inverse (n : ℕ) (w : RawWord) :
    rawEval n (rawInverse w) = (rawEval n w)⁻¹ := by
  induction w with
  | nil => simp [rawInverse]
  | cons l w ih =>
    have he : rawInverse (l :: w) = rawInverse w ++ [(l.1, !l.2)] := by simp [rawInverse]
    rw [he]
    simp [ih, mul_inv_rev]

@[simp] theorem rawEval_conjugate (n : ℕ) (w v : RawWord) :
    rawEval n (rawConjugate w v) = rawEval n w * rawEval n v * (rawEval n w)⁻¹ := by
  simp [rawConjugate, mul_assoc]

@[simp] theorem rawValid_nil (n : ℕ) : RawValid n [] := by simp [RawValid]
@[simp] theorem rawValid_append (n : ℕ) (u v : RawWord) :
    RawValid n (u ++ v) ↔ RawValid n u ∧ RawValid n v := by simp [RawValid, or_imp, forall_and]

@[simp] theorem rawInverse_inverse (w : RawWord) : rawInverse (rawInverse w) = w := by
  simp [rawInverse, List.map_reverse, List.map_map, Function.comp_def]

@[simp] theorem rawValid_inverse (n : ℕ) (w : RawWord) :
    RawValid n (rawInverse w) ↔ RawValid n w := by
  have hf : ∀ u : RawWord, RawValid n u → RawValid n (rawInverse u) := by
    intro u hu l hl
    rcases List.mem_map.mp hl with ⟨a, ha, rfl⟩
    exact hu a (List.mem_reverse.mp ha)
  exact ⟨fun h => by simpa using hf (rawInverse w) h, hf w⟩

theorem rawValid_mono {n m : ℕ} (h : n ≤ m) {w : RawWord} (hw : RawValid n w) :
    RawValid m w := by intro l hl; have := hw l hl; omega

theorem encodeWord_valid {n : ℕ} (w : Word n) : RawValid n (encodeWord w) := by
  intro l hl
  rcases List.mem_map.mp hl with ⟨a, _, rfl⟩
  exact a.1.isLt

@[simp] theorem rawEval_encodeWord {n : ℕ} (w : Word n) : rawEval n (encodeWord w) = eval w := by
  induction w with
  | nil => rfl
  | cons l w ih =>
    change rawLetter n (l.1.val, l.2) * rawEval n (encodeWord w) = letterValue l * eval w
    rw [ih]
    simp [rawLetter, l.1.isLt]

/-- Every braid has a valid word in the single, rank-independent encoding. -/
theorem rawEval_surjective (n : ℕ) (b : BraidGroup n) :
    ∃ w : RawWord, RawValid n w ∧ rawEval n w = b := by
  obtain ⟨w, rfl⟩ := eval_surjective b
  exact ⟨encodeWord w, encodeWord_valid w, rawEval_encodeWord w⟩

/-- Adding strands leaves a valid raw word unchanged. -/
theorem inclusion_rawEval {n m : ℕ} (h : n ≤ m) (w : RawWord) (hw : RawValid n w) :
    inclusion h (rawEval n w) = rawEval m w := by
  induction w with
  | nil => simp
  | cons l w ih =>
    have hl := hw l (by simp)
    have htail : RawValid n w := fun k hk => hw k (by simp [hk])
    have hlm : l.1 < m - 1 := by omega
    simp only [rawEval_cons, map_mul, ih htail]
    rcases l with ⟨i, s⟩
    cases s <;> simp [rawLetter, letterValue, hl, hlm]

/-- Inversion of encoded words is primitive recursive. -/
theorem rawInverse_primrec : Primrec rawInverse := by
  exact Primrec.list_map Primrec.list_reverse
    (Primrec.to₂ ((Primrec.fst.comp Primrec.snd).pair
      ((Primrec.dom_finite Bool.not).comp (Primrec.snd.comp Primrec.snd))))

/-- Constructing a word conjugate is primitive recursive. -/
theorem rawConjugate_primrec : Primrec₂ rawConjugate :=
  Primrec.list_append.comp (Primrec.list_append.comp Primrec.fst Primrec.snd)
    (rawInverse_primrec.comp Primrec.fst)

/-- One simultaneous-conjugacy instance, encoded as a finite list of word pairs. -/
abbrev RawInstance := List (RawWord × RawWord)

def RawInstanceValid (n : ℕ) (e : RawInstance) : Prop :=
  ∀ p ∈ e, RawValid n p.1 ∧ RawValid n p.2

def RawInstanceSolvable (n : ℕ) (e : RawInstance) : Prop :=
  ∃ x : BraidGroup n, ∀ p ∈ e, x⁻¹ * rawEval n p.1 * x = rawEval n p.2

/-- Assemble the single simultaneous-conjugacy instance of the manuscript. -/
def rawAssembly (p : (List RawWord × List RawWord) × (RawWord × RawWord)) : RawInstance :=
  p.1.1.map (fun u => (u, u)) ++
    p.1.2.map (fun v => (rawConjugate p.2.2 v, rawConjugate p.2.1 v))

/-- The reduction's word-level assembly is primitive recursive. -/
theorem rawAssembly_primrec : Primrec rawAssembly := by
  apply Primrec.list_append.comp
  · exact Primrec.list_map (Primrec.fst.comp Primrec.fst)
      (Primrec.to₂ (Primrec.snd.pair Primrec.snd))
  · exact Primrec.list_map (Primrec.snd.comp Primrec.fst) (Primrec.to₂
      ((rawConjugate_primrec.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.fst)) Primrec.snd).pair
       (rawConjugate_primrec.comp (Primrec.fst.comp (Primrec.snd.comp Primrec.fst)) Primrec.snd)))

end BraidGroup
