import BraidGroup.Compatibility
import BraidGroup.FinitePresentation
import Mathlib.GroupTheory.Index
import BraidGroup.Words

/-! # Pure braid elements and standard pure crossings

`pureGenerator i j h` is the usual `A_(i,j)` with zero-based strand indices:
conjugate the square of crossing `i` by the descending crossings between `i` and `j`.
This module does not assert that these elements generate the pure braid subgroup.
-/

/-- The pure braid group, realized as a subgroup of the braid group. -/
abbrev PureBraidGroup (n : ℕ) := ↥(BraidGroup.pure n)

namespace BraidGroup

variable {n : ℕ}

/-- The inclusion of pure braids into all braids. -/
def pureInclusion (n : ℕ) : PureBraidGroup n →* BraidGroup n := (pure n).subtype

theorem pureInclusion_injective (n : ℕ) : Function.Injective (pureInclusion n) :=
  Subtype.val_injective

@[simp] theorem permutation_pureInclusion (b : PureBraidGroup n) :
    permutation (pureInclusion n b) = 1 := b.property

/-- Descending crossings used to move a square crossing to a pair of strand positions. -/
def pureConjugator (i j : Fin n) : BraidGroup n :=
  (((List.finRange (n - 1)).filter (fun k => i.val < k.val ∧ k.val < j.val)).reverse.map σ).prod

/-- The standard pure braid on strand positions `i < j`. -/
def pureGenerator (i j : Fin n) (h : i < j) : PureBraidGroup n :=
  ⟨pureConjugator i j * σ (⟨i.val, by have := j.isLt; have := h; omega⟩ : Generator n) ^ 2 *
    (pureConjugator i j)⁻¹, conjugate_sq_mem_pure _ _⟩

@[simp] theorem writhe_pureGenerator (i j : Fin n) (h : i < j) :
    writhe (pureGenerator i j h : BraidGroup n) = 2 := by
  simp [pureGenerator]

/-- Mirroring restricts to an involutive automorphism of the pure braid group. -/
def pureMirror : PureBraidGroup n ≃* PureBraidGroup n where
  toFun b := ⟨mirror b.val, by
    change permutation (mirror (b : BraidGroup n)) = 1
    rw [permutation_mirror]
    exact b.property⟩
  invFun b := ⟨mirror b.val, by
    change permutation (mirror (b : BraidGroup n)) = 1
    rw [permutation_mirror]
    exact b.property⟩
  left_inv b := Subtype.ext (mirror_mirror b.val)
  right_inv b := Subtype.ext (mirror_mirror b.val)
  map_mul' a b := Subtype.ext (mirror.map_mul a.val b.val)

@[simp] theorem pureMirror_val (b : PureBraidGroup n) :
    (pureMirror b : BraidGroup n) = mirror (b : BraidGroup n) := rfl

/-- Pure braids have finite index in the braid group. -/
instance pure_finiteIndex : (pure n).FiniteIndex :=
  inferInstanceAs (MonoidHom.ker (permutation (n := n))).FiniteIndex

/-- The index of the pure braid subgroup is `n!`. -/
theorem pure_index (n : ℕ) : (pure n).index = n.factorial := by
  rw [Subgroup.index_eq_card]
  calc
    Nat.card (BraidGroup n ⧸ pure n) = Nat.card (Equiv.Perm (Fin n)) :=
      Nat.card_congr (quotientPureEquiv n).toEquiv
    _ = n.factorial := by rw [Nat.card_eq_fintype_card, Fintype.card_perm, Fintype.card_fin]

/-- Schreier's lemma gives finite generation of the pure braid group. -/
instance pure_finitelyGenerated : Group.FG (PureBraidGroup n) :=
  inferInstanceAs (Group.FG ↥(pure n))

end BraidGroup
