import BraidGroup.ExponentSum

/-! # Signed braid words and their evaluation

Word evaluation is provided without claiming a decision procedure for braid equality.
The Boolean sign is `true` for a positive crossing and `false` for its inverse.
-/
namespace BraidGroup

variable {n : ℕ}

abbrev Letter (n : ℕ) := Generator n × Bool
abbrev Word (n : ℕ) := List (Letter n)

def letterValue (a : Letter n) : BraidGroup n := if a.2 then σ a.1 else (σ a.1)⁻¹

def eval (w : Word n) : BraidGroup n := (w.map letterValue).prod

@[simp] theorem letterValue_pos (i : Generator n) : letterValue (i, true) = σ i := rfl
@[simp] theorem letterValue_neg (i : Generator n) : letterValue (i, false) = (σ i)⁻¹ := rfl
@[simp] theorem eval_nil : eval ([] : Word n) = 1 := rfl
@[simp] theorem eval_cons (a : Letter n) (w : Word n) :
    eval (a :: w) = letterValue a * eval w := rfl
@[simp] theorem eval_singleton (a : Letter n) : eval [a] = letterValue a := by simp
@[simp] theorem eval_append (u v : Word n) : eval (u ++ v) = eval u * eval v := by
  simp [eval]

/-- Reverse a word and change every crossing sign. -/
def inverseWord (w : Word n) : Word n := w.reverse.map (fun a => (a.1, !a.2))

@[simp] theorem letterValue_flip (a : Letter n) :
    letterValue (a.1, !a.2) = (letterValue a)⁻¹ := by
  rcases a with ⟨i, b⟩
  cases b <;> simp [letterValue]

@[simp] theorem inverseWord_nil : inverseWord ([] : Word n) = [] := rfl
@[simp] theorem inverseWord_cons (a : Letter n) (w : Word n) :
    inverseWord (a :: w) = inverseWord w ++ [(a.1, !a.2)] := by
  simp [inverseWord]

@[simp] theorem eval_inverseWord (w : Word n) : eval (inverseWord w) = (eval w)⁻¹ := by
  induction w with
  | nil => simp
  | cons a w ih => simp [ih, mul_inv_rev]

@[simp] theorem inverseWord_inverseWord (w : Word n) : inverseWord (inverseWord w) = w := by
  simp [inverseWord, List.map_reverse, List.map_map, Function.comp_def]

/-- Every braid has a finite signed-word representative. -/
theorem eval_surjective : Function.Surjective (eval (n := n)) := by
  intro b
  refine induction_on b ⟨[], rfl⟩ (fun i => ⟨[(i, true)], by simp⟩) ?_ ?_
  · rintro b ⟨w, rfl⟩
    exact ⟨inverseWord w, eval_inverseWord w⟩
  · rintro a b ⟨u, rfl⟩ ⟨v, rfl⟩
    exact ⟨u ++ v, eval_append u v⟩

/-- Exponent sum may be computed directly from the signs in a word. -/
def wordExponent (w : Word n) : ℤ := (w.map (fun a => if a.2 then (1 : ℤ) else -1)).sum

@[simp] theorem writhe_letterValue (a : Letter n) :
    writhe (letterValue a) = if a.2 then 1 else -1 := by
  rcases a with ⟨i, b⟩
  cases b <;> simp [letterValue]

@[simp] theorem writhe_eval (w : Word n) : writhe (eval w) = wordExponent w := by
  induction w with
  | nil => simp [wordExponent]
  | cons a w ih => simp [wordExponent, ih]

/-- Unequal exponent sums certify unequal braids. -/
theorem eval_ne_of_wordExponent_ne (u v : Word n) (h : wordExponent u ≠ wordExponent v) :
    eval u ≠ eval v := by
  intro he
  exact h (by simpa using congrArg writhe he)

end BraidGroup
