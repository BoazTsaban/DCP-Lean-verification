import Mathlib.GroupTheory.PresentedGroup
import Mathlib.Tactic.Group
import Mathlib.Tactic.FinCases

/-!
# The Artin presentation of the braid group

`BraidGroup n` is the group on `n` strands. Generators are indexed from zero by
`Fin (n - 1)`: `σ i` crosses strands `i` and `i + 1`. This includes the trivial
zero- and one-strand groups. Multiplication is the group operation of Mathlib.
-/

namespace BraidGroup

/-- The indices of the standard generators of the braid group on `n` strands. -/
abbrev Generator (n : ℕ) := Fin (n - 1)

/-- Generators whose crossings have disjoint strand positions. -/
def Far {n : ℕ} (i j : Generator n) : Prop :=
  i.val + 1 < j.val ∨ j.val + 1 < i.val

/-- The second crossing immediately follows the first. -/
def Adjacent {n : ℕ} (i j : Generator n) : Prop := i.val + 1 = j.val

theorem Far.symm {n : ℕ} {i j : Generator n} (h : Far i j) : Far j i := Or.symm h

theorem Far.ne {n : ℕ} {i j : Generator n} (h : Far i j) : i ≠ j := by
  intro hij
  subst j
  rcases h with h | h <;> omega

/-- A relator for distant generators. -/
def commuteRelator {n : ℕ} (i j : Generator n) : FreeGroup (Generator n) :=
  (FreeGroup.of i * FreeGroup.of j) * (FreeGroup.of j * FreeGroup.of i)⁻¹

/-- A relator for adjacent generators. -/
def braidRelator {n : ℕ} (i j : Generator n) : FreeGroup (Generator n) :=
  (FreeGroup.of i * FreeGroup.of j * FreeGroup.of i) *
    (FreeGroup.of j * FreeGroup.of i * FreeGroup.of j)⁻¹

/-- Precisely the two families of relations in the Artin presentation. -/
inductive IsRelator (n : ℕ) : FreeGroup (Generator n) → Prop
  | commute (i j : Generator n) (h : Far i j) : IsRelator n (commuteRelator i j)
  | braid (i j : Generator n) (h : Adjacent i j) : IsRelator n (braidRelator i j)

/-- The defining relators. -/
def relators (n : ℕ) : Set (FreeGroup (Generator n)) := {r | IsRelator n r}

end BraidGroup

/-- The braid group on `n` strands, given by its standard Artin presentation. -/
abbrev BraidGroup (n : ℕ) := PresentedGroup (BraidGroup.relators n)

namespace BraidGroup

variable {n : ℕ}

/-- The standard positive crossing, indexed from zero. -/
def σ (i : Generator n) : BraidGroup n := PresentedGroup.of i

/-- The quotient map from words in the free group. -/
def ofFree : FreeGroup (Generator n) →* BraidGroup n := PresentedGroup.mk (relators n)

@[simp] theorem ofFree_of (i : Generator n) : ofFree (FreeGroup.of i) = σ i := rfl

theorem ofFree_surjective : Function.Surjective (ofFree (n := n)) :=
  PresentedGroup.mk_surjective _

/-- Distant standard generators commute. -/
theorem far_comm (i j : Generator n) (h : Far i j) : σ i * σ j = σ j * σ i := by
  have hr := PresentedGroup.one_of_mem (rels := relators n) (IsRelator.commute i j h)
  change ofFree (commuteRelator i j) = 1 at hr
  simpa [commuteRelator, map_mul, map_inv] using (mul_inv_eq_one.mp hr)

/-- The standard three-term Artin relation. -/
theorem braid_relation (i j : Generator n) (h : Adjacent i j) :
    σ i * σ j * σ i = σ j * σ i * σ j := by
  have hr := PresentedGroup.one_of_mem (rels := relators n) (IsRelator.braid i j h)
  change ofFree (braidRelator i j) = 1 at hr
  simpa [braidRelator, map_mul, map_inv] using (mul_inv_eq_one.mp hr)

/-- The hypotheses needed to extend generator images to a homomorphism. -/
structure IsBraidSystem {G : Type*} [Group G] (f : Generator n → G) : Prop where
  far_comm : ∀ i j, Far i j → f i * f j = f j * f i
  braid_relation : ∀ i j, Adjacent i j → f i * f j * f i = f j * f i * f j

variable {G : Type*} [Group G]

/-- The universal homomorphism determined by a braid system. -/
def lift (f : Generator n → G) (hf : IsBraidSystem f) : BraidGroup n →* G :=
  PresentedGroup.toGroup (f := f) (fun r hr => by
    cases hr with
    | commute i j h =>
      simp only [commuteRelator, map_mul, map_inv, FreeGroup.lift_apply_of]
      rw [hf.far_comm i j h, mul_inv_cancel]
    | braid i j h =>
      simp only [braidRelator, map_mul, map_inv, FreeGroup.lift_apply_of]
      rw [hf.braid_relation i j h, mul_inv_cancel])

@[simp] theorem lift_σ (f : Generator n → G) (hf : IsBraidSystem f) (i : Generator n) :
    lift f hf (σ i) = f i := PresentedGroup.toGroup.of _

/-- Homomorphisms from a braid group agree if they agree on standard generators. -/
@[ext] theorem hom_ext {f g : BraidGroup n →* G} (h : ∀ i, f (σ i) = g (σ i)) : f = g :=
  PresentedGroup.ext h

/-- Every homomorphism gives a braid system. -/
theorem isBraidSystem (f : BraidGroup n →* G) : IsBraidSystem (fun i => f (σ i)) where
  far_comm i j h := by simpa only [map_mul] using congrArg f (far_comm i j h)
  braid_relation i j h := by simpa only [map_mul] using congrArg f (braid_relation i j h)

@[simp] theorem lift_comp_σ (f : BraidGroup n →* G) :
    lift (fun i => f (σ i)) (isBraidSystem f) = f := by ext i; simp

/-- The full universal property as an equivalence of types. -/
def homEquiv : (BraidGroup n →* G) ≃ {f : Generator n → G // IsBraidSystem f} where
  toFun f := ⟨fun i => f (σ i), isBraidSystem f⟩
  invFun f := lift f.val f.property
  left_inv f := lift_comp_σ f
  right_inv f := by apply Subtype.ext; funext i; simp

/-- The standard generators generate the whole group. -/
theorem closure_range_σ : Subgroup.closure (Set.range (σ (n := n))) = ⊤ :=
  PresentedGroup.closure_range_of _

/-- Induction using the identity, signed generators, and products. -/
@[elab_as_elim] theorem induction_on {P : BraidGroup n → Prop} (b : BraidGroup n)
    (one : P 1) (gen : ∀ i, P (σ i)) (inv : ∀ b, P b → P b⁻¹)
    (mul : ∀ a b, P a → P b → P (a * b)) : P b := by
  apply PresentedGroup.induction_on b
  intro w
  induction w with
  | C1 => exact one
  | of i => exact gen i
  | inv_of i => exact inv _ (gen i)
  | mul u v hu hv => exact mul _ _ hu hv

end BraidGroup
