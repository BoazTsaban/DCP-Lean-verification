import BraidGroup.ExponentSum
import BraidGroup.Permutation

/-! # Zero, one, and two strands, and noncommutativity with three or more strands -/
namespace BraidGroup

/-- With at most one strand, every braid is the identity. -/
theorem eq_one_of_le_one {n : ℕ} (h : n ≤ 1) (b : BraidGroup n) : b = 1 := by
  refine induction_on b rfl ?_ ?_ ?_
  · intro i
    have := i.isLt
    omega
  · intro a ha
    simp [ha]
  · intro a b ha hb
    simp [ha, hb]

instance subsingleton_zero : Subsingleton (BraidGroup 0) :=
  ⟨fun a b => (eq_one_of_le_one (by omega) a).trans (eq_one_of_le_one (by omega) b).symm⟩

instance subsingleton_one : Subsingleton (BraidGroup 1) :=
  ⟨fun a b => (eq_one_of_le_one (by omega) a).trans (eq_one_of_le_one (by omega) b).symm⟩

/-- The braid group on two strands is infinite cyclic. -/
def twoEquiv : BraidGroup 2 ≃* Multiplicative ℤ where
  toFun := exponentSum
  invFun := cyclicSection (0 : Generator 2)
  left_inv b := by
    have h : (cyclicSection (0 : Generator 2)).comp exponentSum =
        MonoidHom.id (BraidGroup 2) := by
      ext i
      have hi : i = 0 := by apply Fin.ext; have := i.isLt; omega
      subst i
      change σ (0 : Generator 2) ^ Multiplicative.toAdd (exponentSum (σ 0)) = σ 0
      simp
    exact DFunLike.congr_fun h b
  right_inv := exponentSum_cyclicSection _
  map_mul' := exponentSum.map_mul

@[simp] theorem twoEquiv_σ : twoEquiv (σ (0 : Generator 2)) = Multiplicative.ofAdd 1 := rfl

theorem two_mul_comm (a b : BraidGroup 2) : a * b = b * a :=
  twoEquiv.injective (by simp [map_mul, mul_comm])

/-- The first two crossings do not commute once there are at least three strands. -/
theorem first_two_not_commute (n : ℕ) :
    σ (⟨0, by omega⟩ : Generator (n + 3)) * σ ⟨1, by omega⟩ ≠
      σ (⟨1, by omega⟩ : Generator (n + 3)) * σ ⟨0, by omega⟩ := by
  intro h
  have hp := congrArg permutation h
  have hx := congrArg (fun p : Equiv.Perm (Fin (n + 3)) => (p ⟨0, by omega⟩).val) hp
  simp [map_mul, adjacentSwap, leftStrand, rightStrand, Equiv.swap_apply_def,
    Equiv.Perm.mul_apply, Fin.ext_iff] at hx

end BraidGroup
