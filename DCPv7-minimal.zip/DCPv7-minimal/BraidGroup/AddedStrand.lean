import BraidGroup.Literature

/-! # The added-strand center-intersection lemma

The proof follows DCPv3's strand-deletion route. Center classification and the
geometric deletion facts are named literature axioms; the conclusion itself is
proved, using the already checked infinite-order two-strand crossing.
-/
namespace BraidGroup

/-- The center in the larger group meets the embedded smaller group trivially. -/
theorem addedStrand_center_intersection (n : ℕ) (hn : 2 ≤ n) :
    Subgroup.center (BraidGroup (n + 1)) ⊓ (inclusion (Nat.le_succ n)).range = ⊥ := by
  apply le_antisymm _ bot_le
  intro z hz
  have hzpow : z ∈ Subgroup.zpowers (fullTwist (n + 1)) := by
    rw [← Literature.center_generated_fullTwist (n + 1) (by omega)]
    exact hz.1
  obtain ⟨q, hq⟩ := Subgroup.mem_zpowers_iff.mp hzpow
  have hpure : fullTwist (n + 1) ^ q ∈ pure (n + 1) :=
    (pure (n + 1)).zpow_mem (Literature.fullTwist_pure _) q
  let t : PureBraidGroup (n + 1) := ⟨fullTwist (n + 1), Literature.fullTwist_pure _⟩
  have htp : (t ^ q : PureBraidGroup (n + 1)) = ⟨fullTwist (n + 1) ^ q, hpure⟩ :=
    Subtype.ext rfl
  have he := Literature.deleteEnds_embedded n (by omega) (t ^ q) (by
    change fullTwist (n + 1) ^ q ∈ (inclusion (Nat.le_succ n)).range
    rw [hq]
    exact hz.2)
  rw [map_zpow, Literature.deleteEnds_fullTwist] at he
  have heInt := congrArg writhe he
  simp at heInt
  have hq0 : q = 0 := by omega
  have hz1 : z = 1 := by simpa [hq0] using hq.symm
  exact hz1

/-- The literature's subgroup equality gives the exact factor form used by the reduction. -/
theorem parabolic_hasDoubleCentralizer (N : ℕ) (hN : 3 ≤ N)
    (A : Subgroup (BraidGroup N)) (hA : IsParabolic A) : GroupDCP.HasDoubleCentralizer A := by
  intro x
  rw [Literature.doubleCentralizer N hN A hA, Subgroup.mem_sup_of_normal_left]
  exact exists_congr fun z => and_congr_right fun _ =>
    exists_congr fun a => and_congr_right fun _ => eq_comm

/-- The two conclusions of DCPv3 Lemma `lem:added-strand`. -/
theorem addedStrand_lemma (n : ℕ) (hn : 2 ≤ n) :
    Subgroup.center (BraidGroup (n + 1)) ⊓ (inclusion (Nat.le_succ n)).range = ⊥ ∧
    ∀ A : Subgroup (BraidGroup n), IsParabolic A →
      IsParabolic (A.map (inclusion (Nat.le_succ n))) :=
  ⟨addedStrand_center_intersection n hn, inclusion_isParabolic (Nat.le_succ n)⟩

end BraidGroup
