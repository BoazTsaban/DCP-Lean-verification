import BraidGroup.DoubleCoset

/-! # The ambient reduction with additional commuting constraints -/
namespace GroupDCP
variable {G : Type*} [Group G]

def ConstrainedDoubleCoset (A B : Subgroup G) (U V : Set G) (g h : G) : Prop :=
  ∃ a ∈ A, ∃ b ∈ B, h = a * g * b ∧
    a ∈ Subgroup.centralizer U ∧ b ∈ Subgroup.centralizer V

def ConstrainedSolves (c d : List G) (U V : Set G) (g h x : G) : Prop :=
  Solves c d g h x ∧ (∀ u ∈ U, x⁻¹ * u * x = u) ∧
    ∀ v ∈ V, x⁻¹ * (h * v * h⁻¹) * x = g * v * g⁻¹

/-- Removing a central factor does not change centralization of a prescribed set. -/
theorem central_mul_mem_centralizer_iff (z : G) (hz : z ∈ Subgroup.center G)
    (a : G) (U : Set G) : z * a ∈ Subgroup.centralizer U ↔ a ∈ Subgroup.centralizer U := by
  have hzU := Subgroup.center_le_centralizer U hz
  constructor
  · intro h
    have he : a = z⁻¹ * (z * a) := by group
    rw [he]
    exact (Subgroup.centralizer U).mul_mem ((Subgroup.centralizer U).inv_mem hzU) h
  · exact fun h => (Subgroup.centralizer U).mul_mem hzU h

/-- DCPv3's commuting-condition extension, with complete factor witnesses. -/
theorem constrained_ambient_reduction (A B H : Subgroup G) (hAH : A ≤ H) (hBH : B ≤ H)
    (c d : List G) (hc : Generates c (Subgroup.centralizer (A : Set G)))
    (hd : Generates d (Subgroup.centralizer (B : Set G)))
    (hA : HasDoubleCentralizer A) (hB : HasDoubleCentralizer B)
    (hcenter : Subgroup.center G ⊓ H = ⊥) (U V : Set G)
    (g h : G) (hg : g ∈ H) (hh : h ∈ H) :
    (∃ x, ConstrainedSolves c d U V g h x) ↔ ConstrainedDoubleCoset A B U V g h := by
  constructor
  · rintro ⟨x, hx, hU, hV⟩
    have hxy := (solves_iff_centralizers c d _ _ hc hd g h x).mp hx
    rcases (hA x).mp hxy.1 with ⟨zA, hzA, a, ha, hxa⟩
    rcases (hB (g⁻¹ * x⁻¹ * h)).mp hxy.2 with ⟨zB, hzB, b, hb, hyb⟩
    have hxU : x ∈ Subgroup.centralizer U := fun u hu => (fixed_conjugation_iff x u).mp (hU u hu)
    have hyV : g⁻¹ * x⁻¹ * h ∈ Subgroup.centralizer V := fun v hv =>
      (forward_conjugation_iff _ v).mp ((transported_conjugation_iff g h x v).mp (hV v hv))
    have haU : a ∈ Subgroup.centralizer U :=
      (central_mul_mem_centralizer_iff zA hzA a U).mp (hxa ▸ hxU)
    have hbV : b ∈ Subgroup.centralizer V :=
      (central_mul_mem_centralizer_iff zB hzB b V).mp (hyb ▸ hyV)
    have hrec : h = x * g * (g⁻¹ * x⁻¹ * h) := by group
    rw [hyb, hxa] at hrec
    have hzb : (a * g) * zB = zB * (a * g) := Subgroup.mem_center_iff.mp hzB _
    have he : h = (zA * zB) * (a * g * b) := by
      calc
        h = (zA * a) * g * (zB * b) := hrec
        _ = zA * ((a * g) * zB) * b := by group
        _ = zA * (zB * (a * g)) * b := by rw [hzb]
        _ = (zA * zB) * (a * g * b) := by group
    have habH := H.mul_mem (H.mul_mem (hAH ha) hg) (hBH hb)
    have hzH : zA * zB ∈ H := by
      have he' : zA * zB = h * (a * g * b)⁻¹ := by rw [he]; group
      rw [he']; exact H.mul_mem hh (H.inv_mem habH)
    have hz1 : zA * zB = 1 := by
      have hm : zA * zB ∈ Subgroup.center G ⊓ H := ⟨(Subgroup.center G).mul_mem hzA hzB, hzH⟩
      rw [hcenter] at hm
      exact hm
    exact ⟨a, ha, b, hb, by simpa only [hz1, one_mul] using he, haU, hbV⟩
  · rintro ⟨a, ha, b, hb, rfl, haU, hbV⟩
    refine ⟨a, factorization_solves A B c d hc hd g a b ha hb, ?_, ?_⟩
    · intro u hu; exact (fixed_conjugation_iff a u).mpr (haU u hu)
    · intro v hv
      apply (transported_conjugation_iff g (a * g * b) a v).mpr
      have hy : g⁻¹ * a⁻¹ * (a * g * b) = b := by group
      rw [hy]
      exact (forward_conjugation_iff b v).mpr (hbV v hv)

/-- An injective homomorphism reflects prescribed commutation as well as factors. -/
theorem map_constrainedDoubleCoset_iff {K : Type*} [Group K] (f : G →* K)
    (hf : Function.Injective f) (A B : Subgroup G) (U V : Set G) (g h : G) :
    ConstrainedDoubleCoset (A.map f) (B.map f) (f '' U) (f '' V) (f g) (f h) ↔
      ConstrainedDoubleCoset A B U V g h := by
  constructor
  · rintro ⟨a, ha, b, hb, he, haU, hbV⟩
    rcases ha with ⟨a, ha, rfl⟩
    rcases hb with ⟨b, hb, rfl⟩
    refine ⟨a, ha, b, hb, hf (by simpa only [map_mul] using he), ?_, ?_⟩
    · intro u hu
      exact hf (by simpa only [map_mul] using haU (f u) ⟨u, hu, rfl⟩)
    · intro v hv
      exact hf (by simpa only [map_mul] using hbV (f v) ⟨v, hv, rfl⟩)
  · rintro ⟨a, ha, b, hb, he, haU, hbV⟩
    refine ⟨f a, ⟨a, ha, rfl⟩, f b, ⟨b, hb, rfl⟩,
      by simpa only [map_mul] using congrArg f he, ?_, ?_⟩
    · rintro _ ⟨u, hu, rfl⟩
      simpa only [map_mul] using congrArg f (haU u hu)
    · rintro _ ⟨v, hv, rfl⟩
      simpa only [map_mul] using congrArg f (hbV v hv)

/-- Appending finite sets to the lists implements the extra equations literally. -/
theorem solves_append_iff (c d u v : List G) (g h x : G) :
    Solves (c ++ u) (d ++ v) g h x ↔
      ConstrainedSolves c d {z | z ∈ u} {z | z ∈ v} g h x := by
  constructor
  · rintro ⟨hc, hd⟩
    exact ⟨⟨fun z hz => hc z (List.mem_append_left u hz),
      fun z hz => hd z (List.mem_append_left v hz)⟩,
      fun z hz => hc z (List.mem_append_right c hz),
      fun z hz => hd z (List.mem_append_right d hz)⟩
  · rintro ⟨⟨hc, hd⟩, hu, hv⟩
    refine ⟨?_, ?_⟩
    · intro z hz
      exact (List.mem_append.mp hz).elim (hc z) (hu z)
    · intro z hz
      exact (List.mem_append.mp hz).elim (hd z) (hv z)

end GroupDCP
