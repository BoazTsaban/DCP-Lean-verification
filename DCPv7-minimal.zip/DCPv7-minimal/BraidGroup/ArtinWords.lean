import BraidGroup.ArtinGroup
import BraidGroup.SubgroupWords

namespace FiniteArtinGroup
open BraidGroup

/-- All spherical source and ambient types used by the manuscript. -/
def Supported (X : Diagram) : Prop :=
  (X.1 = 0 ∧ 2 ≤ X.2) ∨ (X.1 = 1 ∧ 4 ≤ X.2) ∨
  (X.1 = 2 ∧ (X.2 = 6 ∨ X.2 = 7 ∨ X.2 = 8)) ∨
  (X.1 = 3 ∧ (X.2 = 2 ∨ X.2 = 3 ∨ X.2 = 4))

def rawLetter (X : Diagram) (l : RawLetter) : OfDiagram X :=
  if hi : l.1 < X.2 then
    if l.2 then generator ⟨l.1, hi⟩ else (generator ⟨l.1, hi⟩)⁻¹
  else 1

def rawEval (X : Diagram) (w : RawWord) : OfDiagram X := (w.map (rawLetter X)).prod

def rawSubgroup (X : Diagram) (s : List RawWord) : Subgroup (OfDiagram X) :=
  Subgroup.closure {z | z ∈ s.map (rawEval X)}

def InstanceValid (X : Diagram) (e : RawInstance) : Prop :=
  ∀ q ∈ e, RawValid (X.2 + 1) q.1 ∧ RawValid (X.2 + 1) q.2

def InstanceSolvable (X : Diagram) (e : RawInstance) : Prop :=
  ∃ x : OfDiagram X, ∀ q ∈ e, x⁻¹ * rawEval X q.1 * x = rawEval X q.2

end FiniteArtinGroup

namespace FiniteArtinGroup
open BraidGroup

@[simp] theorem rawEval_nil (X : Diagram) : rawEval X [] = 1 := rfl
@[simp] theorem rawEval_cons (X : Diagram) (l : RawLetter) (w : RawWord) :
    rawEval X (l :: w) = rawLetter X l * rawEval X w := rfl
@[simp] theorem rawEval_append (X : Diagram) (u v : RawWord) :
    rawEval X (u ++ v) = rawEval X u * rawEval X v := by simp [rawEval]

@[simp] theorem rawLetter_flip (X : Diagram) (l : RawLetter) :
    rawLetter X (l.1, !l.2) = (rawLetter X l)⁻¹ := by
  rcases l with ⟨i, s⟩
  by_cases h : i < X.2 <;> cases s <;> simp [rawLetter, h]

@[simp] theorem rawEval_inverse (X : Diagram) (w : RawWord) :
    rawEval X (rawInverse w) = (rawEval X w)⁻¹ := by
  induction w with
  | nil => simp [rawInverse]
  | cons l w ih =>
    have he : rawInverse (l :: w) = rawInverse w ++ [(l.1, !l.2)] := by simp [rawInverse]
    rw [he]
    simp [ih, mul_inv_rev]

@[simp] theorem rawEval_conjugate (X : Diagram) (w v : RawWord) :
    rawEval X (rawConjugate w v) = rawEval X w * rawEval X v * (rawEval X w)⁻¹ := by
  simp [rawConjugate, mul_assoc]

@[simp] theorem rawEval_substitute_flip (X : Diagram) (s : List RawWord) (l : RawLetter) :
    rawEval X (substituteChunk s (l.1, !l.2)) = (rawEval X (substituteChunk s l))⁻¹ := by
  rcases l with ⟨i, b⟩
  cases b <;> simp [substituteChunk]

@[simp] theorem rawEval_substitute_inverse (X : Diagram) (s : List RawWord) (w : RawWord) :
    rawEval X (substitute s (rawInverse w)) = (rawEval X (substitute s w))⁻¹ := by
  induction w with
  | nil => simp [rawInverse]
  | cons l w ih =>
    have he : rawInverse (l :: w) = rawInverse w ++ [(l.1, !l.2)] := by simp [rawInverse]
    rw [he]
    simp [ih, mul_inv_rev]

/-- Every subgroup element is represented by a word in the supplied generators. -/
theorem subgroupWord_exists (X : Diagram) (s : List RawWord) {a : OfDiagram X}
    (ha : a ∈ rawSubgroup X s) :
    ∃ w, SubgroupWordValid s w ∧ rawEval X (substitute s w) = a := by
  induction ha using Subgroup.closure_induction with
  | mem x hx =>
    rcases List.mem_map.mp hx with ⟨u, hu, rfl⟩
    rcases List.mem_iff_getElem.mp hu with ⟨i, hi, he⟩
    refine ⟨[(i, true)], ?_, ?_⟩
    · simpa [SubgroupWordValid] using hi
    · simp only [substitute_cons, substitute_nil, substituteChunk, if_true, List.append_nil]
      rw [List.getD_eq_getElem s [] hi, he]
  | one => exact ⟨[], by simp, by simp⟩
  | mul x y hx hy ihx ihy =>
    rcases ihx with ⟨u, hu, heu⟩
    rcases ihy with ⟨v, hv, hev⟩
    exact ⟨u ++ v, (subgroupWordValid_append s u v).mpr ⟨hu, hv⟩, by simp [heu, hev]⟩
  | inv x hx ih =>
    rcases ih with ⟨u, hu, heu⟩
    exact ⟨rawInverse u, (subgroupWordValid_inverse s u).mpr hu, by simp [heu]⟩

/-- A valid word in the supplied subgroup generators evaluates into that subgroup. -/
theorem substitute_mem (X : Diagram) (s : List RawWord) (w : RawWord)
    (hw : SubgroupWordValid s w) : rawEval X (substitute s w) ∈ rawSubgroup X s := by
  induction w with
  | nil => simp only [substitute_nil, rawEval_nil]; exact (rawSubgroup X s).one_mem
  | cons l w ih =>
    have hl := hw l (by simp)
    have ht : SubgroupWordValid s w := fun k hk => hw k (by simp [hk])
    have hm : rawEval X (s.getD l.1 []) ∈ rawSubgroup X s := by
      rw [List.getD_eq_getElem s [] hl]
      exact Subgroup.subset_closure (List.mem_map.mpr ⟨_, List.getElem_mem hl, rfl⟩)
    rw [substitute_cons, rawEval_append]
    apply (rawSubgroup X s).mul_mem _ (ih ht)
    rcases l with ⟨i, b⟩
    cases b
    · simpa only [substituteChunk, Bool.false_eq_true, if_false, rawEval_inverse] using
        (rawSubgroup X s).inv_mem hm
    · simpa only [substituteChunk, if_true] using hm


end FiniteArtinGroup
