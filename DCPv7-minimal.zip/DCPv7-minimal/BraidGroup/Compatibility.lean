import BraidGroup.Operations
import BraidGroup.ExponentSum
import BraidGroup.Permutation
import Mathlib.Algebra.Ring.Int.Parity

/-! # Compatibility of braid operations with exponent sum and permutation -/
namespace BraidGroup

variable {n m : ℕ}

@[simp] theorem exponentSum_mirror (b : BraidGroup n) :
    exponentSum (mirror b) = (exponentSum b)⁻¹ := by
  change exponentSum (mirrorHom (n := n) b) = (exponentSum b)⁻¹
  have h : exponentSum.comp (mirrorHom (n := n)) =
      (zpowGroupHom (-1) : Multiplicative ℤ →* Multiplicative ℤ).comp exponentSum := by ext i; simp
  simpa only [MonoidHom.comp_apply, zpowGroupHom_apply, zpow_neg_one] using DFunLike.congr_fun h b

@[simp] theorem writhe_mirror (b : BraidGroup n) : writhe (mirror b) = -writhe b := by
  simp [writhe]

@[simp] theorem exponentSum_reverse (b : BraidGroup n) :
    exponentSum (reverse b) = exponentSum b := by
  have h : exponentSum.comp (reverseHom (n := n)) = exponentSum := by ext i; simp
  exact DFunLike.congr_fun h b

@[simp] theorem writhe_reverse (b : BraidGroup n) : writhe (reverse b) = writhe b := by
  simp [writhe]

@[simp] theorem exponentSum_inclusion (h : n ≤ m) (b : BraidGroup n) :
    exponentSum (inclusion h b) = exponentSum b := by
  have he : exponentSum.comp (inclusion h) = exponentSum := by ext i; simp
  exact DFunLike.congr_fun he b

@[simp] theorem writhe_inclusion (h : n ≤ m) (b : BraidGroup n) :
    writhe (inclusion h b) = writhe b := by simp [writhe]

@[simp] theorem exponentSum_shift (b : BraidGroup n) : exponentSum (shift b) = exponentSum b := by
  have h : exponentSum.comp (shift (n := n)) = exponentSum := by ext i; simp
  exact DFunLike.congr_fun h b

@[simp] theorem writhe_shift (b : BraidGroup n) : writhe (shift b) = writhe b := by simp [writhe]

@[simp] theorem permutation_mirror (b : BraidGroup n) : permutation (mirror b) = permutation b := by
  have h : permutation.comp (mirrorHom (n := n)) = permutation := by ext i; simp
  exact DFunLike.congr_fun h b

@[simp] theorem mirror_mem_pure_iff (b : BraidGroup n) : mirror b ∈ pure n ↔ b ∈ pure n := by simp

@[simp] theorem mirror_mem_exponentKernel_iff (b : BraidGroup n) :
    mirror b ∈ exponentKernel n ↔ b ∈ exponentKernel n := by simp

@[simp] theorem reverse_mem_exponentKernel_iff (b : BraidGroup n) :
    reverse b ∈ exponentKernel n ↔ b ∈ exponentKernel n := by simp

/-- Permutation sign is determined by exponent sum. -/
theorem sign_permutation (b : BraidGroup n) :
    Equiv.Perm.sign (permutation b) = (-1 : ℤˣ) ^ writhe b := by
  have h : Equiv.Perm.sign.comp (permutation (n := n)) =
      (zpowersHom ℤˣ (-1)).comp exponentSum := by
    ext i
    simp [adjacentSwap, leftStrand_ne_rightStrand]
  exact DFunLike.congr_fun h b

/-- A pure braid always has even exponent sum. -/
theorem even_writhe_of_mem_pure (b : BraidGroup n) (hb : b ∈ pure n) : Even (writhe b) := by
  by_contra he
  have ho := Int.not_even_iff_odd.mp he
  have hs := sign_permutation b
  rw [(mem_pure b).mp hb, map_one, ho.neg_one_zpow] at hs
  have hv := congrArg (fun u : ℤˣ => (u : ℤ)) hs
  norm_num at hv

end BraidGroup
