import BraidGroup.Basic
import Mathlib.GroupTheory.Perm.Sign
import Mathlib.GroupTheory.QuotientGroup.Basic

/-! # The permutation of strands and the pure braid subgroup -/
namespace BraidGroup

variable {n : ℕ}

/-- The left strand involved in a standard crossing. -/
def leftStrand (i : Generator n) : Fin n := ⟨i.val, by have := i.isLt; omega⟩
/-- The right strand involved in a standard crossing. -/
def rightStrand (i : Generator n) : Fin n := ⟨i.val + 1, by have := i.isLt; omega⟩

@[simp] theorem leftStrand_val (i : Generator n) : (leftStrand i).val = i.val := rfl
@[simp] theorem rightStrand_val (i : Generator n) : (rightStrand i).val = i.val + 1 := rfl

theorem leftStrand_ne_rightStrand (i : Generator n) : leftStrand i ≠ rightStrand i := by
  intro h
  have := congrArg Fin.val h
  simp at this

/-- The adjacent transposition associated to a standard crossing. -/
def adjacentSwap (i : Generator n) : Equiv.Perm (Fin n) :=
  Equiv.swap (leftStrand i) (rightStrand i)

/-- Adjacent transpositions satisfy the braid relations. -/
theorem adjacentSwap_isBraidSystem : IsBraidSystem (adjacentSwap (n := n)) where
  far_comm i j h := by
    apply (Equiv.Perm.disjoint_swap_swap (x := leftStrand i) (y := rightStrand i)
      (z := leftStrand j) (t := rightStrand j) ?_).commute.eq
    simp [Fin.ext_iff, leftStrand, rightStrand]
    rcases h with h | h <;> omega
  braid_relation i j h := by
    have hab := leftStrand_ne_rightStrand i
    have hbc := leftStrand_ne_rightStrand j
    have hmid : rightStrand i = leftStrand j := by
      apply Fin.ext
      exact h
    have hac : leftStrand i ≠ rightStrand j := by
      intro he
      have := congrArg Fin.val he
      simp only [leftStrand_val, rightStrand_val, Adjacent] at *
      omega
    have h₁ := Equiv.swap_mul_swap_mul_swap (x := rightStrand j)
      (y := leftStrand j) (z := leftStrand i) hbc.symm hac.symm
    have h₂ := Equiv.swap_mul_swap_mul_swap (x := leftStrand i)
      (y := leftStrand j) (z := rightStrand j) (hmid ▸ hab) hac
    simpa only [adjacentSwap, hmid, Equiv.swap_comm] using h₁.trans ((Equiv.swap_comm _ _).trans h₂.symm)

/-- Forget crossings and retain the permutation of strand endpoints. -/
def permutation : BraidGroup n →* Equiv.Perm (Fin n) :=
  lift adjacentSwap adjacentSwap_isBraidSystem

@[simp] theorem permutation_σ (i : Generator n) : permutation (σ i) = adjacentSwap i := by
  simp [permutation]

@[simp] theorem permutation_σ_inv (i : Generator n) : permutation (σ i)⁻¹ = adjacentSwap i := by
  simp [adjacentSwap]

/-- Every permutation of strand endpoints is realized by a braid. -/
theorem permutation_surjective (n : ℕ) : Function.Surjective (permutation (n := n)) := by
  cases n with
  | zero =>
    intro p
    exact ⟨1, by simp; exact Subsingleton.elim _ _⟩
  | succ n =>
    apply MonoidHom.range_eq_top.mp
    have hgen : Subgroup.closure (Set.range (adjacentSwap (n := n + 1))) = ⊤ := by
      have he : (adjacentSwap (n := n + 1)) =
          (fun i : Fin n => Equiv.swap i.castSucc i.succ) := by
        funext i
        rfl
      rw [he]
      exact Subgroup.closure_eq_top_of_mclosure_eq_top
        (Equiv.Perm.mclosure_swap_castSucc_succ n)
    apply top_unique
    rw [← hgen]
    rw [Subgroup.closure_le]
    rintro _ ⟨i, rfl⟩
    exact ⟨σ i, permutation_σ i⟩

/-- Pure braids are precisely those with trivial strand permutation. -/
def pure (n : ℕ) : Subgroup (BraidGroup n) := (permutation (n := n)).ker

instance pure_normal : (pure n).Normal := inferInstanceAs
  (MonoidHom.ker (permutation (n := n))).Normal

@[simp] theorem mem_pure (b : BraidGroup n) : b ∈ pure n ↔ permutation b = 1 := Iff.rfl

/-- The quotient of the braid group by the pure braid subgroup is the symmetric group. -/
noncomputable def quotientPureEquiv (n : ℕ) :
    BraidGroup n ⧸ pure n ≃* Equiv.Perm (Fin n) :=
  QuotientGroup.quotientKerEquivOfSurjective permutation (permutation_surjective n)

@[simp] theorem σ_sq_mem_pure (i : Generator n) : σ i ^ 2 ∈ pure n := by
  simp [adjacentSwap, pow_two]

theorem σ_not_mem_pure (i : Generator n) : σ i ∉ pure n := by
  simpa [adjacentSwap, Equiv.swap_eq_one_iff] using leftStrand_ne_rightStrand i

/-- Any conjugate of a square of a standard generator is pure. -/
theorem conjugate_sq_mem_pure (b : BraidGroup n) (i : Generator n) :
    b * σ i ^ 2 * b⁻¹ ∈ pure n := by
  simp only [mem_pure, map_mul, map_inv]
  have hi : permutation (σ i ^ 2) = 1 := σ_sq_mem_pure i
  rw [hi, mul_one, mul_inv_cancel]

end BraidGroup
