import BraidGroup.Basic
import Mathlib.Algebra.Group.Subgroup.ZPowers.Basic
import Mathlib.GroupTheory.QuotientGroup.Basic

/-! # Exponent sum, infinite-order generators, and cyclic sections -/
namespace BraidGroup

variable {n : ℕ}

/-- Sending every standard generator to the same group element respects the relations. -/
theorem constant_isBraidSystem {G : Type*} [Group G] (g : G) :
    IsBraidSystem (n := n) (fun _ => g) := ⟨fun _ _ _ => rfl, fun _ _ _ => rfl⟩

/-- The homomorphism sending each standard generator to `g`. -/
def constantHom {G : Type*} [Group G] (g : G) : BraidGroup n →* G :=
  lift (fun _ => g) (constant_isBraidSystem g)

@[simp] theorem constantHom_σ {G : Type*} [Group G] (g : G) (i : Generator n) :
    constantHom g (σ i) = g := lift_σ _ _ _

/-- The exponent-sum homomorphism, with integers written multiplicatively. -/
def exponentSum : BraidGroup n →* Multiplicative ℤ := constantHom (Multiplicative.ofAdd 1)

/-- The signed total number of crossings. -/
def writhe (b : BraidGroup n) : ℤ := Multiplicative.toAdd (exponentSum b)

@[simp] theorem exponentSum_σ (i : Generator n) :
    exponentSum (σ i) = Multiplicative.ofAdd 1 := constantHom_σ _ _

@[simp] theorem writhe_σ (i : Generator n) : writhe (σ i) = 1 := rfl
@[simp] theorem writhe_one : writhe (1 : BraidGroup n) = 0 := by simp [writhe]
@[simp] theorem writhe_mul (a b : BraidGroup n) : writhe (a * b) = writhe a + writhe b := by
  simp [writhe]
@[simp] theorem writhe_inv (a : BraidGroup n) : writhe a⁻¹ = -writhe a := by simp [writhe]
@[simp] theorem writhe_pow (a : BraidGroup n) (k : ℕ) : writhe (a ^ k) = k * writhe a := by
  simp [writhe]
@[simp] theorem writhe_zpow (a : BraidGroup n) (k : ℤ) : writhe (a ^ k) = k * writhe a := by
  simp [writhe]

/-- Integer powers of any standard generator provide a section of exponent sum. -/
def cyclicSection (i : Generator n) : Multiplicative ℤ →* BraidGroup n :=
  zpowersHom (BraidGroup n) (σ i)

@[simp] theorem cyclicSection_apply (i : Generator n) (k : Multiplicative ℤ) :
    cyclicSection i k = σ i ^ Multiplicative.toAdd k := rfl

@[simp] theorem writhe_cyclicSection (i : Generator n) (k : Multiplicative ℤ) :
    writhe (cyclicSection i k) = Multiplicative.toAdd k := by simp

@[simp] theorem exponentSum_cyclicSection (i : Generator n) (k : Multiplicative ℤ) :
    exponentSum (cyclicSection i k) = k := by
  apply Multiplicative.toAdd.injective
  exact writhe_cyclicSection i k

theorem exponentSum_surjective (i : Generator n) :
    Function.Surjective (exponentSum (n := n)) := fun k => ⟨cyclicSection i k, exponentSum_cyclicSection i k⟩

theorem cyclicSection_injective (i : Generator n) : Function.Injective (cyclicSection i) :=
  Function.LeftInverse.injective (exponentSum_cyclicSection i)

/-- Distinct integer powers of a standard generator are distinct braids. -/
theorem σ_zpow_injective (i : Generator n) : Function.Injective (fun k : ℤ => σ i ^ k) := by
  intro a b h
  have := congrArg writhe h
  simpa using this

theorem σ_ne_one (i : Generator n) : σ i ≠ 1 := by
  intro h
  have := congrArg writhe h
  simp at this

theorem σ_pow_ne_one (i : Generator n) {k : ℕ} (hk : k ≠ 0) : σ i ^ k ≠ 1 := by
  intro h
  have : (k : ℤ) = 0 := by simpa using congrArg writhe h
  exact hk (Int.ofNat_eq_zero.mp this)

theorem σ_zpow_eq_one_iff (i : Generator n) (k : ℤ) : σ i ^ k = 1 ↔ k = 0 := by
  constructor
  · intro h; simpa using congrArg writhe h
  · rintro rfl; simp

instance infinite (n : ℕ) : Infinite (BraidGroup (n + 2)) :=
  Infinite.of_injective (fun k : ℤ => σ (⟨0, by omega⟩ : Generator (n + 2)) ^ k)
    (σ_zpow_injective _)

/-- The subgroup of braids with exponent sum zero. -/
def exponentKernel (n : ℕ) : Subgroup (BraidGroup n) := (exponentSum (n := n)).ker

instance exponentKernel_normal : (exponentKernel n).Normal := inferInstanceAs
  (MonoidHom.ker (exponentSum (n := n))).Normal

@[simp] theorem mem_exponentKernel (b : BraidGroup n) :
    b ∈ exponentKernel n ↔ writhe b = 0 := by
  change exponentSum b = 1 ↔ Multiplicative.toAdd (exponentSum b) = 0
  exact Multiplicative.toAdd.injective.eq_iff.symm

/-- Quotienting by the exponent kernel gives the infinite cyclic group. -/
def quotientExponentEquiv (i : Generator n) :
    BraidGroup n ⧸ exponentKernel n ≃* Multiplicative ℤ :=
  QuotientGroup.quotientKerEquivOfRightInverse exponentSum (cyclicSection i)
    (exponentSum_cyclicSection i)

end BraidGroup
