import BraidGroup.DoubleCoset
import BraidGroup.Parabolic
import Mathlib.Algebra.Group.Subgroup.Finite

/-! # Double cosets in direct products and conjugated product subgroups -/
namespace GroupDCP
variable {ι : Type*} {G : ι → Type*} [∀ i, Group (G i)]

def productSubgroup (A : ∀ i, Subgroup (G i)) : Subgroup (∀ i, G i) := Subgroup.pi Set.univ A

@[simp] theorem mem_productSubgroup (A : ∀ i, Subgroup (G i)) (x : ∀ i, G i) :
    x ∈ productSubgroup A ↔ ∀ i, x i ∈ A i := by simp [productSubgroup, Subgroup.mem_pi]

/-- Product double-coset membership is exactly coordinatewise membership. -/
theorem product_doubleCoset_iff (A B : ∀ i, Subgroup (G i)) (g h : ∀ i, G i) :
    InDoubleCoset (productSubgroup A) (productSubgroup B) g h ↔
      ∀ i, InDoubleCoset (A i) (B i) (g i) (h i) := by
  constructor
  · rintro ⟨a, ha, b, hb, he⟩ i
    exact ⟨a i, (mem_productSubgroup A a).mp ha i, b i,
      (mem_productSubgroup B b).mp hb i, congrFun he i⟩
  · intro hi
    classical
    choose a ha b hb he using hi
    exact ⟨a, (mem_productSubgroup A a).mpr ha, b, (mem_productSubgroup B b).mpr hb,
      funext he⟩

/-- Conjugating a product subgroup acts coordinatewise. -/
theorem conjugate_productSubgroup (a : ∀ i, G i) (A : ∀ i, Subgroup (G i)) :
    BraidGroup.conjugateSubgroup a (productSubgroup A) =
      productSubgroup (fun i => BraidGroup.conjugateSubgroup (a i) (A i)) := by
  ext x
  constructor
  · rintro ⟨y, hy, rfl⟩
    apply (mem_productSubgroup _ _).mpr
    intro i
    exact ⟨y i, (mem_productSubgroup A y).mp hy i, rfl⟩
  · intro hx
    classical
    have hs := (mem_productSubgroup _ _).mp hx
    choose y hy he using hs
    exact ⟨y, (mem_productSubgroup A y).mpr hy, funext he⟩

/-- The union of coordinate-supported generating sets in a finite direct product. -/
def axesGenerators [DecidableEq ι] (S : ∀ i, Set (G i)) : Set (∀ i, G i) :=
  {x | ∃ i, ∃ y ∈ S i, x = Pi.mulSingle i y}

/-- A subset of the union of factor generators generates the product of its coordinate closures. -/
theorem closure_axes [Finite ι] [DecidableEq ι] (S : ∀ i, Set (G i)) :
    Subgroup.closure (axesGenerators S) = productSubgroup (fun i => Subgroup.closure (S i)) := by
  apply le_antisymm
  · rw [Subgroup.closure_le]
    rintro _ ⟨i, y, hy, rfl⟩
    exact Subgroup.mulSingle_mem_pi i y |>.mpr (fun _ => Subgroup.subset_closure hy)
  · rw [productSubgroup, Subgroup.pi_le_iff]
    intro i
    rw [MonoidHom.map_closure, Subgroup.closure_le]
    rintro _ ⟨y, hy, rfl⟩
    exact Subgroup.subset_closure ⟨i, y, hy, rfl⟩

/-- Each factor is the image of the product subgroup under the coordinate projection. -/
theorem productSubgroup_projection [DecidableEq ι] (A : ∀ i, Subgroup (G i)) (i : ι) :
    (productSubgroup A).map (Pi.evalMonoidHom G i) = A i := by
  ext x
  constructor
  · rintro ⟨y, hy, rfl⟩
    exact (mem_productSubgroup A y).mp hy i
  · intro hx
    refine ⟨Pi.mulSingle i x, ?_, ?_⟩
    · exact Subgroup.mulSingle_mem_pi i x |>.mpr (fun _ => hx)
    · simp

/-- A conjugate of a standard product parabolic is exactly a product of conjugate factor parabolics. -/
theorem conjugate_closure_axes [Finite ι] [DecidableEq ι] (S : ∀ i, Set (G i))
    (a : ∀ i, G i) : BraidGroup.conjugateSubgroup a (Subgroup.closure (axesGenerators S)) =
      productSubgroup (fun i => BraidGroup.conjugateSubgroup (a i) (Subgroup.closure (S i))) := by
  rw [closure_axes, conjugate_productSubgroup]

end GroupDCP
