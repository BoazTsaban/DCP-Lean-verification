import BraidGroup.Basic

/-! # Maps between braid groups and the mirror automorphism -/
namespace BraidGroup

variable {n m k : ℕ}

/-- A map of generator indices preserving distant pairs and adjacent pairs
(the latter may have their order reversed). -/
structure IndexMap (n m : ℕ) where
  toFun : Generator n → Generator m
  far : ∀ i j, Far i j → Far (toFun i) (toFun j)
  adjacent : ∀ i j, Adjacent i j →
    Adjacent (toFun i) (toFun j) ∨ Adjacent (toFun j) (toFun i)

/-- The homomorphism induced by a relation-preserving map of generator indices. -/
def map (f : IndexMap n m) : BraidGroup n →* BraidGroup m :=
  lift (fun i => σ (f.toFun i)) {
    far_comm := fun i j h => far_comm _ _ (f.far i j h)
    braid_relation := fun i j h => by
      rcases f.adjacent i j h with h | h
      · exact braid_relation _ _ h
      · exact (braid_relation _ _ h).symm }

@[simp] theorem map_σ (f : IndexMap n m) (i : Generator n) :
    map f (σ i) = σ (f.toFun i) := by simp [map]

/-- Add unused strands on the right. This definition alone makes no injectivity claim. -/
def inclusionIndex (h : n ≤ m) : IndexMap n m where
  toFun i := ⟨i.val, by have := i.isLt; omega⟩
  far _ _ h := h
  adjacent _ _ h := Or.inl h

/-- The standard homomorphism adding strands on the right. -/
def inclusion (h : n ≤ m) : BraidGroup n →* BraidGroup m := map (inclusionIndex h)

@[simp] theorem inclusion_σ (h : n ≤ m) (i : Generator n) :
    inclusion h (σ i) = σ ⟨i.val, by have := i.isLt; omega⟩ := by simp [inclusion, inclusionIndex]

@[simp] theorem inclusion_refl : inclusion (le_refl n) = MonoidHom.id (BraidGroup n) := by
  ext i
  simp

@[simp] theorem inclusion_comp (h : n ≤ m) (h' : m ≤ k) :
    (inclusion h').comp (inclusion h) = inclusion (h.trans h') := by ext i; simp

/-- Add one unused strand on the left. -/
def shiftIndex (n : ℕ) : IndexMap n (n + 1) where
  toFun i := ⟨i.val + 1, by have := i.isLt; omega⟩
  far i j h := by rcases h with h | h <;> simp only [Far] <;> omega
  adjacent i j h := Or.inl (by simp only [Adjacent] at *; omega)

/-- The standard homomorphism adding a strand on the left. -/
def shift : BraidGroup n →* BraidGroup (n + 1) := map (shiftIndex n)

@[simp] theorem shift_σ (i : Generator n) :
    shift (σ i) = σ ⟨i.val + 1, by have := i.isLt; omega⟩ := by simp [shift, shiftIndex]

/-- Inverting every crossing simultaneously respects the Artin relations. -/
theorem inverse_isBraidSystem : IsBraidSystem (fun i : Generator n => (σ i)⁻¹) where
  far_comm i j h := by
    have he := congrArg Inv.inv (far_comm i j h)
    simpa only [mul_inv_rev] using he.symm
  braid_relation i j h := by
    have he := congrArg Inv.inv (braid_relation i j h)
    simpa only [mul_inv_rev, mul_assoc] using he

/-- Mirror every crossing. Unlike group inversion, this is a homomorphism. -/
def mirrorHom : BraidGroup n →* BraidGroup n := lift _ inverse_isBraidSystem

@[simp] theorem mirrorHom_σ (i : Generator n) : mirrorHom (σ i) = (σ i)⁻¹ := by
  simp [mirrorHom]

@[simp] theorem mirrorHom_comp :
    (mirrorHom (n := n)).comp mirrorHom = MonoidHom.id (BraidGroup n) := by ext i; simp

theorem mirrorHom_involutive : Function.Involutive (mirrorHom (n := n)) := by
  intro b
  exact DFunLike.congr_fun mirrorHom_comp b

/-- The involutive mirror automorphism. -/
def mirror : BraidGroup n ≃* BraidGroup n where
  toFun := mirrorHom
  invFun := mirrorHom
  left_inv := mirrorHom_involutive
  right_inv := mirrorHom_involutive
  map_mul' := mirrorHom.map_mul

@[simp] theorem mirror_σ (i : Generator n) : mirror (σ i) = (σ i)⁻¹ := mirrorHom_σ i
@[simp] theorem mirror_mirror (b : BraidGroup n) : mirror (mirror b) = b := mirrorHom_involutive b

/-- Reverse the order of strand positions. -/
def reverseIndex (n : ℕ) : IndexMap n n where
  toFun := Fin.rev
  far i j h := by
    simp only [Far, Fin.val_rev] at *
    have := i.isLt
    have := j.isLt
    omega
  adjacent i j h := Or.inr (by
    simp only [Adjacent, Fin.val_rev] at *
    have := i.isLt
    have := j.isLt
    omega)

def reverseHom : BraidGroup n →* BraidGroup n := map (reverseIndex n)

@[simp] theorem reverseHom_σ (i : Generator n) : reverseHom (σ i) = σ i.rev := by
  simp [reverseHom, reverseIndex]

@[simp] theorem reverseHom_comp :
    (reverseHom (n := n)).comp reverseHom = MonoidHom.id (BraidGroup n) := by ext i; simp

theorem reverseHom_involutive : Function.Involutive (reverseHom (n := n)) := by
  intro b
  exact DFunLike.congr_fun reverseHom_comp b

/-- The automorphism reversing the order of strands. -/
def reverse : BraidGroup n ≃* BraidGroup n where
  toFun := reverseHom
  invFun := reverseHom
  left_inv := reverseHom_involutive
  right_inv := reverseHom_involutive
  map_mul' := reverseHom.map_mul

@[simp] theorem reverse_σ (i : Generator n) : reverse (σ i) = σ i.rev := reverseHom_σ i
@[simp] theorem reverse_reverse (b : BraidGroup n) : reverse (reverse b) = b := reverseHom_involutive b

theorem mirror_reverse (b : BraidGroup n) : mirror (reverse b) = reverse (mirror b) := by
  have h : (mirrorHom (n := n)).comp reverseHom = reverseHom.comp mirrorHom := by ext i; simp
  exact DFunLike.congr_fun h b

end BraidGroup
