import Mathlib.GroupTheory.Subgroup.Centralizer
import Mathlib.Tactic.Group

/-! # Double cosets and the ambient simultaneous-conjugacy reduction

This module proves the group-theoretic argument of DCPv3, Proposition
`prop:ambient-reduction` and Remark `rem:central-obstruction`. It uses real
Mathlib groups, subgroups, centralizers, and centers. No cyclicity is assumed.
-/
namespace GroupDCP

variable {G : Type*} [Group G]

/-- Membership in the double coset `A g B`, including explicit factor witnesses. -/
def InDoubleCoset (A B : Subgroup G) (g h : G) : Prop :=
  ∃ a ∈ A, ∃ b ∈ B, h = a * g * b

/-- Membership in `Z(G) A` with an explicit central and subgroup factor. -/
def CentralProduct (A : Subgroup G) (x : G) : Prop :=
  ∃ z ∈ Subgroup.center G, ∃ a ∈ A, x = z * a

/-- The precise double-centralizer property used in the manuscript. -/
def HasDoubleCentralizer (A : Subgroup G) : Prop :=
  ∀ x, x ∈ Subgroup.centralizer (Subgroup.centralizer (A : Set G) : Set G) ↔
    CentralProduct A x

/-- A finite list generates a specified subgroup. Empty lists are permitted. -/
def Generates (c : List G) (C : Subgroup G) : Prop :=
  Subgroup.closure {u | u ∈ c} = C

/-- The exact simultaneous conjugacy equations in DCPv3. -/
def Solves (c d : List G) (g h x : G) : Prop :=
  (∀ u ∈ c, x⁻¹ * u * x = u) ∧
  (∀ v ∈ d, x⁻¹ * (h * v * h⁻¹) * x = g * v * g⁻¹)

/-- The central enlargement of a double coset. -/
def InCentralDoubleCoset (A B : Subgroup G) (g h : G) : Prop :=
  ∃ z ∈ Subgroup.center G, ∃ a ∈ A, ∃ b ∈ B, h = z * (a * g * b)

theorem fixed_conjugation_iff (x u : G) : x⁻¹ * u * x = u ↔ u * x = x * u := by
  constructor
  · intro h
    calc
      u * x = x * (x⁻¹ * u * x) := by group
      _ = x * u := by rw [h]
  · intro h
    calc
      x⁻¹ * u * x = x⁻¹ * (u * x) := mul_assoc _ _ _
      _ = x⁻¹ * (x * u) := by rw [h]
      _ = u := by group

theorem forward_conjugation_iff (x u : G) : x * u * x⁻¹ = u ↔ u * x = x * u := by
  constructor
  · intro h
    calc
      u * x = (x * u * x⁻¹) * x := by rw [h]
      _ = x * u := by group
  · intro h
    calc
      x * u * x⁻¹ = (u * x) * x⁻¹ := by rw [h]
      _ = u := by group

/-- Finite generator equations imply centralization of the whole generated subgroup. -/
theorem fixes_generators_iff (c : List G) (C : Subgroup G) (hc : Generates c C) (x : G) :
    (∀ u ∈ c, x⁻¹ * u * x = u) ↔ x ∈ Subgroup.centralizer (C : Set G) := by
  rw [← hc, Subgroup.centralizer_closure]
  exact forall₂_congr (fun u _ => fixed_conjugation_iff x u)

/-- The second family of equations is equivalent to centralizing with `g⁻¹ x⁻¹ h`. -/
theorem transported_conjugation_iff (g h x v : G) :
    x⁻¹ * (h * v * h⁻¹) * x = g * v * g⁻¹ ↔
      (g⁻¹ * x⁻¹ * h) * v * (g⁻¹ * x⁻¹ * h)⁻¹ = v := by
  constructor
  · intro he
    calc
      (g⁻¹ * x⁻¹ * h) * v * (g⁻¹ * x⁻¹ * h)⁻¹ =
          g⁻¹ * (x⁻¹ * (h * v * h⁻¹) * x) * g := by group
      _ = g⁻¹ * (g * v * g⁻¹) * g := by rw [he]
      _ = v := by group
  · intro he
    calc
      x⁻¹ * (h * v * h⁻¹) * x =
          g * ((g⁻¹ * x⁻¹ * h) * v * (g⁻¹ * x⁻¹ * h)⁻¹) * g⁻¹ := by group
      _ = g * v * g⁻¹ := by rw [he]

theorem solves_iff_centralizers (c d : List G) (C D : Subgroup G)
    (hc : Generates c C) (hd : Generates d D) (g h x : G) :
    Solves c d g h x ↔
      x ∈ Subgroup.centralizer (C : Set G) ∧
      g⁻¹ * x⁻¹ * h ∈ Subgroup.centralizer (D : Set G) := by
  rw [Solves, fixes_generators_iff c C hc]
  apply and_congr_right
  intro _
  rw [← hd, Subgroup.centralizer_closure]
  exact forall₂_congr fun v _ => (transported_conjugation_iff g h x v).trans
    (forward_conjugation_iff _ v)

/-- Every element of a subgroup centralizes that subgroup's centralizer. -/
theorem mem_doubleCentralizer {A : Subgroup G} {a : G} (ha : a ∈ A) :
    a ∈ Subgroup.centralizer (Subgroup.centralizer (A : Set G) : Set G) := by
  intro u hu
  exact (hu a ha).symm

/-- Central times subgroup factors commute with the centralizer. -/
theorem centralProduct_mem_doubleCentralizer {A : Subgroup G} {x : G}
    (hx : CentralProduct A x) :
    x ∈ Subgroup.centralizer (Subgroup.centralizer (A : Set G) : Set G) := by
  rcases hx with ⟨z, hz, a, ha, rfl⟩
  exact (Subgroup.centralizer (Subgroup.centralizer (A : Set G) : Set G)).mul_mem
    (Subgroup.center_le_centralizer _ hz) (mem_doubleCentralizer ha)

/-- A double-coset factorization gives the exact simultaneous-conjugacy witness. -/
theorem factorization_solves (A B : Subgroup G) (c d : List G)
    (hc : Generates c (Subgroup.centralizer (A : Set G)))
    (hd : Generates d (Subgroup.centralizer (B : Set G)))
    (g a b : G) (ha : a ∈ A) (hb : b ∈ B) :
    Solves c d g (a * g * b) a := by
  rw [solves_iff_centralizers c d _ _ hc hd]
  constructor
  · exact mem_doubleCentralizer ha
  · have he : g⁻¹ * a⁻¹ * (a * g * b) = b := by group
    rw [he]
    exact mem_doubleCentralizer hb

/-- Central factors disappear under the simultaneous conjugacy equations. -/
theorem central_factorization_solves (A B : Subgroup G) (c d : List G)
    (hc : Generates c (Subgroup.centralizer (A : Set G)))
    (hd : Generates d (Subgroup.centralizer (B : Set G)))
    (g z a b : G) (hz : z ∈ Subgroup.center G) (ha : a ∈ A) (hb : b ∈ B) :
    Solves c d g (z * (a * g * b)) a := by
  rw [solves_iff_centralizers c d _ _ hc hd]
  constructor
  · exact mem_doubleCentralizer ha
  · have hza : a⁻¹ * z = z * a⁻¹ := Subgroup.mem_center_iff.mp hz _
    have hzg : g⁻¹ * z = z * g⁻¹ := Subgroup.mem_center_iff.mp hz _
    have he : g⁻¹ * a⁻¹ * (z * (a * g * b)) = z * b := by
      calc
        g⁻¹ * a⁻¹ * (z * (a * g * b)) = g⁻¹ * (a⁻¹ * z) * a * g * b := by group
        _ = g⁻¹ * (z * a⁻¹) * a * g * b := by rw [hza]
        _ = (g⁻¹ * z) * g * b := by group
        _ = z * b := by rw [hzg]; group
    rw [he]
    exact centralProduct_mem_doubleCentralizer ⟨z, hz, b, hb, rfl⟩

/-- The central-obstruction remark, with no center-intersection assumption. -/
theorem solvable_iff_centralDoubleCoset (A B : Subgroup G) (c d : List G)
    (hc : Generates c (Subgroup.centralizer (A : Set G)))
    (hd : Generates d (Subgroup.centralizer (B : Set G)))
    (hA : HasDoubleCentralizer A) (hB : HasDoubleCentralizer B) (g h : G) :
    (∃ x, Solves c d g h x) ↔ InCentralDoubleCoset A B g h := by
  constructor
  · rintro ⟨x, hx⟩
    have hxy := (solves_iff_centralizers c d _ _ hc hd g h x).mp hx
    rcases (hA x).mp hxy.1 with ⟨zA, hzA, a, ha, hxa⟩
    rcases (hB (g⁻¹ * x⁻¹ * h)).mp hxy.2 with ⟨zB, hzB, b, hb, hyb⟩
    refine ⟨zA * zB, (Subgroup.center G).mul_mem hzA hzB, a, ha, b, hb, ?_⟩
    have hreconstruct : h = x * g * (g⁻¹ * x⁻¹ * h) := by group
    rw [hyb, hxa] at hreconstruct
    have hcomm : (a * g) * zB = zB * (a * g) := Subgroup.mem_center_iff.mp hzB _
    calc
      h = (zA * a) * g * (zB * b) := hreconstruct
      _ = zA * ((a * g) * zB) * b := by group
      _ = zA * (zB * (a * g)) * b := by rw [hcomm]
      _ = (zA * zB) * (a * g * b) := by group
  · rintro ⟨z, hz, a, ha, b, hb, rfl⟩
    exact ⟨a, central_factorization_solves A B c d hc hd g z a b hz ha hb⟩

/-- A trivial ambient-center intersection eliminates exactly the central ambiguity. -/
theorem centralDoubleCoset_iff (A B H : Subgroup G) (hAH : A ≤ H) (hBH : B ≤ H)
    (hcenter : Subgroup.center G ⊓ H = ⊥) (g h : G) (hg : g ∈ H) (hh : h ∈ H) :
    InCentralDoubleCoset A B g h ↔ InDoubleCoset A B g h := by
  constructor
  · rintro ⟨z, hz, a, ha, b, hb, he⟩
    have hab : a * g * b ∈ H := H.mul_mem (H.mul_mem (hAH ha) hg) (hBH hb)
    have hzH : z ∈ H := by
      have hrecover : z = h * (a * g * b)⁻¹ := by rw [he]; group
      rw [hrecover]
      exact H.mul_mem hh (H.inv_mem hab)
    have hzbot : z ∈ (⊥ : Subgroup G) := by rw [← hcenter]; exact ⟨hz, hzH⟩
    have hz1 : z = 1 := hzbot
    refine ⟨a, ha, b, hb, ?_⟩
    simpa only [hz1, one_mul] using he
  · rintro ⟨a, ha, b, hb, he⟩
    exact ⟨1, (Subgroup.center G).one_mem, a, ha, b, hb, by simpa using he⟩

/-- DCPv3 Proposition `prop:ambient-reduction`, its complete algebraic equivalence. -/
theorem ambient_reduction (A B H : Subgroup G) (hAH : A ≤ H) (hBH : B ≤ H)
    (c d : List G) (hc : Generates c (Subgroup.centralizer (A : Set G)))
    (hd : Generates d (Subgroup.centralizer (B : Set G)))
    (hA : HasDoubleCentralizer A) (hB : HasDoubleCentralizer B)
    (hcenter : Subgroup.center G ⊓ H = ⊥) (g h : G) (hg : g ∈ H) (hh : h ∈ H) :
    (∃ x, Solves c d g h x) ↔ InDoubleCoset A B g h :=
  (solvable_iff_centralDoubleCoset A B c d hc hd hA hB g h).trans
    (centralDoubleCoset_iff A B H hAH hBH hcenter g h hg hh)

@[simp] theorem membership_iff_doubleCoset (A : Subgroup G) (h : G) :
    InDoubleCoset A ⊥ 1 h ↔ h ∈ A := by
  constructor
  · rintro ⟨a, ha, b, hb, he⟩
    have hb1 : b = 1 := hb
    rw [he, hb1]
    simpa using ha
  · intro hh
    exact ⟨h, hh, 1, (⊥ : Subgroup G).one_mem, by simp⟩

/-- Injective homomorphisms preserve and reflect double-coset membership. -/
theorem map_doubleCoset_iff {K : Type*} [Group K] (f : G →* K)
    (hf : Function.Injective f) (A B : Subgroup G) (g h : G) :
    InDoubleCoset (A.map f) (B.map f) (f g) (f h) ↔ InDoubleCoset A B g h := by
  constructor
  · rintro ⟨a, ha, b, hb, he⟩
    rcases ha with ⟨a, ha, rfl⟩
    rcases hb with ⟨b, hb, rfl⟩
    exact ⟨a, ha, b, hb, hf (by simpa only [map_mul] using he)⟩
  · rintro ⟨a, ha, b, hb, he⟩
    exact ⟨f a, ⟨a, ha, rfl⟩, f b, ⟨b, hb, rfl⟩, by simpa only [map_mul] using congrArg f he⟩

end GroupDCP
