import BraidGroup.Basic
import Mathlib.GroupTheory.FinitelyPresentedGroup

/-! # Finite presentation of braid groups -/
namespace BraidGroup

/-- There are only finitely many defining Artin relators. -/
theorem relators_finite (n : ℕ) : (relators n).Finite := by
  have hs : relators n ⊆
      Set.range (fun p : Generator n × Generator n => commuteRelator p.1 p.2) ∪
      Set.range (fun p : Generator n × Generator n => braidRelator p.1 p.2) := by
    intro r hr
    cases hr with
    | commute i j h => exact Or.inl ⟨(i, j), rfl⟩
    | braid i j h => exact Or.inr ⟨(i, j), rfl⟩
  exact ((Set.finite_range _).union (Set.finite_range _)).subset hs

instance finitelyPresented (n : ℕ) : Group.IsFinitelyPresented (BraidGroup n) where
  out := ⟨n - 1, ofFree, ofFree_surjective,
    relators n, relators_finite n, by
      change Subgroup.normalClosure (relators n) =
        (QuotientGroup.mk' (Subgroup.normalClosure (relators n))).ker
      rw [QuotientGroup.ker_mk']⟩

/-- The standard finite set of crossings is a finite generating set. -/
instance finitelyGenerated (n : ℕ) : Group.FG (BraidGroup n) := by
  rw [Group.fg_iff]
  exact ⟨Set.range (σ (n := n)), closure_range_σ, Set.finite_range _⟩

end BraidGroup
