import DCPv7

/-! A separate local package consumes the public component entry point. -/
#check DCPv7.MainSearch.main_theorem
#check DCPv7.ConstrainedSearch.main_theorem
#check DCPv7.WordAutomaton.finite_words_generate
#check DCPv7.ProductEncoding.product_main_theorem
#check DCPv7.EffectiveReduction.reduction_computable
#check DCPv7.ProductEncoding.coordinateInput_primrec
#check DCPv7.AssemblyCost.assembly_time_linear
#check DCPv7.VerifiedBiautomatic.biautomatic_lemma
#check DCPv7.VerifiedManuscript.braid_main
#check DCPv7.VerifiedManuscript.constrained_main
#check DCPv7.VerifiedManuscript.spherical_main
#check DCPv7.VerifiedManuscript.product_main
#check DCPv7.ProductEncoding.paper_product_main_theorem
#check DCPv7.ProductEncoding.paperSearch_preserves_targets
